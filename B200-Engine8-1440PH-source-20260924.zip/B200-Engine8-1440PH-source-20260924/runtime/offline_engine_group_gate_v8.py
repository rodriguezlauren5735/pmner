"""Offline full-pass verification. Never imports networking or pool code."""
import argparse,ctypes,json,struct,time
from pathlib import Path
from blake3 import blake3
import pearl_mining as pm
from offline_wideproof_fixture_v2 import HEADER,config

def main():
 p=argparse.ArgumentParser();p.add_argument('--m',type=int,default=512);p.add_argument('--n',type=int,default=512)
 p.add_argument('--noise-rows',type=int,choices=(1,8),default=1);p.add_argument('--k',type=int,default=8192);p.add_argument('--steps',type=int,default=8);p.add_argument('--nbits',type=lambda s:int(s,0),default=0x1d2fffff)
 p.add_argument('--group',type=int,default=16)
 args=p.parse_args();m,n,k=args.m,args.n,args.k
 assert 1<=args.steps<=100 and (m+n)*k<=4_000_000_000
 assert (2+128)*k<=1<<22 and m%256==n%256==0
 lib=ctypes.CDLL(str(Path('b200_offline_engine_v8.so').resolve()))
 u8p=ctypes.POINTER(ctypes.c_uint8);u32p=ctypes.POINTER(ctypes.c_uint32)
 lib.engine_init.argtypes=[ctypes.c_int]*4;lib.engine_init.restype=ctypes.c_int
 lib.engine_job.argtypes=[u8p,u8p];lib.engine_job.restype=ctypes.c_int
 lib.engine_pass.argtypes=[u8p,u8p,u32p,ctypes.POINTER(ctypes.c_double)];lib.engine_pass.restype=ctypes.c_int
 lib.engine_roots.argtypes=[ctypes.c_int,u8p,ctypes.c_size_t];lib.engine_roots.restype=ctypes.c_int
 lib.engine_close.argtypes=[];lib.engine_close.restype=ctypes.c_int
 buf=lambda b:(ctypes.c_uint8*len(b)).from_buffer_copy(b)
 cfg=config(k);base=(args.nbits&0x7fffff)<<(8*((args.nbits>>24)-3));target=pm.penalized_target_bound(base,cfg)
 assert target is not None and 0<target<1<<256
 assert callable(getattr(pm.MerkleTree,'sparse_filled_multileaf_proof',None))
 meta=(ctypes.c_uint8*128)();hits=(ctypes.c_uint32*(16+1024*16))();seconds=ctypes.c_double()
 caches=[(ctypes.c_uint8*(((dim*k+131071)//131072)*32))() for dim in (m,n)]
 assert lib.engine_init(m,n,k,args.group)==0
 lib.engine_noise_rows.argtypes=[ctypes.c_int];lib.engine_noise_rows.restype=ctypes.c_int
 assert lib.engine_noise_rows(args.noise_rows)==0
 durations=[];verified=0;job_header=None
 try:
  for step in range(args.steps):
   cold=step in (0,args.steps//2)
   if cold:
    job_header=bytes([HEADER[0]^(16 if step else 0)])+HEADER[1:]
    key=blake3(job_header+cfg.to_bytes()).digest()
    assert lib.engine_job(buf(key),buf(target.to_bytes(32,'little')))==0
   nonce=123456789+step;prefix=bytes((((nonce>>(7*j))&127)-64)&255 for j in range(10))
   start=time.perf_counter();assert lib.engine_pass(buf(prefix),meta,hits,ctypes.byref(seconds))==0
   call_wall=time.perf_counter()-start;count=hits[0];raw=bytes(hits)
   assert count<=1024
   roots=[bytes(meta[:32]),bytes(meta[32:64])]
   salts=[blake3(b'pearl/cert-v3/noise-seed/'+name).digest() for name in (b'A',b'B')]
   bound=[blake3(root+dim.to_bytes(4,'little')+bytes(28),key=salt).digest() for root,dim,salt in zip(roots,(m,n),salts)]
   sb=blake3(key+bound[1]).digest();sa=blake3(sb+bound[0]).digest()
   assert bytes(meta[64:])==sa+sb,'GPU commitment seed differs from CPU'
   if m<=512 and n<=512:
    assert roots[0]==blake3(prefix+bytes([64])*(m*k-10),key=key).digest()
    assert roots[1]==blake3(bytes([64])*(n*k),key=key).digest()
   proof_start=time.perf_counter()
   for which,cache in enumerate(caches):assert lib.engine_roots(which,cache,len(cache))==0
   selected=sorted(set(i*(count-1)//min(7,count-1) for i in range(min(8,count)))) if count>1 else list(range(count))
   for index in selected:
    proof_id=struct.unpack_from('<I',raw,64*(index+1))[0];gpu_hash=int.from_bytes(raw[64*(index+1)+4:64*(index+1)+36],'little')
    assert gpu_hash<=target
    tile,t=divmod(proof_id,128);tm,tn=divmod(tile,n//256)
    row=(t//16)*16+(t%16)//2;group=t%2
    rows=[tm*128+row,tm*128+row+8];cols=list(range(tn*256+group*128,tn*256+(group+1)*128))
    assert 0<=min(rows)<=max(rows)<m and 0<=min(cols)<=max(cols)<n
    proofs=[]
    for which,(dim,indices,pfx) in enumerate(((m,rows,prefix),(n,cols,b''))):
     leaves=pm.MerkleTree.compute_leaf_indices_from_rows(indices,(dim,k))
     pr=pm.MerkleTree.sparse_filled_multileaf_proof(pfx,64,dim*k,key,leaves,7,128,bytes(caches[which])[32:],roots[which])
     proofs.append(pm.MatrixMerkleProof(pr,indices))
    proof=pm.PlainProof(m=m,n=n,k=k,noise_rank=128,a_merkle_proof=proofs[0],bt_merkle_proof=proofs[1],moe=None)
    header=pm.IncompleteBlockHeader.from_bytes(job_header)
    valid,why=pm.verify_plain_proof_v3(header,proof,nbits_override=args.nbits)
    assert valid,{'step':step,'proof':proof_id,'reason':why}
    assert pm.PlainProof.from_base64(proof.to_base64()).to_base64()==proof.to_base64()
    if not verified:
     assert gpu_hash>pm.penalized_target_bound(1,cfg)
     rejected,_=pm.verify_plain_proof_v3(header,proof,nbits_override=0x01010000);assert not rejected
    verified+=1
   if not cold:durations.append(seconds.value)
   print(json.dumps({'step':step,'cold_job':cold,'nonce':nonce,'m':m,'n':n,'k':k,'hits':count,'verified_in_pass':len(selected),'full_gpu_pass_seconds':seconds.value,'ctypes_call_wall_seconds':call_wall,'proof_and_copy_seconds':time.perf_counter()-proof_start,'offline_only':True}),flush=True)
  assert verified>0,'no native V3 proof verified'
  print(json.dumps({'state':'passed','native_proofs_verified':verified,'warm_full_pass_tmad_s':len(durations)*m*n*k/sum(durations)/1e12 if durations else None,'includes_commitment_noising_hash_hit_copy':True,'excludes_proof_and_network':True,'not_pool_hashrate':True}),flush=True)
 finally:assert lib.engine_close()==0

if __name__=='__main__':main()
