"""Prepared B200 pool adapter; NEVER started automatically on import.

Requires passed native engine gates and an explicit finite runtime. GPU0 only.
Uses original V3 verification before submitting every proof over verified TLS.
Reported local throughput and difficulty-weighted accepted work remain separate.
"""
from __future__ import annotations
import argparse,ctypes,json,multiprocessing,os,secrets,signal,struct,threading,time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from blake3 import blake3
import pearl_mining as pm
from offline_wideproof_fixture_v2 import config
from b200_stratum_transport_v1 import (EventLogger,StratumClient,Submission,compact_to_target,encode_base128_nonce,encode_kryptex_proof)

GPU_UUID='GPU-af7a73cd-3032-50a8-c5a5-21c5bab963d7'

def hit_indices(proof_id:int,m:int,n:int):
 if m%256 or n%256 or not 0<=proof_id<m*n//256:raise ValueError('invalid proof id or shape')
 tile,t=divmod(proof_id,128);tm,tn=divmod(tile,n//256)
 row=(t//16)*16+(t%16)//2;half=t%2
 rows=[tm*128+row,tm*128+row+8]
 cols=list(range(tn*256+half*128,tn*256+(half+1)*128))
 if max(rows)>=m or max(cols)>=n:raise ValueError('out-of-bounds proof pattern')
 return rows,cols

def proof_worker_ready():return True

def prove_hit(task):
 started=time.perf_counter()
 m,n,k,job,prefix,key,meta,caches,record=task
 if k<2048 or k>32256 or k%128 or 130*k>1<<22:raise ValueError('unsupported proof input length')
 cfg=config(k);expected_key=blake3(job.header+cfg.to_bytes()).digest()
 if key!=expected_key:raise ValueError('snapshot key mismatch')
 target=pm.penalized_target_bound(compact_to_target(job.share_nbits),cfg)
 if target is None or not 0<target<1<<256:raise ValueError('invalid target')
 proof_id=struct.unpack_from('<I',record)[0];hash_value=int.from_bytes(record[4:36],'little')
 if hash_value>target:raise ValueError('GPU hit does not meet target')
 rows,cols=hit_indices(proof_id,m,n);roots=(meta[:32],meta[32:64]);proofs=[]
 for which,(dim,indices,pfx) in enumerate(((m,rows,prefix),(n,cols,b''))):
  expected=((dim*k+131071)//131072)*32
  if len(caches[which])!=expected:raise ValueError('invalid cached root length')
  leaves=pm.MerkleTree.compute_leaf_indices_from_rows(indices,(dim,k))
  merkle=pm.MerkleTree.sparse_filled_multileaf_proof(pfx,64,dim*k,key,leaves,7,128,caches[which][32:],roots[which])
  proofs.append(pm.MatrixMerkleProof(merkle,indices))
 proof=pm.PlainProof(m=m,n=n,k=k,noise_rank=128,a_merkle_proof=proofs[0],bt_merkle_proof=proofs[1],moe=None)
 valid,why=pm.verify_plain_proof_v3(pm.IncompleteBlockHeader.from_bytes(job.header),proof,nbits_override=job.share_nbits)
 if not valid:raise RuntimeError(f'Independent native V3 rejected local candidate: {why}')
 return encode_kryptex_proof(proof),time.perf_counter()-started,proof_id

class Engine:
 def __init__(self,library,m,n,k,group,noise_rows):
  self.m,self.n,self.k=m,n,k
  self.lib=ctypes.CDLL(str(Path(library).resolve()))
  u8p=ctypes.POINTER(ctypes.c_uint8);u32p=ctypes.POINTER(ctypes.c_uint32)
  self.lib.engine_init.argtypes=[ctypes.c_int]*4;self.lib.engine_job.argtypes=[u8p,u8p]
  self.lib.engine_pass.argtypes=[u8p,u8p,u32p,ctypes.POINTER(ctypes.c_double)]
  self.lib.engine_roots.argtypes=[ctypes.c_int,u8p,ctypes.c_size_t]
  self.lib.engine_noise_rows.argtypes=[ctypes.c_int];self.lib.engine_close.argtypes=[]
  for name in ('engine_init','engine_job','engine_pass','engine_roots','engine_noise_rows','engine_close'):getattr(self.lib,name).restype=ctypes.c_int
  self.meta=(ctypes.c_uint8*128)();self.hits=(ctypes.c_uint32*(16+1024*16))();self.seconds=ctypes.c_double()
  self.caches=[(ctypes.c_uint8*(((dim*k+131071)//131072)*32))() for dim in (m,n)]
  if self.lib.engine_init(m,n,k,group):raise RuntimeError('engine rejected shape')
  if self.lib.engine_noise_rows(noise_rows):raise RuntimeError('engine rejected noise layout')
 @staticmethod
 def buf(data):return (ctypes.c_uint8*len(data)).from_buffer_copy(data)
 def job(self,job):
  self.key=blake3(job.header+config(self.k).to_bytes()).digest()
  target=pm.penalized_target_bound(compact_to_target(job.share_nbits),config(self.k))
  if target is None or not 0<target<1<<256:raise ValueError('unsupported target')
  if self.lib.engine_job(self.buf(self.key),self.buf(target.to_bytes(32,'little'))):raise RuntimeError('engine job failed')
 def run(self,nonce):
  prefix=bytes(v&255 for v in encode_base128_nonce(nonce))
  if self.lib.engine_pass(self.buf(prefix),self.meta,self.hits,ctypes.byref(self.seconds)):raise RuntimeError('engine pass failed/overflow')
  count=self.hits[0]
  if not 0<=count<=1024:raise RuntimeError('hit queue overflow')
  if not count:return prefix,[],None
  raw=bytes(self.hits);records=[raw[64*(i+1):64*(i+2)] for i in range(count)]
  for which,cache in enumerate(self.caches):
   if self.lib.engine_roots(which,cache,len(cache)):raise RuntimeError('engine root copy failed')
  return prefix,records,(self.key,bytes(self.meta),tuple(bytes(c) for c in self.caches))
 def close(self):
  if self.lib.engine_close():raise RuntimeError('engine close failed')

def validate_runtime_gate(gate,library):
 gate_path=Path(gate)
 if not gate_path.name.endswith('-native-gates.json'):raise RuntimeError('unexpected gate filename')
 if json.loads(gate_path.read_text()).get('state')!='passed':raise RuntimeError('native engine gate has not passed')
 runtime_path=gate_path.with_name(gate_path.name.removesuffix('-native-gates.json')+'-status.json')
 runtime=json.loads(runtime_path.read_text())
 if runtime.get('state')!='passed':raise RuntimeError('continuous engine validation has not passed')
 if runtime.get('library')!=Path(library).name:raise RuntimeError('runtime gate/library mismatch')
 return runtime

def main():
 p=argparse.ArgumentParser();p.add_argument('--wallet',required=True);p.add_argument('--worker',required=True)
 p.add_argument('--host',default='prl-us.kryptex.network');p.add_argument('--port',type=int,default=8048)
 p.add_argument('--seconds',type=int,required=True);p.add_argument('--m',type=int,default=32768);p.add_argument('--n',type=int,default=259584)
 p.add_argument('--k',type=int,default=8192);p.add_argument('--group',type=int,default=16);p.add_argument('--noise-rows',type=int,choices=(1,8),default=8)
 p.add_argument('--library',default='b200_offline_engine_v4.so');p.add_argument('--gate',default='offline-engine-v4-native-gates.json')
 p.add_argument('--log-file',required=True);a=p.parse_args()
 if not 60<=a.seconds<=1800:raise ValueError('finite runtime must be 60..1800 seconds')
 if not a.wallet.startswith('prl1') or len(a.wallet)>100 or not a.worker or len(a.worker)>64 or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in a.worker):raise ValueError('invalid wallet/worker')
 if os.environ.get('CUDA_VISIBLE_DEVICES')!=GPU_UUID:raise RuntimeError('GPU0 UUID isolation is required')
 validate_runtime_gate(a.gate,a.library)
 if Path(a.log_file).exists():raise FileExistsError(a.log_file)
 import fcntl
 lock=Path('gpu0.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 logger=EventLogger(a.log_file);stop=threading.Event()
 for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda *_:stop.set())
 client=StratumClient(host=a.host,port=a.port,wallet_worker=a.wallet+'.'+a.worker,logger=logger,stop_event=stop,reconnect_seconds=3)
 engine=None;executor=None;pending=[];started=time.monotonic();mining_start=None;work=0;passes=0;dropped=0;job=None;nonce=secrets.randbits(60);next_status=started+10
 try:
  executor=ProcessPoolExecutor(max_workers=1,mp_context=multiprocessing.get_context('spawn'))
  if not executor.submit(proof_worker_ready).result(timeout=30):raise RuntimeError('proof worker failed')
  engine=Engine(a.library,a.m,a.n,a.k,a.group,a.noise_rows)
  client.start();logger.emit('canary_started',m=a.m,n=a.n,k=a.k,worker=a.worker,seconds=a.seconds,library=a.library,configuration=config(a.k).to_bytes().hex(),gpu_uuid=GPU_UUID)
  while not stop.is_set() and time.monotonic()-started<a.seconds:
   for future,snapshot,hs in list(pending):
    if future.done():
     pending.remove((future,snapshot,hs))
     if future.cancelled():continue
     wire,proof_seconds,proof_id=future.result()
     queued=client.queue_submission(Submission(snapshot,hs,wire))
     logger.emit('proof_verified',job_id=snapshot.job_id,proof_id=proof_id,proof_seconds=proof_seconds,queued=queued)
   new=client.wait_for_new_job(job.epoch if job else None,0.0 if job and client.is_current(job) else 0.5)
   if new:
    job=new;engine.job(job)
    if mining_start is None:mining_start=time.monotonic()
   if job and client.is_current(job):
    nonce+=1;prefix,records,cache=engine.run(nonce);passes+=1;work+=a.m*a.n*a.k
    hs=int(work/max(time.monotonic()-mining_start,1e-9))
    if records and client.is_current(job):
     key,meta,caches=cache
     for record in records:
      if len(pending)>=16:dropped+=1;logger.emit('proof_queue_full',job_id=job.job_id);continue
      future=executor.submit(prove_hit,(a.m,a.n,a.k,job,prefix,key,meta,caches,record));pending.append((future,job,hs))
   now=time.monotonic()
   if now>=next_status:
    stats=client.stats();logger.emit('status',passes=passes,elapsed=now-started,local_wall_tmad_s=work/max(now-(mining_start or started),1e-9)/1e12,accepted_work_tmad_s=stats['accepted_work']/max(now-(mining_start or started),1e-9)/1e12,**stats,proof_pending=len(pending),proof_dropped=dropped)
    next_status=now+10
  # Bounded drain: no new GPU work; allow already valid current-job shares to settle.
  drain=time.monotonic()+5
  while pending and not stop.is_set() and time.monotonic()<drain:
   for future,snapshot,hs in list(pending):
    if future.done():
     pending.remove((future,snapshot,hs));wire,_,_=future.result();client.queue_submission(Submission(snapshot,hs,wire))
   time.sleep(0.05)
  if not stop.is_set():stop.wait(2)
 finally:
  stop.set()
  if client._thread.ident is not None:client.stop()
  else:client._wakeup.close()
  for future,_,_ in pending:future.cancel()
  if executor:executor.shutdown(wait=True,cancel_futures=True)
  if engine:engine.close()
  now=time.monotonic();stats=client.stats();logger.emit('canary_finished',passes=passes,elapsed=now-started,local_wall_tmad_s=work/max(now-(mining_start or started),1e-9)/1e12,accepted_work_tmad_s=stats['accepted_work']/max(now-(mining_start or started),1e-9)/1e12,**stats,proof_dropped=dropped)
  lock.close()

if __name__=='__main__':main()
