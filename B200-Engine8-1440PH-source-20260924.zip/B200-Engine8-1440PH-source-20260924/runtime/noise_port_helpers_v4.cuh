#pragma once
// Uses the frozen original 0.6.2 keyed noise kernel; require independent CPU
// verification (noise-v5-status.json passed) before using this benchmark helper.
// Fixed keys are for offline testing only, not a commitment or a real pool job.
#include "gemm/noise_generation_kernel.h"
#include <cutlass/device_kernel.h>
__global__ void sparse_indices(const int8_t* sparse,uint16_t* indices,int K,int* errors){
 int k=blockIdx.x*blockDim.x+threadIdx.x;if(k>=K)return;
 int pos=-1,neg=-1,np=0,nn=0;
 for(int r=0;r<128;++r){int v=sparse[k*128+r];if(v==1){pos=r;++np;}else if(v==-1){neg=r;++nn;}else if(v!=0)atomicAdd(errors,1);}
 if(np!=1||nn!=1)atomicAdd(errors,1);
 indices[k]=np==1&&nn==1?uint16_t(pos|(neg<<8)):uint16_t(0xffff);
}
__global__ void apply_sparse(const int8_t* base,const int8_t* dense,const uint16_t* indices,int8_t* out,int rows,int K){
 int row=blockIdx.x;if(row>=rows)return;
 // Every warp holds all 128 noise bytes as 32 packed words.
 uint32_t noise_word=reinterpret_cast<const uint32_t*>(dense+size_t(row)*128)[threadIdx.x&31];
 // Uniform loop and shuffle participation, including partial K fixtures.
 for(int start=0;start<K;start+=int(blockDim.x)*16){
   int k=start+int(threadIdx.x)*16;bool active=k<K;
   uint4 value=make_uint4(0,0,0,0),i0=make_uint4(0,0,0,0),i1=make_uint4(0,0,0,0);
   if(active){
     value=*reinterpret_cast<const uint4*>(base+size_t(row)*K+k);
     i0=*reinterpret_cast<const uint4*>(indices+k);i1=*reinterpret_cast<const uint4*>(indices+k+8);
   }
   uint32_t words[4]={value.x,value.y,value.z,value.w},packed[4]={};
   uint32_t selectors[8]={i0.x,i0.y,i0.z,i0.w,i1.x,i1.y,i1.z,i1.w};
   CUTE_UNROLL
   for(int j=0;j<16;++j){
     uint32_t pair=(selectors[j/2]>>((j&1)*16))&65535u;int pos=pair&255,neg=pair>>8;
     uint32_t pn=__shfl_sync(0xffffffffu,noise_word,(pos>>2)&31);
     uint32_t nn=__shfl_sync(0xffffffffu,noise_word,(neg>>2)&31);
     int pv=int(int8_t((pn>>((pos&3)*8))&255)),nv=int(int8_t((nn>>((neg&3)*8))&255));
     int byte=(words[j/4]>>((j%4)*8))&255;
     uint32_t v=uint32_t(byte+pv-nv)&255;packed[j/4]|=v<<((j%4)*8);
   }
   if(active)*reinterpret_cast<uint4*>(out+size_t(row)*K+k)=make_uint4(packed[0],packed[1],packed[2],packed[3]);
 }
}

template<typename T>T* alloc(size_t count){T* p;CK(cudaMalloc(&p,count*sizeof(T)));return p;}

// Optional exact-length offline fixtures, never read browser/session credentials.
bool probe_read_exact_file(const char* variable,uint8_t* dest,size_t length){
 const char* path=getenv(variable);if(!path||!*path)return false;
 FILE* f=fopen(path,"rb");if(!f){fprintf(stderr,"cannot open fixture %s\n",variable);exit(8);}
 size_t count=fread(dest,1,length,f);int extra=fgetc(f);fclose(f);
 if(count!=length||extra!=EOF){fprintf(stderr,"wrong fixture size %s\n",variable);exit(8);}
 return true;
}
void probe_noise_keys(uint8_t* ka,uint8_t* kb){
 for(int i=0;i<32;++i){ka[i]=i;kb[i]=255-i;}
 uint8_t keys[64];if(probe_read_exact_file("PROBE_NOISE_KEYS",keys,64))for(int i=0;i<32;++i){ka[i]=keys[i];kb[i]=keys[i+32];}
}
void fixed_noised_inputs(int8_t* a,int8_t* b,int M,int N,int K){
 uint8_t ka[32],kb[32];probe_noise_keys(ka,kb);
 auto keya=alloc<uint8_t>(32),keyb=alloc<uint8_t>(32);CK(cudaMemcpy(keya,ka,32,cudaMemcpyHostToDevice));CK(cudaMemcpy(keyb,kb,32,cudaMemcpyHostToDevice));
 auto eal=alloc<int8_t>(size_t(M)*128),ebr=alloc<int8_t>(size_t(N)*128),ear=alloc<int8_t>(K*128),ebl=alloc<int8_t>(K*128);
 auto ia=alloc<uint16_t>(K),ib=alloc<uint16_t>(K);auto errors=alloc<int>(1);CK(cudaMemset(errors,0,4));
 using Gen=pearl::NoiseGenerationKernel<128,128>;
 Gen::Arguments args{.ptr_EAL=eal,.ptr_EAL_fp16=nullptr,.ptr_EAR_R_major=ear,.ptr_EAR_K_major=nullptr,.ptr_EBL_R_major=ebl,.ptr_EBL_K_major=nullptr,.ptr_EBR=ebr,.ptr_EBR_fp16=nullptr,.num_rows_EAL=M,.length_EAR=K,.length_EBL=K,.num_rows_EBR=N,.ptr_key_A=keya,.ptr_key_B=keyb,.ptr_aux_buffer=nullptr,.aux_buffer_size=0};
 auto params=Gen::to_underlying_arguments(args);
 auto kernel=cutlass::device_kernel<Gen>;
 cudaEvent_t t0,t1,tg,ti,ta;CK(cudaEventCreate(&t0));CK(cudaEventCreate(&t1));CK(cudaEventCreate(&tg));CK(cudaEventCreate(&ti));CK(cudaEventCreate(&ta));CK(cudaEventRecord(t0));
 kernel<<<Gen::get_grid_shape(params),Gen::get_block_shape(),Gen::SharedStorageSize>>>(params);CK(cudaGetLastError());
 CK(cudaEventRecord(tg));
 sparse_indices<<<(K+255)/256,256>>>(ear,ia,K,errors);sparse_indices<<<(K+255)/256,256>>>(ebl,ib,K,errors);CK(cudaGetLastError());
 CK(cudaEventRecord(ti));
 apply_sparse<<<M,256>>>(a,eal,ia,a,M,K);
 CK(cudaEventRecord(ta));
 apply_sparse<<<N,256>>>(b,ebr,ib,b,N,K);CK(cudaGetLastError());
 CK(cudaEventRecord(t1));CK(cudaEventSynchronize(t1));float ms;CK(cudaEventElapsedTime(&ms,t0,t1));
 int err;CK(cudaMemcpy(&err,errors,4,cudaMemcpyDeviceToHost));if(err){fprintf(stderr,"sparse structure errors %d\n",err);exit(5);}
 printf("offline_noise_not_pool_job=1 noising_setup_ms=%.6f excluded_from_core_rate=1\n",ms);
 float gen,idx,am,bm;CK(cudaEventElapsedTime(&gen,t0,tg));CK(cudaEventElapsedTime(&idx,tg,ti));CK(cudaEventElapsedTime(&am,ti,ta));CK(cudaEventElapsedTime(&bm,ta,t1));
 printf("noise_components_ms generation=%.6f indices=%.6f apply_A=%.6f apply_B=%.6f excludes_allocation_and_commitments=1\n",gen,idx,am,bm);
 void* buffers[]={keya,keyb,eal,ebr,ear,ebl,ia,ib,errors};for(void* p:buffers)CK(cudaFree(p));
 CK(cudaEventDestroy(t0));CK(cudaEventDestroy(t1));
 CK(cudaEventDestroy(tg));CK(cudaEventDestroy(ti));CK(cudaEventDestroy(ta));
}
