"""Bounded offline throughput: fresh nonce every pass, no networking or share-rate claim.

Target is zero to isolate engine cost. A separately validated nonzero-target/native
proof fixture is mandatory before this benchmark; it is not pool accepted work.
"""
import argparse,ctypes,json,time
from pathlib import Path
from blake3 import blake3
from offline_wideproof_fixture_v2 import HEADER,config

def main():
 p=argparse.ArgumentParser();p.add_argument('--m',type=int,default=32768);p.add_argument('--n',type=int,default=259584)
 p.add_argument('--k',type=int,default=8192);p.add_argument('--group',type=int,default=16)
 p.add_argument('--noise-rows',type=int,choices=(1,8),default=1)
 p.add_argument('--warmup',type=float,default=15);p.add_argument('--seconds',type=float,default=40)
 p.add_argument('--job-every',type=float,default=30)
 p.add_argument('--library',default='b200_offline_engine_v8.so')
 a=p.parse_args();assert 1<=a.warmup<=60 and 5<=a.seconds<=180 and (a.job_every==0 or 10<=a.job_every<=120)
 lib=ctypes.CDLL(str(Path(a.library).resolve()))
 u8p=ctypes.POINTER(ctypes.c_uint8);u32p=ctypes.POINTER(ctypes.c_uint32)
 lib.engine_init.argtypes=[ctypes.c_int]*4;lib.engine_job.argtypes=[u8p,u8p]
 lib.engine_pass.argtypes=[u8p,u8p,u32p,ctypes.POINTER(ctypes.c_double)]
 lib.engine_noise_rows.argtypes=[ctypes.c_int];lib.engine_close.argtypes=[]
 for name in ('engine_init','engine_job','engine_pass','engine_noise_rows','engine_close'):getattr(lib,name).restype=ctypes.c_int
 buf=lambda b:(ctypes.c_uint8*len(b)).from_buffer_copy(b)
 assert lib.engine_init(a.m,a.n,a.k,a.group)==0
 assert lib.engine_noise_rows(a.noise_rows)==0
 meta=(ctypes.c_uint8*128)();hits=(ctypes.c_uint32*(16+1024*16))();elapsed=ctypes.c_double()
 key=blake3(HEADER+config(a.k).to_bytes()).digest();assert lib.engine_job(buf(key),buf(bytes(32)))==0
 nonce=123456789;job_changes=0
 def run():
  nonlocal nonce
  nonce+=1;prefix=bytes((((nonce>>(7*j))&127)-64)&255 for j in range(10))
  assert lib.engine_pass(buf(prefix),meta,hits,ctypes.byref(elapsed))==0
  assert hits[0]==0,'unexpected zero-target hit'
  return elapsed.value
 try:
  cold=run();start=time.perf_counter();warm=0
  while time.perf_counter()-start<a.warmup:run();warm+=1
  print(json.dumps({'phase':'measured_start','unix':time.time(),'cold_seconds':cold,'warmup_passes':warm,**vars(a),'not_pool_hashrate':True}),flush=True)
  start=time.perf_counter();count=0;device_time=0.;next_report=10.;last_count=0;last_time=start;next_job=a.job_every
  while time.perf_counter()-start<a.seconds:
   if a.job_every and time.perf_counter()-start>=next_job:
    job_changes+=1;header=HEADER[:-4]+job_changes.to_bytes(4,'little')
    assert lib.engine_job(buf(blake3(header+config(a.k).to_bytes()).digest()),buf(bytes(32)))==0
    next_job+=a.job_every
   device_time+=run();count+=1;now=time.perf_counter()
   if now-start>=next_report:
    print(json.dumps({'phase':'measured','seconds':now-start,'passes':count,'window_full_pass_tmad_s':(count-last_count)*a.m*a.n*a.k/(now-last_time)/1e12,'unix':time.time()}),flush=True)
    last_count=count;last_time=now;next_report+=10.
  wall=time.perf_counter()-start
  print(json.dumps({'state':'passed','passes':count,'job_changes':job_changes,'wall_seconds':wall,'native_call_seconds':device_time,'full_pass_wall_tmad_s':count*a.m*a.n*a.k/wall/1e12,'native_pass_tmad_s':count*a.m*a.n*a.k/device_time/1e12,'includes_fresh_nonce_commitments_A_noising_hash_target_copy':True,'excludes_cpu_proof_network':True,'zero_target':True,'not_pool_hashrate':True,**vars(a)}),flush=True)
 finally:assert lib.engine_close()==0

if __name__=='__main__':main()
