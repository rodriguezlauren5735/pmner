"""Read-only analysis; compute throughput is not difficulty-weighted accepted rate."""
import argparse,collections,csv,json,math,statistics
from datetime import datetime
from pathlib import Path

def analyze(events):
 start=next(e for e in events if e['event']=='canary_started')
 statuses=[e for e in events if e['event']=='status' and e.get('passes',0)>0]
 finals=[e for e in events if e['event']=='canary_finished']
 if not statuses:return {'no_work':True,'finished':bool(finals)}
 unit=start['m']*start['n']*start['k']/1e12
 # Compute independent non-overlapping >=55s windows from pass count deltas.
 windows=[];left=next((e for e in statuses if e['elapsed']>=60),statuses[0])
 for right in statuses:
  dt=right['elapsed']-left['elapsed']
  if dt>=55:
   windows.append({'seconds':dt,'passes':right['passes']-left['passes'],'tmad_s':(right['passes']-left['passes'])*unit/dt})
   left=right
 responses=[e for e in events if e['event']=='share_response']
 accepted=[e for e in responses if e.get('accepted') is True]
 rejected=[e for e in responses if e.get('accepted') is False]
 last=finals[-1] if finals else statuses[-1]
 elapsed=last['passes']*unit/last['local_wall_tmad_s']
 weights=[e['expected_work'] for e in accepted]
 point=sum(weights)/elapsed/1e12
 se=math.sqrt(sum(x*x for x in weights))/elapsed/1e12
 result={'finished':bool(finals),'shape':{k:start[k] for k in ('m','n','k','worker','library')},
  'mining_status_last':statuses[-1],'final_includes_drain':finals[-1] if finals else None,
  'computed_windows':windows,'accepted_count':len(accepted),'rejected_count':len(rejected),
  'rejections':rejected,'accepted_work_tmad_s':point,
  'approx_stationary_compound_poisson_95_interval_tmad_s':[max(0,point-1.96*se),point+1.96*se] if len(accepted)>=30 else None,
  'interval_warning':'Approximate share-luck interval, not evidence of a small stable win; adaptive difficulty/selection can affect inference.',
  'events':dict(collections.Counter(e['event'] for e in events))}
 if windows:result['window_summary']={'min':min(w['tmad_s'] for w in windows),'max':max(w['tmad_s'] for w in windows),'mean':statistics.mean(w['tmad_s'] for w in windows)}
 return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('log');a=p.parse_args()
 events=[json.loads(line) for line in Path(a.log).read_text().splitlines()]
 print(json.dumps(analyze(events),indent=2))
