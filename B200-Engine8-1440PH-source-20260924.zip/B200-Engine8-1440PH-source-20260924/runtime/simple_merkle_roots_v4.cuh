#pragma once
// Independent, offline-test-first BLAKE3 subtree builder, no TMA/warp specialization.
// Input length must be a positive multiple of1024 bytes. Frozen source untouched.
#include <cute/tensor.hpp>
#include <cutlass/cutlass.h>
#include "blake3/blake3.cuh"
#include "tensor_hash/tensor_hash_constants.cuh"
namespace pearl {
using namespace cute;
template<bool ApplyRoot> struct SimpleMerkleRootsKernel {
 static constexpr uint32_t MaxThreadsPerBlock=128,MinBlocksPerMultiprocessor=2;
 static constexpr int SharedStorageSize=8*128*4;
 struct Arguments {const uint8_t* data;uint32_t bytes;uint8_t* roots;};
 using Params=Arguments;
 static Params to_underlying_arguments(Arguments a){return a;}
 static dim3 get_grid_shape(Params p){return dim3((p.bytes/1024+127)/128);}
 static dim3 get_block_shape(){return dim3(128);}
 CUTLASS_DEVICE void operator()(Params const& p,char* memory){
  auto* nodes=reinterpret_cast<uint32_t(*)[128]>(memory);
  uint32_t tid=threadIdx.x,chunks=p.bytes/1024,chunk=blockIdx.x*128+tid;
  uint32_t leaves=min(128u,chunks-blockIdx.x*128);
  auto cv=make_tensor<uint32_t>(Int<8>{});auto msg=make_tensor<uint32_t>(Int<16>{});
  if(tid<leaves){
   CUTE_UNROLL
   for(int i=0;i<8;++i)cv(i)=c_key[i];
   #pragma unroll 1
   for(int block=0;block<16;++block){
    auto* words=reinterpret_cast<const uint32_t*>(p.data+size_t(chunk)*1024+block*64);
    CUTE_UNROLL
    for(int i=0;i<16;++i)msg(i)=words[i];
    uint32_t flags=blake3::KEYED_HASH;
    if(block==0)flags|=blake3::CHUNK_START;
    if(block==15){flags|=blake3::CHUNK_END;if(ApplyRoot&&chunks==1)flags|=blake3::ROOT;}
    blake3::compress_msg_block_u32(msg,cv,blake3::CompressParams{.counter=chunk,.block_len=64,.flags=flags});
   }
   CUTE_UNROLL
   for(int i=0;i<8;++i)nodes[i][tid]=cv(i);
  }
  __syncthreads();
  // Carry odd subtrees unchanged. Final parent applies ROOT only for a whole-message CTA.
  for(uint32_t stride=1;stride<leaves;stride*=2){
   uint32_t left=tid*stride*2,right=left+stride;bool active=right<leaves;
   if(active){
    CUTE_UNROLL
    for(int i=0;i<8;++i){msg(i)=nodes[i][left];msg(i+8)=nodes[i][right];cv(i)=c_key[i];}
   }
   __syncthreads();
   if(active){
    auto params=(ApplyRoot&&left==0&&stride*2>=leaves)?blake3::COMPRESS_PARAMS_ROOT:blake3::COMPRESS_PARAMS_INNER_NODE;
    blake3::compress_msg_block_u32(msg,cv,params);
    CUTE_UNROLL
    for(int i=0;i<8;++i)nodes[i][left]=cv(i);
   }
   __syncthreads();
  }
  if(tid<8)reinterpret_cast<uint32_t*>(p.roots)[blockIdx.x*8+tid]=nodes[tid][0];
 }
};
}
