"""Prepare/verify local V3 fixtures. This module never opens a network socket."""
import base64,json,re,struct,sys
from pathlib import Path
from blake3 import blake3
import pearl_mining as pm

HEADER=bytes.fromhex('00000020d0c6e8483e11724095e82b739bdb511f02ba63bb2023cc0663a52079e2bfb097a65ef30a69c6ebce375322a046445350f53eac02516f6b39d78b73ea3e61451dbae89b6a64d90018')
NBITS=0x1d2fffff
def config(k):
 return pm.MiningConfiguration(common_dim=k,rank=128,mma_type=pm.MMAType.Int7xInt7ToInt32,
  rows_pattern=pm.PeriodicPattern.from_list([0,8]),cols_pattern=pm.PeriodicPattern.from_list(list(range(128))),moe=None)
def inputs(k,nonce):
 prefix=bytes((((nonce>>(7*j))&127)-64)&255 for j in range(10))
 return prefix+bytes([64])*(512*k-10),bytes([64])*(512*k),prefix
def write(path,data):
 with path.open('xb') as out:out.write(data)
def prepare(label,k):
 assert re.fullmatch(r'[a-z0-9-]+',label) and k in (2048,8192,16384,32256)
 nonce=123456789;cfg=config(k);key=blake3(HEADER+cfg.to_bytes()).digest()
 a,b,prefix=inputs(k,nonce)
 ra=blake3(a,key=key).digest();rb=blake3(b,key=key).digest()
 salt_a=blake3(b'pearl/cert-v3/noise-seed/A').digest();salt_b=blake3(b'pearl/cert-v3/noise-seed/B').digest()
 bound_a=blake3(ra+(512).to_bytes(4,'little')+bytes(28),key=salt_a).digest()
 bound_b=blake3(rb+(512).to_bytes(4,'little')+bytes(28),key=salt_b).digest()
 seed_b=blake3(key+bound_b).digest();seed_a=blake3(seed_b+bound_a).digest()
 target=pm.penalized_target_bound((NBITS&0x7fffff)<<(8*((NBITS>>24)-3)),cfg)
 assert target is not None and 0<target<1<<256
 write(Path(label+'-keys.bin'),seed_a+seed_b);write(Path(label+'-nonce.bin'),prefix)
 write(Path(label+'-target.bin'),target.to_bytes(32,'little'))
 meta={'m':512,'n':512,'k':k,'rank':128,'nonce':nonce,'header':HEADER.hex(),'nbits':NBITS,'key':key.hex(),'root_a':ra.hex(),'root_b':rb.hex(),'seed_a':seed_a.hex(),'seed_b':seed_b.hex(),'target':str(target),'config':cfg.to_bytes().hex()}
 with Path(label+'-fixture.json').open('x') as f:json.dump(meta,f,indent=2)
 print(json.dumps({'prepared':label,'k':k,'offline_only':True}))
def verify(label,export):
 meta=json.loads(Path(label+'-fixture.json').read_text());k=meta['k']
 key=bytes.fromhex(meta['key']);a,b,_=inputs(k,meta['nonce'])
 ta=pm.MerkleTree(a,key);tb=pm.MerkleTree(b,key)
 assert ta.root.hex()==meta['root_a'] and tb.root.hex()==meta['root_b']
 exported_config=Path(export+'-config.bin').read_bytes()
 assert exported_config==bytes.fromhex(meta['seed_a'])+int(meta['target']).to_bytes(32,'little')
 raw=Path(export+'-gpu-hits.bin').read_bytes();count=struct.unpack_from('<I',raw)[0]
 assert 0<count<=1024 and len(raw)==64*(count+1),'fixture must contain valid candidates'
 picks=sorted(set((i*(count-1))//7 for i in range(8))) if count>=8 else list(range(count))
 header=pm.IncompleteBlockHeader.from_bytes(bytes.fromhex(meta['header']));verified=[]
 for i in picks:
  proof_id=struct.unpack_from('<I',raw,64*(i+1))[0];tile,t=divmod(proof_id,128);tm,tn=divmod(tile,2)
  row=(t//16)*16+(t%16)//2;group=t%2
  rows=[tm*128+row,tm*128+row+8];cols=[tn*256+c for c in range(256) if c//128==group]
  assert max(rows)<512 and max(cols)<512
  ma=pm.MatrixMerkleProof(ta.get_multileaf_proof(pm.MerkleTree.compute_leaf_indices_from_rows(rows,(512,k))),rows)
  mb=pm.MatrixMerkleProof(tb.get_multileaf_proof(pm.MerkleTree.compute_leaf_indices_from_rows(cols,(512,k))),cols)
  proof=pm.PlainProof(m=512,n=512,k=k,noise_rank=128,a_merkle_proof=ma,bt_merkle_proof=mb,moe=None)
  valid,reason=pm.verify_plain_proof_v3(header,proof,nbits_override=meta['nbits'])
  assert valid,{'proof_id':proof_id,'reason':reason}
  encoded=proof.to_base64();decoded=pm.PlainProof.from_base64(encoded)
  assert decoded.to_base64()==encoded
  if not verified:
   hard_bound=pm.penalized_target_bound(1,config(k));gpu_hash=int.from_bytes(raw[64*(i+1)+4:64*(i+1)+36],'little')
   assert hard_bound is not None and gpu_hash>hard_bound
   rejected,_=pm.verify_plain_proof_v3(header,proof,nbits_override=0x01010000)
   assert not rejected,'harder target was incorrectly accepted'
  verified.append(proof_id)
 print(json.dumps({'state':'passed','offline_only':True,'k':k,'total_gpu_hits':count,'independent_native_v3_verified':verified,'roundtrip':True,'hard_target_rejected':True}))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare(sys.argv[2],int(sys.argv[3]))
 elif sys.argv[1]=='verify':verify(sys.argv[2],sys.argv[3])
 else:raise SystemExit('expected prepare or verify')
