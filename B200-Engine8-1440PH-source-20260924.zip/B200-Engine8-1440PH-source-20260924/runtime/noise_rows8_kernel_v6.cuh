#pragma once
// One complete warp per row, eight rows per CTA; general int8 wrap semantics retained.
__global__ void apply_sparse_rows8(const int8_t* base,const int8_t* dense,const uint16_t* indices,int8_t* out,int rows,int K){
 int row=blockIdx.x*8+threadIdx.x/32;if(row>=rows)return;
 // Every warp holds all 128 noise bytes as 32 packed words.
 uint32_t noise_word=reinterpret_cast<const uint32_t*>(dense+size_t(row)*128)[threadIdx.x&31];
 // Uniform loop and shuffle participation, including partial K fixtures.
 for(int start=0;start<K;start+=32*16){
   int k=start+int(threadIdx.x&31)*16;bool active=k<K;
   uint4 value=make_uint4(0,0,0,0),i0=make_uint4(0,0,0,0),i1=make_uint4(0,0,0,0);
   if(active){
     value=*reinterpret_cast<const uint4*>(base+size_t(row)*K+k);
     i0=*reinterpret_cast<const uint4*>(indices+k);i1=*reinterpret_cast<const uint4*>(indices+k+8);
   }
   uint32_t words[4]={value.x,value.y,value.z,value.w},packed[4]={};
   uint32_t selectors[8]={i0.x,i0.y,i0.z,i0.w,i1.x,i1.y,i1.z,i1.w};
   CUTE_UNROLL
   for(int j=0;j<16;++j){
     uint32_t pair=(selectors[j/2]>>((j&1)*16))&65535u;int pos=pair&255,neg=pair>>8;
     uint32_t pn=__shfl_sync(0xffffffffu,noise_word,(pos>>2)&31);
     uint32_t nn=__shfl_sync(0xffffffffu,noise_word,(neg>>2)&31);
     int pv=int(int8_t((pn>>((pos&3)*8))&255)),nv=int(int8_t((nn>>((neg&3)*8))&255));
     int byte=(words[j/4]>>((j%4)*8))&255;
     uint32_t v=uint32_t(byte+pv-nv)&255;packed[j/4]|=v<<((j%4)*8);
   }
   if(active)*reinterpret_cast<uint4*>(out+size_t(row)*K+k)=make_uint4(packed[0],packed[1],packed[2],packed[3]);
 }
}
