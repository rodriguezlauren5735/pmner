"""Local socketpair wakeup for a single-owner network selector.

No pool connection, proof transformation, or submission occurs in this module.
Close only after the selector thread has stopped using reader.
"""
import socket
import threading


class SubmissionWakeup:
    def __init__(self):
        self.reader, self._writer = socket.socketpair()
        self.reader.setblocking(False)
        self._writer.setblocking(False)
        self._lock = threading.Lock()
        self._closed = False

    def notify(self):
        with self._lock:
            if self._closed:
                return False
            try:
                self._writer.send(b'\x01')
            except BlockingIOError:
                # A full buffer already makes reader ready; notifications coalesce.
                pass
            return True

    def drain(self):
        with self._lock:
            if self._closed:
                return
            while True:
                try:
                    data = self.reader.recv(4096)
                except BlockingIOError:
                    return
                if not data:
                    raise ConnectionError('wakeup writer closed unexpectedly')

    def close(self):
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self.reader.close()
            self._writer.close()
