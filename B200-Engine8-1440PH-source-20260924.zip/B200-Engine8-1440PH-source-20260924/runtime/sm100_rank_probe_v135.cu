// v135: combined consumer+producer acknowledgments prevent done-parity lapping.
// v130: single leader reader barrier aggregates both CTAs; removes extra ready rendezvous.
// v129: aggregate TMA completion at CTA0 using SM100 2SM copies, retain reader rendezvous.
// v128: publish mbarrier initialization to async/cluster users before cluster rendezvous.
// v125: exact v121 kernel; expanded safe M <= 131072 for shape screening.
// v121: eight independent XOR chains, unchanged exact 2x128 proof.
// Exact 2-row x 128-contiguous-column proof pattern (256 elements).
// One transcript/thread; MUST verify new config/key/target/proofs before any pool use.
// v111: offline commitment-derived seed/target/nonce fixtures for independent V3 proof verification.
// v110: v109 exact two-SM ping-pong core plus original BLAKE3 and bounded hit queue.
// v109: exact two-SM ping-pong core with bounded K2048..65536 and runtime group tuning.
// v103: two-SM ping-pong 64-column TMEM reads and overlapped XOR.
// v99: v98 plus two-shuffle reduction and explicit TCgen thread-sync fences.
// v98: two-SM release, unsigned positive B and A outside the nonce cluster.
// v91: two-SM release core with verified vector noise helper.
#define NDEBUG 1
// SM100 INT8 cumulative-rank transcript probe; NOT a miner or hashrate claim.
// CuTe/TMEM construction follows NVIDIA CUTLASS's BSD-3-Clause SM100 tutorial.
#include <cute/tensor.hpp>
#include <cute/algorithm/cooperative_copy.hpp>
#include <cute/arch/tmem_allocator_sm100.hpp>
#include <cute/atom/copy_traits_sm90_tma.hpp>
#include <cute/arch/copy_sm100_tma.hpp>
#include <cute/atom/copy_traits_sm100.hpp>
#include <cutlass/arch/barrier.h>
#include <cute/arch/cluster_sm90.hpp>
#include <cuda_runtime.h>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <algorithm>
#include <chrono>
#include <string>
using namespace cute;
#define CK(x) do {cudaError_t e=(x);if(e!=cudaSuccess){fprintf(stderr,"%s: %s\n",#x,cudaGetErrorString(e));exit(2);}}while(0)
#include "noise_port_helpers_v4.cuh"
#ifndef PROBE_BN
#define PROBE_BN 256
#endif
constexpr int BN=256;
constexpr int RB=64;
using MM=decltype(make_tiled_mma(SM100_MMA_S8_2x1SM_SS<int8_t,int8_t,int32_t,256,256,UMMA::Major::K,UMMA::Major::K>{}));
using RankTile=Shape<_256,Int<BN>,_128>;
using SA=decltype(UMMA::tile_to_mma_shape(UMMA::Layout_K_SW128_Atom<int8_t>{},partition_shape_A(MM{},Shape<_256,_128>{})));
using SB=decltype(UMMA::tile_to_mma_shape(UMMA::Layout_K_SW128_Atom<int8_t>{},partition_shape_B(MM{},Shape<Int<BN>,_128>{})));
using GL=decltype(make_layout(make_shape(int(0),int(0)),make_stride(int(0),_1{})));
using GT=decltype(make_tensor(make_gmem_ptr<int8_t>(nullptr),GL{}));
using SFA=decltype(tile_to_shape(UMMA::Layout_K_SW128_Atom<int8_t>{},Shape<_128,_128>{},Step<_1,_2>{}));
using SFB=decltype(tile_to_shape(UMMA::Layout_K_SW128_Atom<int8_t>{},Shape<_128,_128>{},Step<_1,_2>{}));
using TA=decltype(make_tma_atom(SM90_TMA_LOAD{},GT{},SFA{},Shape<_128,_128>{}));
using TB=decltype(make_tma_atom(SM90_TMA_LOAD{},GT{},SFB{},Shape<_128,_128>{}));
struct Smem {
  alignas(128) ArrayEngine<int8_t,cosize_v<SA>> a[2];
  alignas(128) ArrayEngine<int8_t,cosize_v<SB>> b[2];
  alignas(16) uint64_t done;
  alignas(16) uint64_t readers;
  alignas(16) uint64_t ready;
  alignas(16) uint64_t loaded[2];
  uint32_t tbase;
};
__device__ __forceinline__ uint32_t xor3(uint32_t a,uint32_t b,uint32_t c){
  uint32_t d;asm("lop3.b32 %0, %1, %2, %3, 0x96;":"=r"(d):"r"(a),"r"(b),"r"(c));return d;
}
__constant__ uint32_t probe_pow_key[8];
__constant__ uint32_t probe_pow_target[8];

template<bool SaveC,bool Hash=false>
__global__ __launch_bounds__(160,2) void rank_probe(__grid_constant__ const TA ta,__grid_constant__ const TB tb,int32_t* C,uint32_t* T,int M,int N,int K,bool positive_inputs,int swizzle_group,uint32_t hit_capacity){
  extern __shared__ char buf[];auto& s=*reinterpret_cast<Smem*>(buf);
  int peer=blockIdx.x%2;
  int gm=int(gridDim.x)/2;
  int linear=int(blockIdx.x)/2+gm*int(blockIdx.y);
  int start=(linear/(swizzle_group*int(gridDim.y)))*swizzle_group;
  int group=min(swizzle_group,gm-start),within=linear%(swizzle_group*int(gridDim.y));
  int bm=(start+within%group)*2+peer,bn=within/group;
  MM mma;if(positive_inputs){mma.idesc_.b_format_=0;mma.idesc_.a_format_=(bm/2==0?1:0);}auto cta=mma.get_slice(peer);
  auto a=ta.get_tma_tensor(make_shape(M,K));
  auto b=tb.get_tma_tensor(make_shape(N,K));
  auto c=make_tensor(make_gmem_ptr(C),make_layout(make_shape(M,N),make_stride(N,_1{})));
  auto coord=make_coord(bm/2,bn,_);
  auto ga=local_tile(a,RankTile{},coord,Step<_1,X,_1>{});
  auto gb=local_tile(b,RankTile{},coord,Step<X,_1,_1>{});
  auto gcc=local_tile(c,RankTile{},coord,Step<_1,_1,X>{});
  auto gc=local_tile(c,Shape<_128,_256>{},make_coord(bm,bn));
  auto pa=cta.partition_A(ga);auto pb=cta.partition_B(gb);auto pc=cta.partition_C(gcc);
  auto acc=cta.make_fragment_C(pc);
  TMEM::Allocator2Sm alloc;
  if(threadIdx.x<32){alloc.allocate(BN,&s.tbase);alloc.release_allocation_lock();}
  __syncthreads();acc.data()=s.tbase;
  if(threadIdx.x==0){initialize_barrier(s.done,1);initialize_barrier(s.readers,258);initialize_barrier(s.loaded[0],1);initialize_barrier(s.loaded[1],1);cutlass::arch::fence_barrier_init();}
  cute::cluster_sync();
  auto load=[&](int rank){
    if(threadIdx.x==128 && rank<K/128){
      int st=rank&1;
      // Descriptors retain the verified compact [K, row] 2D box and SW128 layout.
      // Both issuing CTAs complete transaction bytes on the leader CTA's barrier.
      if(peer==0)set_barrier_transaction_bytes(s.loaded[st],2*256*128);
      SM100_TMA_2SM_LOAD_2D::copy(ta.get_tma_descriptor(),&s.loaded[st],
        uint64_t(TMA::CacheHintSm100::EVICT_NORMAL),s.a[st].begin(),rank*128,bm*128);
      SM100_TMA_2SM_LOAD_2D::copy(tb.get_tma_descriptor(),&s.loaded[st],
        uint64_t(TMA::CacheHintSm100::EVICT_NORMAL),s.b[st].begin(),rank*128,(bn*2+peer)*128);
    }
  };
  if(threadIdx.x>=128){
    load(0);load(1);
    mma.accumulate_=UMMA::ScaleOut::Zero;
    for(int rank=0;rank<K/128;++rank){
      int st=rank&1;
      if(peer==0){
      wait_barrier(s.loaded[st],(rank/2)&1);
      if(rank)wait_barrier(s.readers,(rank-1)&1);
      asm volatile("tcgen05.fence::after_thread_sync;":::"memory");
      auto sa=make_tensor(make_smem_ptr(s.a[st].begin()),SA{});
      auto sb=make_tensor(make_smem_ptr(s.b[st].begin()),SB{});
      auto da=cta.make_fragment_A(sa);auto db=cta.make_fragment_B(sb);
      CUTE_UNROLL
      for(int k=0;k<size<2>(da);++k){gemm(mma,da(_,_,k),db(_,_,k),acc);mma.accumulate_=UMMA::ScaleOut::One;}
      cutlass::arch::umma_arrive_multicast_2x1SM(&s.done,3);
      }
#if defined(PROBE_DELAY_PEER_PRODUCER) && PROBE_DELAY_PEER_PRODUCER
      if(peer==1)__nanosleep(10000);
#endif
      wait_barrier(s.done,rank&1);
      asm volatile("tcgen05.fence::after_thread_sync;":::"memory");
      // Both producer warps must observe this done phase before the leader can
      // issue the next rank. Otherwise two prefetched stages can lap a lagging
      // peer producer and its parity wait misses the phase, deadlocking reuse.
      if(threadIdx.x==128)cutlass::arch::ClusterBarrier::arrive(&s.readers,0,1);
      load(rank+2);
    }
  }else{
  auto accview=acc(make_coord(_,_),_0{},_0{});
  auto first=local_tile(accview,Shape<_128,Int<RB>>{},make_coord(_0{},_0{}));
  // 16dp256b matches the original WGMMA proof's 2-row / interleaved-column ownership.
  using ReadOp=SM100_TMEM_LOAD_32dp32b64x;
  using ReadAtom=Copy_Atom<ReadOp,int32_t>;
  // Each warp must stay in its own 32-DP subpartition. The second warpgroup
  // reads the other 16 rows of each subpartition; no rows are duplicated.
  auto threads=Layout<Shape<_32,_4>,Stride<_0,decltype(Int<32>{}*TMEM::DP<int32_t>{})>>{};
  auto vals=coalesce(upcast<32>(typename Copy_Traits<ReadOp>::ValID{}));
  auto cp=make_cotiled_copy(ReadAtom{},make_layout(threads,vals),first.layout());
  auto thr=cp.get_slice(threadIdx.x);
  auto firstout=local_tile(gc,Shape<_128,Int<RB>>{},make_coord(_0{},_0{}));
  auto reg=make_tensor<int32_t>(shape(thr.partition_D(firstout)));
  auto icoord=make_identity_tensor(Shape<_128,Int<BN>>{});
  auto rcoord=thr.partition_D(local_tile(icoord,Shape<_128,Int<RB>>{},make_coord(_0{},_0{})));
  uint32_t ring[1][16]={};
  for(int base=0;base<K/128;base+=16){
   CUTE_UNROLL
   for(int slot=0;slot<16;++slot){
    int rank=base+slot;if(rank>=K/128)break;
    wait_barrier(s.done,rank&1);
    uint32_t sum[8]={};
    auto reg1=make_tensor<int32_t>(shape(reg));
    auto read=[&](auto& rg,int q){
      auto as=local_tile(accview,Shape<_128,Int<RB>>{},make_coord(_0{},q));
      copy(cp,thr.partition_S(as),rg);
    };
    auto consume=[&](auto& rg,int q){
      CUTE_UNROLL
      for(int i=0;i<size(rg);++i)sum[((get<1>(rcoord(i))+q*RB)/128)*4+(get<1>(rcoord(i))&3)]^=uint32_t(rg(i));
      if constexpr(SaveC){if(rank==K/128-1){auto out=local_tile(gc,Shape<_128,Int<RB>>{},make_coord(_0{},q));auto dst=thr.partition_D(out);copy(rg,dst);}}
    };
    read(reg,0);read(reg1,1);
    cutlass::arch::fence_view_async_tmem_load();
    consume(reg,0);
    read(reg,2);consume(reg1,1);
    cutlass::arch::fence_view_async_tmem_load();
    read(reg1,3);consume(reg,2);
    cutlass::arch::fence_view_async_tmem_load();
    asm volatile("tcgen05.fence::before_thread_sync;":::"memory");
    cutlass::arch::ClusterBarrier::arrive(&s.readers,0,1);
    consume(reg1,3);
    bool upper=(get<0>(rcoord(0))&8)!=0;
    uint32_t lower=xor3(sum[0],sum[1],sum[2])^sum[3];
    uint32_t higher=xor3(sum[4],sum[5],sum[6])^sum[7];
    uint32_t other=__shfl_xor_sync(0xffffffffu,upper?lower:higher,8);
    uint32_t x=(upper?higher:lower)^other;
    ring[0][slot]=((ring[0][slot]<<13)|(ring[0][slot]>>19))^x;
   }
  }
  int row=get<0>(rcoord(0));
  {
    CUTE_UNROLL
    for(int g=0;g<1;++g){
      int group=(row%16)/8;
      int proof=(row/16)*16+(row%8)*2+group;
      size_t offset=((size_t(bm)*gridDim.y+bn)*128+proof)*16;
      if constexpr(!Hash){
        CUTE_UNROLL
        for(int j=0;j<16;j+=4)reinterpret_cast<uint4*>(T+offset)[j/4]=make_uint4(ring[g][j],ring[g][j+1],ring[g][j+2],ring[g][j+3]);
      }else{
        auto message=make_tensor<uint32_t>(Int<16>{});auto hash=make_tensor<uint32_t>(Int<8>{});
        CUTE_UNROLL
        for(int j=0;j<16;++j)message(j)=ring[g][j];
        CUTE_UNROLL
        for(int j=0;j<8;++j)hash(j)=probe_pow_key[j];
        blake3::compress_msg_block_u32(message,hash,blake3::COMPRESS_PARAMS_SINGLE_BLOCK_KEYED);
        bool accepted=true;
        CUTE_UNROLL
        for(int j=7;j>=0;--j){if(hash(j)>probe_pow_target[j]){accepted=false;break;}if(hash(j)<probe_pow_target[j])break;}
        if(accepted){
          uint32_t index=atomicAdd(T,1u);
          if(index<hit_capacity){
            uint32_t* record=T+16+size_t(index)*16;record[0]=uint32_t(offset/16);
            CUTE_UNROLL
            for(int j=0;j<8;++j)record[j+1]=hash(j);
          }
        }
      }
    }
  }
  }
  cute::cluster_sync();
  if(threadIdx.x<32)alloc.free(s.tbase,BN);
}
static void export_words(const std::string& path,const std::vector<uint32_t>& words){
 FILE* f=fopen(path.c_str(),"wbx");if(!f){fprintf(stderr,"cannot create %s\n",path.c_str());exit(8);}
 if(fwrite(words.data(),4,words.size(),f)!=words.size()){fclose(f);exit(8);}if(fclose(f))exit(8);
}
static uint32_t rot(uint32_t x){return (x<<13)|(x>>19);}
int main(int argc,char**argv){
  int M=256,N=BN,K=2176,reps=1;
  if(argc==5){M=atoi(argv[1]);N=atoi(argv[2]);K=atoi(argv[3]);reps=atoi(argv[4]);}
  if(M<=0||N<=0||K<=0||M%256||N%BN||K%128||M>131072||N>262144||K>8192||reps<1||reps>30)return 3;
  bool verify=(M<=2048&&N<=1024);
  const char* export_prefix=getenv("PROBE_EXPORT");
  if(verify&&(!export_prefix||!*export_prefix)){fprintf(stderr,"PROBE_EXPORT required for independent fused hash gate\n");return 3;}
  cudaDeviceProp p;CK(cudaGetDeviceProperties(&p,0));if(p.major!=10)return 4;
  printf("device=%s SMs=%d CC=%d.%d smem=%zu\n",p.name,p.multiProcessorCount,p.major,p.minor,sizeof(Smem));
  std::vector<int8_t>a(size_t(M)*K),b(size_t(N)*K);
  for(size_t i=0;i<a.size();++i)a[i]=int((i*17+i/97)%31)-15;
  for(size_t i=0;i<b.size();++i)b[i]=int((i*13+i/83)%29)-14;
  const char* pm=getenv("PROBE_INPUT");int pattern=pm?atoi(pm):0;uint32_t seed=0x135ad67u;
  if(pattern && pattern!=4){for(auto* v:{&a,&b})for(auto& x:*v){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;x=pattern==1?int(seed&255)-128:pattern==2?((seed&1)?127:-128):-128;}}
  if(pattern==4){std::fill(a.begin(),a.end(),64);std::fill(b.begin(),b.end(),64);for(int j=0;j<10;++j)a[j]=int8_t(j*23-128);}
  if(pattern==4)probe_read_exact_file("PROBE_NONCE",reinterpret_cast<uint8_t*>(a.data()),10);
  printf("input_pattern=%d\n",pattern);
  int8_t *da,*db;int32_t*dc;uint32_t*dt;
  size_t nc=size_t(M)*N,nt=size_t(M/128)*(N/BN)*128*16;
  CK(cudaMalloc(&da,a.size()));CK(cudaMalloc(&db,b.size()));CK(cudaMalloc(&dc,verify?nc*4:4));CK(cudaMalloc(&dt,(verify?nt+16:16+1024*16)*4));
  CK(cudaMemcpy(da,a.data(),a.size(),cudaMemcpyHostToDevice));CK(cudaMemcpy(db,b.data(),b.size(),cudaMemcpyHostToDevice));
  if(pattern==4){fixed_noised_inputs(da,db,M,N,K);if(verify){CK(cudaMemcpy(a.data(),da,a.size(),cudaMemcpyDeviceToHost));CK(cudaMemcpy(b.data(),db,b.size(),cudaMemcpyDeviceToHost));}}
  CK(cudaFuncSetAttribute(rank_probe<true>,cudaFuncAttributeMaxDynamicSharedMemorySize,sizeof(Smem)));
  CK(cudaFuncSetAttribute(rank_probe<false>,cudaFuncAttributeMaxDynamicSharedMemorySize,sizeof(Smem)));
  CK(cudaFuncSetAttribute(rank_probe<false,true>,cudaFuncAttributeMaxDynamicSharedMemorySize,sizeof(Smem)));
  std::vector<uint32_t> config(16);
  for(int j=0;j<8;++j)config[j]=uint32_t(4*j)|(uint32_t(4*j+1)<<8)|(uint32_t(4*j+2)<<16)|(uint32_t(4*j+3)<<24);
  for(int j=8;j<16;++j)config[j]=verify?0xffffffffu:0u;
  if(verify)config[15]=0x7fffffffu;
  uint8_t fixture_ka[32],fixture_kb[32];probe_noise_keys(fixture_ka,fixture_kb);
  for(int j=0;j<8;++j)config[j]=uint32_t(fixture_ka[4*j])|(uint32_t(fixture_ka[4*j+1])<<8)|(uint32_t(fixture_ka[4*j+2])<<16)|(uint32_t(fixture_ka[4*j+3])<<24);
  probe_read_exact_file("PROBE_POW_TARGET",reinterpret_cast<uint8_t*>(config.data()+8),32);
  CK(cudaMemcpyToSymbol(probe_pow_key,config.data(),32));
  CK(cudaMemcpyToSymbol(probe_pow_target,config.data()+8,32));
  auto ma=make_tensor(make_gmem_ptr(da),make_layout(make_shape(M,K),make_stride(K,_1{})));
  auto mb=make_tensor(make_gmem_ptr(db),make_layout(make_shape(N,K),make_stride(K,_1{})));
  auto ta=make_tma_atom(SM90_TMA_LOAD{},ma,SFA{},Shape<_128,_128>{});
  auto tb=make_tma_atom(SM90_TMA_LOAD{},mb,SFB{},Shape<_128,_128>{});
  cudaLaunchConfig_t cfg{};cfg.gridDim=dim3(M/128,N/BN);cfg.blockDim=dim3(160);cfg.dynamicSmemBytes=sizeof(Smem);
  cudaLaunchAttribute attr{};attr.id=cudaLaunchAttributeClusterDimension;attr.val.clusterDim.x=2;attr.val.clusterDim.y=1;attr.val.clusterDim.z=1;cfg.attrs=&attr;cfg.numAttrs=1;
  int swizzle_group=getenv("PROBE_GROUP")?atoi(getenv("PROBE_GROUP")):16;if(swizzle_group<1||swizzle_group>64)return 3;
  printf("swizzle_group=%d\n",swizzle_group);
  auto launch=[&]{
    if(!verify)CK(cudaMemset(dt,0,16*4));
    if(verify)CK(cudaLaunchKernelEx(&cfg,rank_probe<true>,ta,tb,dc,dt,M,N,K,pattern==4,swizzle_group,verify?uint32_t(nt/16):1024u));
    else CK(cudaLaunchKernelEx(&cfg,rank_probe<false,true>,ta,tb,dc,dt,M,N,K,pattern==4,swizzle_group,verify?uint32_t(nt/16):1024u));
    CK(cudaGetLastError());
  };
  launch();CK(cudaDeviceSynchronize());
  if(verify){
    std::vector<int32_t> ref(nc,0),out(nc);std::vector<uint32_t> tr(nt,0),got(nt);
    for(int k0=0;k0<K;k0+=128){
      for(int r=0;r<M;++r)for(int c=0;c<N;++c){
        int32_t v=ref[r*N+c];for(int k=k0;k<k0+128;++k)v+=int(a[r*K+k])*int(b[c*K+k]);ref[r*N+c]=v;
      }
      for(int tm=0;tm<M/128;++tm)for(int tn=0;tn<N/BN;++tn)for(int t=0;t<128;++t){
        int row=(t/16)*16+(t%16)/2,g=t%2;uint32_t x=0;
        for(int r: {row,row+8})for(int c=0;c<BN;++c)if(c/128==g)x^=uint32_t(ref[(tm*128+r)*N+tn*BN+c]);
        auto& v=tr[((tm*(N/BN)+tn)*128+t)*16+((k0/128)&15)];v=rot(v)^x;
      }
    }
    CK(cudaMemcpy(out.data(),dc,nc*4,cudaMemcpyDeviceToHost));CK(cudaMemcpy(got.data(),dt,nt*4,cudaMemcpyDeviceToHost));
    int ce=0,te=0;for(size_t i=0;i<nc;++i)ce+=ref[i]!=out[i];for(size_t i=0;i<nt;++i)te+=tr[i]!=got[i];
    printf("correctness K=%d matrix_mismatches=%d transcript_mismatches=%d\n",K,ce,te);if(ce||te)return 5;
    CK(cudaLaunchKernelEx(&cfg,rank_probe<false>,ta,tb,dc,dt,M,N,K,pattern==4,swizzle_group,verify?uint32_t(nt/16):1024u));CK(cudaGetLastError());CK(cudaDeviceSynchronize());
    CK(cudaMemcpy(got.data(),dt,nt*4,cudaMemcpyDeviceToHost));
    te=0;for(size_t i=0;i<nt;++i)te+=tr[i]!=got[i];
    printf("no_C_variant K=%d transcript_mismatches=%d\n",K,te);if(te)return 6;
    CK(cudaMemset(dt,0,(nt+16)*4));
    CK(cudaLaunchKernelEx(&cfg,rank_probe<false,true>,ta,tb,dc,dt,M,N,K,pattern==4,swizzle_group,verify?uint32_t(nt/16):1024u));CK(cudaGetLastError());CK(cudaDeviceSynchronize());
    uint32_t hit_count;CK(cudaMemcpy(&hit_count,dt,4,cudaMemcpyDeviceToHost));if(hit_count>nt/16)return 9;
    std::vector<uint32_t> hits(16+size_t(hit_count)*16);CK(cudaMemcpy(hits.data(),dt,hits.size()*4,cudaMemcpyDeviceToHost));
    export_words(std::string(export_prefix)+"-cpu-transcripts.bin",tr);
    export_words(std::string(export_prefix)+"-gpu-hits.bin",hits);
    export_words(std::string(export_prefix)+"-config.bin",config);
    printf("fused_hash_gate exported %zu independent CPU transcripts and GPU hash/target records\n",nt/16);
  }
  if(!verify){int warm=getenv("PROBE_WARMUP_SECONDS")?atoi(getenv("PROBE_WARMUP_SECONDS")):2;if(warm<2||warm>15)return 3;auto until=std::chrono::steady_clock::now()+std::chrono::seconds(warm);do{for(int i=0;i<10;++i)launch();CK(cudaDeviceSynchronize());}while(std::chrono::steady_clock::now()<until);}
  cudaEvent_t start,end;CK(cudaEventCreate(&start));CK(cudaEventCreate(&end));
  CK(cudaEventRecord(start));for(int r=0;r<reps;++r)launch();CK(cudaEventRecord(end));CK(cudaEventSynchronize(end));
  float ms;CK(cudaEventElapsedTime(&ms,start,end));ms/=reps;
  printf("probe_core_plus_blake3_target_hitqueue_not_full_miner M=%d N=%d K=%d ms=%.6f integer_TOPS=%.3f not_pool_hashrate=1\n",M,N,K,ms,2.0*M*N*K/(ms*1e9));
  if(!verify){uint32_t hits;CK(cudaMemcpy(&hits,dt,4,cudaMemcpyDeviceToHost));if(hits>1024)return 9;printf("timed_last_pass_hits=%u target_is_offline_zero\n",hits);}
  CK(cudaFree(da));CK(cudaFree(db));CK(cudaFree(dc));CK(cudaFree(dt));
}
