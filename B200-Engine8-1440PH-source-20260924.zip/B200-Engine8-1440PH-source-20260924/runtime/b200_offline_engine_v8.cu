// v8: core135 with explicit acknowledgment from both producer warps.
// v7: core130, leader TMA/readers completion without ready rendezvous.
// v6: barrier-init publication candidate; no diagnostic host stage synchronizations.
// v4: exact v125 fused core, configurable independently verified noise-application layout.
// v3: disabled noise outputs also require zero lengths, matching upstream host wrapper.
// PREPARED ONLY: depends on separately validated safe tensor-hash port v4.
// Offline full-pass backend, one context per process, GPU0 selected by runner.
// No sockets, wallet, pool submission, driver/power/clock control.
#define main wide_probe_unused_main
#include "sm100_rank_probe_v135.cu"
#undef main
#undef CK
#define main tensorhash_probe_unused_main
#include "tensorhash_port_probe_v4.cu"
#undef main
#undef CK
#define CK(call) do {cudaError_t engine_cuda_error=(call);if(engine_cuda_error!=cudaSuccess){fprintf(stderr,"%s: %s\n",#call,cudaGetErrorString(engine_cuda_error));exit(2);}}while(0)

#include "noise_rows8_kernel_v6.cuh"
struct Engine {
 int m,n,k,group;bool job=false,cached=false,rows8=false;
 int8_t *a,*b,*na,*nb,*eal,*ebr,*ear,*ebl;
 uint16_t *ia,*ib;int* errors;
 uint8_t *key,*sa,*sb,*ca,*cb,*scratcha,*scratchb;
 uint32_t *hits;uint32_t blocks_a,blocks_b;
 TA ta;TB tb;cudaLaunchConfig_t cfg{};cudaLaunchAttribute attr{};
};
static Engine* active=nullptr;
static void reduce_cache(uint8_t* scratch,uint32_t blocks){
 uint32_t count=(blocks+511)/512;
 if(count==1)launch<pearl::ComputeBlakeMTKernel<512,true>>({reinterpret_cast<uint32_t*>(scratch),blocks});
 else{
  launch<pearl::ComputeBlakeMTKernel<512,false>>({reinterpret_cast<uint32_t*>(scratch),blocks});
  launch<pearl::ReduceRootsKernel<128>>({reinterpret_cast<uint32_t*>(scratch),count});
 }
}
static void commitment(Engine& e,bool cold){
 uint32_t ab=uint32_t(size_t(e.m)*e.k),bb=uint32_t(size_t(e.n)*e.k);
 if(cold){
  launch<pearl::SimpleMerkleRootsKernel<false>>({reinterpret_cast<uint8_t*>(e.a),ab,e.ca});
  launch<pearl::SimpleMerkleRootsKernel<false>>({reinterpret_cast<uint8_t*>(e.b),bb,e.cb});
  CK(cudaMemcpyAsync(e.scratchb,e.cb,size_t(e.blocks_b)*32,cudaMemcpyDeviceToDevice));
  reduce_cache(e.scratchb,e.blocks_b);
 }else{
  launch<pearl::SimpleMerkleRootsKernel<false>>({reinterpret_cast<uint8_t*>(e.a),131072,e.ca});
 }
 CK(cudaMemcpyAsync(e.scratcha,e.ca,size_t(e.blocks_a)*32,cudaMemcpyDeviceToDevice));
 reduce_cache(e.scratcha,e.blocks_a);
 launch<pearl::CommitmentHashFromMerkleRootsKernel>({e.scratcha,e.scratchb,e.key,e.sa,e.sb,nullptr,nullptr,true,uint32_t(e.m),uint32_t(e.n)});
 CK(cudaMemcpyToSymbolAsync(probe_pow_key,e.sa,32,0,cudaMemcpyDeviceToDevice));
}
static void noising(Engine& e,bool cold){
 using Gen=pearl::NoiseGenerationKernel<128,128>;
 Gen::Arguments args{.ptr_EAL=e.eal,.ptr_EAL_fp16=nullptr,.ptr_EAR_R_major=e.ear,.ptr_EAR_K_major=nullptr,
  .ptr_EBL_R_major=cold?e.ebl:nullptr,.ptr_EBL_K_major=nullptr,.ptr_EBR=cold?e.ebr:nullptr,.ptr_EBR_fp16=nullptr,
  .num_rows_EAL=e.m,.length_EAR=e.k,.length_EBL=cold?e.k:0,.num_rows_EBR=cold?e.n:0,
  .ptr_key_A=e.sa,.ptr_key_B=e.sb,.ptr_aux_buffer=nullptr,.aux_buffer_size=0};
 launch<Gen>(args);
 CK(cudaMemsetAsync(e.errors,0,4));
 sparse_indices<<<(e.k+255)/256,256>>>(e.ear,e.ia,e.k,e.errors);
 if(e.rows8)apply_sparse_rows8<<<(e.m+7)/8,256>>>(e.a,e.eal,e.ia,e.na,e.m,e.k);
 else apply_sparse<<<e.m,256>>>(e.a,e.eal,e.ia,e.na,e.m,e.k);
 if(cold){
  sparse_indices<<<(e.k+255)/256,256>>>(e.ebl,e.ib,e.k,e.errors);
  if(e.rows8)apply_sparse_rows8<<<(e.n+7)/8,256>>>(e.b,e.ebr,e.ib,e.nb,e.n,e.k);
  else apply_sparse<<<e.n,256>>>(e.b,e.ebr,e.ib,e.nb,e.n,e.k);
 }
 CK(cudaGetLastError());
}
extern "C" int engine_init(int m,int n,int k,int group){
 if(active||m<256||m>131072||m%256||n<256||n>262144||n%256||k<2048||k>32256||k%128||group<1||group>64)return 1;
 if(size_t(n)*k>0xffffffffULL||size_t(m)*k>0xffffffffULL||size_t(130)*k>(1<<22))return 2;
 cudaDeviceProp p;CK(cudaGetDeviceProperties(&p,0));if(p.major!=10)return 3;
 auto* e=new Engine{};e->m=m;e->n=n;e->k=k;e->group=group;
 e->a=alloc<int8_t>(size_t(m)*k);e->b=alloc<int8_t>(size_t(n)*k);
 e->na=alloc<int8_t>(size_t(m)*k);e->nb=alloc<int8_t>(size_t(n)*k);
 e->eal=alloc<int8_t>(size_t(m)*128);e->ebr=alloc<int8_t>(size_t(n)*128);
 e->ear=alloc<int8_t>(size_t(k)*128);e->ebl=alloc<int8_t>(size_t(k)*128);
 e->ia=alloc<uint16_t>(k);e->ib=alloc<uint16_t>(k);e->errors=alloc<int>(1);
 e->key=alloc<uint8_t>(32);e->sa=alloc<uint8_t>(32);e->sb=alloc<uint8_t>(32);
 e->blocks_a=(size_t(m)*k+131071)/131072;e->blocks_b=(size_t(n)*k+131071)/131072;
 e->ca=alloc<uint8_t>(size_t(e->blocks_a)*32);e->cb=alloc<uint8_t>(size_t(e->blocks_b)*32);
 e->scratcha=alloc<uint8_t>(size_t(e->blocks_a)*32);e->scratchb=alloc<uint8_t>(size_t(e->blocks_b)*32);
 e->hits=alloc<uint32_t>(16+1024*16);
 CK(cudaMemset(e->a,64,size_t(m)*k));CK(cudaMemset(e->b,64,size_t(n)*k));
 auto ma=make_tensor(make_gmem_ptr(e->na),make_layout(make_shape(m,k),make_stride(k,_1{})));
 auto mb=make_tensor(make_gmem_ptr(e->nb),make_layout(make_shape(n,k),make_stride(k,_1{})));
 e->ta=make_tma_atom(SM90_TMA_LOAD{},ma,SFA{},Shape<_128,_128>{});
 e->tb=make_tma_atom(SM90_TMA_LOAD{},mb,SFB{},Shape<_128,_128>{});
 e->cfg.gridDim=dim3(m/128,n/256);e->cfg.blockDim=dim3(160);e->cfg.dynamicSmemBytes=sizeof(Smem);
 e->attr.id=cudaLaunchAttributeClusterDimension;e->attr.val.clusterDim.x=2;e->attr.val.clusterDim.y=1;e->attr.val.clusterDim.z=1;
 e->cfg.attrs=&e->attr;e->cfg.numAttrs=1;
 CK(cudaFuncSetAttribute(rank_probe<false,true>,cudaFuncAttributeMaxDynamicSharedMemorySize,sizeof(Smem)));
 active=e;return 0;
}
extern "C" int engine_job(const uint8_t* key,const uint8_t* target){
 if(!active||!key||!target)return 1;
 CK(cudaMemcpy(active->key,key,32,cudaMemcpyHostToDevice));CK(cudaMemcpyToSymbol(c_key,key,32));
 CK(cudaMemcpyToSymbol(probe_pow_target,target,32));active->job=true;active->cached=false;return 0;
}
// meta = raw roots A/B followed by noise seeds A/B (128 bytes).
// hits = 64-byte count header then bounded 64-byte records. No silent truncation.
extern "C" int engine_pass(const uint8_t* nonce,uint8_t* meta,uint32_t* hits,double* elapsed){
 if(!active||!active->job||!nonce||!meta||!hits||!elapsed)return 1;
 auto& e=*active;CK(cudaDeviceSynchronize());auto start=std::chrono::steady_clock::now();
 CK(cudaMemcpyAsync(e.a,nonce,10,cudaMemcpyHostToDevice));
 commitment(e,!e.cached);noising(e,!e.cached);
 CK(cudaMemsetAsync(e.hits,0,16*4));
 CK(cudaLaunchKernelEx(&e.cfg,rank_probe<false,true>,e.ta,e.tb,static_cast<int32_t*>(nullptr),e.hits,e.m,e.n,e.k,true,e.group,1024u));
 CK(cudaDeviceSynchronize());int errors;CK(cudaMemcpy(&errors,e.errors,4,cudaMemcpyDeviceToHost));if(errors)return 2;
 uint32_t count;CK(cudaMemcpy(&count,e.hits,4,cudaMemcpyDeviceToHost));if(count>1024)return 3;
 CK(cudaMemcpy(hits,e.hits,size_t(16+count*16)*4,cudaMemcpyDeviceToHost));
 CK(cudaMemcpy(meta,e.scratcha,32,cudaMemcpyDeviceToHost));CK(cudaMemcpy(meta+32,e.scratchb,32,cudaMemcpyDeviceToHost));
 CK(cudaMemcpy(meta+64,e.sa,32,cudaMemcpyDeviceToHost));CK(cudaMemcpy(meta+96,e.sb,32,cudaMemcpyDeviceToHost));
 *elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();e.cached=true;return 0;
}
extern "C" int engine_roots(int which,uint8_t* out,size_t bytes){
 if(!active||!active->cached||!out||(which!=0&&which!=1))return 1;
 auto& e=*active;size_t want=size_t(which?e.blocks_b:e.blocks_a)*32;
 if(bytes!=want)return 2;CK(cudaMemcpy(out,which?e.cb:e.ca,want,cudaMemcpyDeviceToHost));return 0;
}
extern "C" int engine_close(){
 if(!active)return 0;auto& e=*active;CK(cudaDeviceSynchronize());
 void* p[]={e.a,e.b,e.na,e.nb,e.eal,e.ebr,e.ear,e.ebl,e.ia,e.ib,e.errors,e.key,e.sa,e.sb,e.ca,e.cb,e.scratcha,e.scratchb,e.hits};
 for(void* v:p)CK(cudaFree(v));delete active;active=nullptr;return 0;
}
extern "C" int engine_noise_rows(int rows){if(!active||(rows!=1&&rows!=8))return 1;active->rows8=(rows==8);return 0;}
extern "C" int engine_target(const uint8_t* target){if(!active||!target)return 1;CK(cudaMemcpyToSymbol(probe_pow_target,target,32));return 0;}
