"""Transport extracted from frozen 0.6.2, no GPU/dependency imports.
Original SHA256: 08fb7ac460fe3d6543e500a59a55bc3ef049c88a5451111b6e25cbecf3800f5b.
Changes: distinct version; bounded16-item queue for all valid hits; log accepted
difficulty-weighted work and error text. TLS verification remains mandatory.
Importing this module does not connect to any server.
"""
from __future__ import annotations
import base64,gzip,json,os,queue,select,socket,ssl,sys,threading,time
from dataclasses import dataclass
from datetime import datetime,timezone
from enum import IntEnum
from pathlib import Path
from typing import Any
class CertificateVersion(IntEnum):
    V3=3

VERSION = "b200-experimental-v1"
DEFAULT_HOST = "prl-us.kryptex.network"
DEFAULT_PORT = 8048
DEFAULT_M = 131072
DEFAULT_N = 262144
DEFAULT_K = 8192
DEFAULT_RANK = 128
NONCE_WIDTH = 10
MERKLE_LEAF_BYTES = 1024
TENSOR_HASH_THREADS = 128
TENSOR_HASH_REDUCTION_LEAVES = 512
TENSOR_HASH_SUBTREE_HEIGHT = 7
MERKLE_DIGEST_BYTES = 32
MAX_PROTOCOL_LINE = 1 << 20
MAX_PENDING_SUBMISSIONS = 16
HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
DEFAULT_AUTH_TIMEOUT = 20.0
DEFAULT_RECEIVE_TIMEOUT = 90.0
DEFAULT_JOB_TIMEOUT = 90.0
DEFAULT_SUBMIT_TIMEOUT = 30.0


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace(
        "+00:00", "Z"
    )


class EventLogger:
    def __init__(self, path: str | None) -> None:
        self._path = Path(path) if path else None
        self._lock = threading.Lock()
        if self._path is not None:
            self._path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, event: str, **fields: Any) -> None:
        record = {"timestamp": utc_now(), "event": event, **fields}
        line = json.dumps(record, separators=(",", ":"), sort_keys=True)
        with self._lock:
            try:
                print(line, flush=True)
            except (BrokenPipeError, OSError):
                pass
            if self._path is not None:
                try:
                    with self._path.open("a", encoding="utf-8") as handle:
                        handle.write(line + "\n")
                except OSError as exc:
                    failed_path = str(self._path)
                    self._path = None
                    try:
                        print(
                            json.dumps(
                                {
                                    "timestamp": utc_now(),
                                    "event": "log_file_disabled",
                                    "path": failed_path,
                                    "error_type": type(exc).__name__,
                                },
                                separators=(",", ":"),
                                sort_keys=True,
                            ),
                            file=sys.stderr,
                            flush=True,
                        )
                    except (BrokenPipeError, OSError):
                        pass


@dataclass(frozen=True)
class JobSnapshot:
    connection_epoch: int
    job_epoch: int
    job_id: str
    header: bytes
    target: int
    share_nbits: int
    cert_version: CertificateVersion
    height: int | None

    @property
    def epoch(self) -> tuple[int, int]:
        return self.connection_epoch, self.job_epoch


@dataclass(frozen=True)
class Submission:
    job: JobSnapshot
    hs: int
    plain_proof: str


@dataclass(frozen=True)
class PendingSubmission:
    submission: Submission
    sent_at: float


class StratumClient:
    """Own the TLS socket and expose only immutable jobs/submissions."""

    def __init__(
        self,
        *,
        host: str,
        port: int,
        wallet_worker: str,
        logger: EventLogger,
        stop_event: threading.Event,
        reconnect_seconds: float,
        auth_timeout: float = DEFAULT_AUTH_TIMEOUT,
        receive_timeout: float = DEFAULT_RECEIVE_TIMEOUT,
        job_timeout: float = DEFAULT_JOB_TIMEOUT,
        submit_timeout: float = DEFAULT_SUBMIT_TIMEOUT,
        loopback_relay_port: int | None = None,
    ) -> None:
        self.host = host
        self.port = port
        self._wallet_worker = wallet_worker
        self.logger = logger
        self.stop_event = stop_event
        self.reconnect_seconds = reconnect_seconds
        self.auth_timeout = auth_timeout
        self.receive_timeout = receive_timeout
        self.job_timeout = job_timeout
        self.submit_timeout = submit_timeout
        if loopback_relay_port is not None and (type(loopback_relay_port) is not int or not 1 <= loopback_relay_port <= 65535):
            raise ValueError("loopback relay port must be an integer in 1..65535")
        self.loopback_relay_port = loopback_relay_port
        self._condition = threading.Condition()
        self._socket: ssl.SSLSocket | socket.socket | None = None
        self._connection_epoch = 0
        self._job_epoch = 0
        self._latest_job: JobSnapshot | None = None
        self._authorized = False
        self._outgoing: queue.Queue[Submission] = queue.Queue(maxsize=16)
        from b200_submit_wakeup_v1 import SubmissionWakeup
        self._wakeup = SubmissionWakeup()
        self._thread = threading.Thread(
            target=self._run, name="kryptex-stratum", daemon=True
        )
        self._accepted = 0
        self._accepted_work = 0.0
        self._rejected = 0
        self._stale_dropped = 0
        self._response_unknown = 0

    def start(self) -> None:
        try:
            self._thread.start()
        except Exception:
            # A duplicate start must not close descriptors owned by a live thread.
            if not self._thread.is_alive():
                self._wakeup.close()
            raise

    def stop(self) -> None:
        self.stop_event.set()
        self._wakeup.notify()
        with self._condition:
            self._condition.notify_all()
            sock = self._socket
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass
        self._thread.join(timeout=20)
        if not self._thread.is_alive():
            self._wakeup.close()

    def stats(self) -> dict[str, int]:
        with self._condition:
            return {
                "accepted": self._accepted,
                "accepted_work": self._accepted_work,
                "rejected": self._rejected,
                "stale_dropped": self._stale_dropped,
                "response_unknown": self._response_unknown,
            }

    def is_current(self, job: JobSnapshot) -> bool:
        with self._condition:
            return self._authorized and self._latest_job == job

    def wait_for_new_job(
        self, previous_epoch: tuple[int, int] | None, timeout: float
    ) -> JobSnapshot | None:
        deadline = time.monotonic() + timeout
        with self._condition:
            while not self.stop_event.is_set():
                if (
                    self._authorized
                    and self._latest_job is not None
                    and self._latest_job.epoch != previous_epoch
                ):
                    return self._latest_job
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                self._condition.wait(remaining)
        return None

    def queue_submission(self, submission: Submission) -> bool:
        if not self.is_current(submission.job):
            with self._condition:
                self._stale_dropped += 1
            self.logger.emit(
                "submission_dropped_stale", job_id=submission.job.job_id
            )
            return False
        try:
            self._outgoing.put_nowait(submission)
        except queue.Full:
            self.logger.emit(
                "submission_dropped_queue_full", job_id=submission.job.job_id
            )
            return False
        self._wakeup.notify()
        return True

    def _drop_queued_submissions(self, reason: str) -> int:
        dropped = 0
        while True:
            try:
                self._outgoing.get_nowait()
                dropped += 1
            except queue.Empty:
                break
        if dropped:
            with self._condition:
                self._stale_dropped += dropped
            self.logger.emit(
                "queued_submissions_dropped", count=dropped, reason=reason
            )
        return dropped

    def _set_disconnected(self) -> None:
        with self._condition:
            self._authorized = False
            self._latest_job = None
            self._socket = None
            self._condition.notify_all()
        self._drop_queued_submissions("disconnected")

    def _run(self) -> None:
        context = ssl.create_default_context()
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        while not self.stop_event.is_set():
            try:
                self._connection_loop(context)
            except Exception as exc:
                if not self.stop_event.is_set():
                    self.logger.emit(
                        "stratum_connection_error",
                        error_type=type(exc).__name__,
                        error=str(exc)[:300],
                    )
            finally:
                self._set_disconnected()
            self.stop_event.wait(self.reconnect_seconds)

    @staticmethod
    def _send_message(sock: ssl.SSLSocket, message: dict[str, Any]) -> None:
        encoded = (
            json.dumps(message, separators=(",", ":"), ensure_ascii=True).encode()
            + b"\n"
        )
        sock.sendall(encoded)

    def _connection_loop(self, context: ssl.SSLContext) -> None:
        endpoint = ("127.0.0.1", self.loopback_relay_port) if self.loopback_relay_port is not None else (self.host, self.port)
        raw_socket = socket.create_connection(endpoint, timeout=15)
        raw_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        for option_name, value in (
            ("TCP_KEEPIDLE", 30),
            ("TCP_KEEPINTVL", 10),
            ("TCP_KEEPCNT", 3),
            ("TCP_USER_TIMEOUT", 45_000),
        ):
            option = getattr(socket, option_name, None)
            if option is not None:
                raw_socket.setsockopt(socket.IPPROTO_TCP, option, value)
        try:
            sock = raw_socket if self.loopback_relay_port is not None else context.wrap_socket(raw_socket, server_hostname=self.host)
        except Exception:
            raw_socket.close()
            raise
        with sock:
            sock.settimeout(2)
            with self._condition:
                self._connection_epoch += 1
                connection_epoch = self._connection_epoch
                self._job_epoch = 0
                self._authorized = False
                self._latest_job = None
                self._socket = sock
            self.logger.emit(
                "stratum_connected",
                host=self.host,
                port=self.port,
                tls_version=sock.version() if hasattr(sock, "version") else "LOOPBACK-RELAY",
                loopback_relay_port=self.loopback_relay_port,
                connection_epoch=connection_epoch,
            )
            self._send_message(
                sock,
                {
                    "id": 1,
                    "method": "mining.authorize",
                    "params": {
                        "wallet": self._wallet_worker,
                        "agent": f"PearlB200-Experimental/{VERSION}",
                        "type": "v2",
                    },
                },
            )
            buffer = bytearray()
            next_request_id = 2
            pending: dict[int, PendingSubmission] = {}
            connected_at = time.monotonic()
            last_rx = connected_at
            authorized_at: float | None = None
            last_work_confirmed_at: float | None = None

            try:
                while not self.stop_event.is_set():
                    readable, _, exceptional = select.select(
                        [sock, self._wakeup.reader], [], [sock], 0.1
                    )
                    if self._wakeup.reader in readable:
                        self._wakeup.drain()
                    if self.stop_event.is_set():
                        break
                    if exceptional:
                        raise ConnectionError("TLS socket entered exceptional state")
                    if sock in readable or getattr(sock, "pending", lambda: 0)() > 0:
                        while True:
                            try:
                                chunk = sock.recv(64 * 1024)
                            except (
                                BlockingIOError,
                                socket.timeout,
                                ssl.SSLWantReadError,
                            ):
                                break
                            if not chunk:
                                raise ConnectionError("pool closed the TLS connection")
                            last_rx = time.monotonic()
                            buffer.extend(chunk)
                            while b"\n" in buffer:
                                raw_line, _, remainder = buffer.partition(b"\n")
                                buffer = bytearray(remainder)
                                if len(raw_line) > MAX_PROTOCOL_LINE:
                                    raise ValueError(
                                        "pool sent an oversized protocol line"
                                    )
                                if raw_line.endswith(b"\r"):
                                    raw_line = raw_line[:-1]
                                if raw_line:
                                    event = self._handle_message(
                                        json.loads(raw_line),
                                        connection_epoch,
                                        pending,
                                    )
                                    if event == "authorized":
                                        authorized_at = last_rx
                                    elif event in ("job", "accepted_current"):
                                        # An accepted share for the current job confirms
                                        # useful work even when a block takes >90 seconds.
                                        # Old-job, rejected and unknown replies do not.
                                        last_work_confirmed_at = last_rx
                            if len(buffer) > MAX_PROTOCOL_LINE:
                                raise ValueError(
                                    "pool sent an oversized unterminated line"
                                )
                            if getattr(sock, "pending", lambda: 0)() == 0:
                                break

                    now = time.monotonic()
                    with self._condition:
                        authorized = self._authorized
                    if not authorized and now - connected_at > self.auth_timeout:
                        raise TimeoutError("pool authorization timed out")
                    if now - last_rx > self.receive_timeout:
                        raise TimeoutError("pool receive watchdog expired")
                    if authorized:
                        job_reference = last_work_confirmed_at or authorized_at or connected_at
                        if now - job_reference > self.job_timeout:
                            raise TimeoutError("pool job watchdog expired")

                    expired_ids = [
                        request_id
                        for request_id, item in pending.items()
                        if now - item.sent_at > self.submit_timeout
                    ]
                    for request_id in expired_ids:
                        item = pending.pop(request_id)
                        with self._condition:
                            self._response_unknown += 1
                        self.logger.emit(
                            "share_response_timeout",
                            request_id=request_id,
                            job_id=item.submission.job.job_id,
                        )

                    if len(pending) >= MAX_PENDING_SUBMISSIONS:
                        continue
                    try:
                        submission = self._outgoing.get_nowait()
                    except queue.Empty:
                        continue
                    if not self.is_current(submission.job):
                        with self._condition:
                            self._stale_dropped += 1
                        self.logger.emit(
                            "submission_dropped_stale",
                            job_id=submission.job.job_id,
                        )
                        continue
                    request_id = next_request_id
                    next_request_id += 1
                    self._send_message(
                        sock,
                        {
                            "id": request_id,
                            "method": "mining.submit",
                            "params": {
                                "hs": submission.hs,
                                "job_id": submission.job.job_id,
                                "plain_proof": submission.plain_proof,
                            },
                        },
                    )
                    pending[request_id] = PendingSubmission(submission, now)
                    self.logger.emit(
                        "share_submitted",
                        request_id=request_id,
                        job_id=submission.job.job_id,
                        hs=submission.hs,
                        proof_chars=len(submission.plain_proof),
                    )
            finally:
                if pending:
                    with self._condition:
                        self._response_unknown += len(pending)
                    self.logger.emit(
                        "share_responses_unknown",
                        count=len(pending),
                        reason="connection_closed",
                    )
                with self._condition:
                    if self._socket is sock:
                        self._socket = None

    def _handle_message(
        self,
        message: Any,
        connection_epoch: int,
        pending: dict[int, PendingSubmission],
    ) -> str | None:
        if not isinstance(message, dict):
            raise ValueError("pool message is not a JSON object")
        if message.get("id") == 1:
            if message.get("result") is not True or message.get("error") is not None:
                raise PermissionError("pool rejected authorization")
            with self._condition:
                self._authorized = True
                self._condition.notify_all()
            self.logger.emit("stratum_authorized", connection_epoch=connection_epoch)
            return "authorized"

        method = message.get("method")
        if method == "mining.notify":
            params = message.get("params")
            if not isinstance(params, dict):
                raise ValueError("mining.notify params are not an object")
            header_hex = params.get("header")
            target_hex = params.get("target")
            job_id = params.get("job_id")
            cert_raw = params.get("cert_version")
            if (
                not isinstance(header_hex, str)
                or len(header_hex) != 152
                or any(character not in HEX_DIGITS for character in header_hex)
            ):
                raise ValueError("notify header is not 76-byte hex")
            if (
                not isinstance(target_hex, str)
                or len(target_hex) != 64
                or any(character not in HEX_DIGITS for character in target_hex)
            ):
                raise ValueError("notify target is not 32-byte hex")
            if not isinstance(job_id, str) or not job_id or len(job_id) > 256:
                raise ValueError("notify job_id is invalid")
            if type(cert_raw) is not int:
                raise ValueError("notify certificate version is not an integer")
            cert_version = CertificateVersion(cert_raw)
            if int(cert_version) != 3:
                raise ValueError(f"unsupported certificate version {int(cert_version)}")
            header = bytes.fromhex(header_hex)
            target = int(target_hex, 16)
            if target == 0:
                raise ValueError("notify target cannot be zero")
            share_nbits = target_to_compact(target)
            height_raw = params.get("height")
            height = height_raw if type(height_raw) is int else None
            with self._condition:
                if connection_epoch != self._connection_epoch:
                    return
                self._job_epoch += 1
                snapshot = JobSnapshot(
                    connection_epoch=connection_epoch,
                    job_epoch=self._job_epoch,
                    job_id=job_id,
                    header=header,
                    target=target,
                    share_nbits=share_nbits,
                    cert_version=cert_version,
                    height=height,
                )
                self._latest_job = snapshot
                self._condition.notify_all()
            self._drop_queued_submissions("new_job")
            self.logger.emit(
                "mining_job",
                job_id=job_id,
                height=height,
                cert_version=int(cert_version),
                share_nbits=f"{share_nbits:08x}",
                connection_epoch=connection_epoch,
                job_epoch=snapshot.job_epoch,
            )
            return "job"

        response_id = message.get("id")
        if isinstance(response_id, int) and response_id in pending:
            submission = pending.pop(response_id).submission
            accepted = message.get("result") is True and message.get("error") is None
            with self._condition:
                if accepted:
                    self._accepted += 1
                    self._accepted_work += (1 << 256) / (compact_to_target(submission.job.share_nbits) + 1)
                else:
                    self._rejected += 1
                totals = (self._accepted, self._rejected)
            error = message.get("error")
            self.logger.emit(
                "share_response",
                request_id=response_id,
                job_id=submission.job.job_id,
                accepted=accepted,
                accepted_total=totals[0],
                rejected_total=totals[1],
                error_type=type(error).__name__ if error is not None else None,
                error=str(error)[:200] if error is not None else None,
                share_target=str(compact_to_target(submission.job.share_nbits)),
                expected_work=(1 << 256) / (compact_to_target(submission.job.share_nbits) + 1),
            )
            return "accepted_current" if accepted and self.is_current(submission.job) else "response"
        return None


def encode_base128_nonce(value: int, width: int = NONCE_WIDTH) -> list[int]:
    if value < 0:
        raise ValueError("nonce must be non-negative")
    result: list[int] = []
    for _ in range(width):
        result.append((value & 0x7F) - 64)
        value >>= 7
    if value:
        raise ValueError("nonce counter exhausted its base-128 field")
    return result


def target_to_compact(target: int) -> int:
    """Encode a positive uint256 target using Bitcoin's compact format."""
    if type(target) is not int or not 0 < target < (1 << 256):
        raise ValueError("target must be a positive uint256")
    size = (target.bit_length() + 7) // 8
    if size <= 3:
        compact = target << (8 * (3 - size))
    else:
        compact = target >> (8 * (size - 3))
    if compact & 0x00800000:
        compact >>= 8
        size += 1
    return compact | (size << 24)


def compact_to_target(compact: int) -> int:
    """Decode a positive Bitcoin compact target without gateway edge cases."""
    if type(compact) is not int or not 0 < compact <= 0xFFFFFFFF:
        raise ValueError("compact target must be a positive uint32")
    if compact & 0x00800000:
        raise ValueError("negative compact targets are unsupported")
    size = compact >> 24
    mantissa = compact & 0x007FFFFF
    if size <= 3:
        target = mantissa >> (8 * (3 - size))
    else:
        target = mantissa << (8 * (size - 3))
    if not 0 < target < (1 << 256):
        raise ValueError("decoded compact target is not a positive uint256")
    return target


def encode_kryptex_proof(proof: Any) -> str:
    current = base64.b64decode(proof.to_base64(), validate=True)
    if getattr(proof, "moe", None) is not None or current[-1:] != b"\x00":
        raise ValueError("dense proof is missing the expected trailing moe=None tag")
    legacy = current[:-1]
    compressed = gzip.compress(legacy, compresslevel=1, mtime=0)
    return base64.b64encode(compressed).decode("ascii")
