import fcntl,json,os,signal,subprocess,time
from pathlib import Path
r=Path('/home/jupyter-b200/pearl-b200-20260924-v1');os.chdir(r)
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-af7a73cd-3032-50a8-c5a5-21c5bab963d7')
env['LD_LIBRARY_PATH']='/usr/local/cuda/lib64:'+env.get('LD_LIBRARY_PATH','')
def run(args,log,timeout,telemetry=False):
 with (r/log).open('x') as out:
  monitor=None;f=None
  if telemetry:
   f=(r/(log.removesuffix('.log')+'-telemetry.csv')).open('x')
   monitor=subprocess.Popen(['nvidia-smi','-i','0','--query-gpu=timestamp,utilization.gpu,power.draw,clocks.sm,temperature.gpu','--format=csv','-lms','200'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   p=subprocess.Popen(args,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=timeout)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();raise
  finally:
   if monitor:
    if monitor.poll() is None:monitor.terminate()
    try:monitor.wait(timeout=10)
    except subprocess.TimeoutExpired:monitor.kill();monitor.wait()
    f.close()
 if code:raise RuntimeError(f'{log}: exit {code}')
with (r/'gpu0.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state={'started':time.time(),'pid':os.getpid(),'state':'running','offline_only':True}
 try:
  for tag in ('tensorhash-v4','tensorhash-v5','offline-v118','noise-v6','noise-bench-v7','build-v135'):
   assert json.loads((r/(tag+'-status.json')).read_text())['state']=='passed',f'{tag} gate not passed'
  assert not (r/'b200_offline_engine_v8.so').exists()
  run(['/usr/local/cuda/bin/nvcc','-std=c++20','-O3','-shared','--cudart','shared','-Xcompiler','-fPIC','-Xptxas=-v','-gencode=arch=compute_100a,code=sm_100a','--expt-relaxed-constexpr','-Isource/cutlass/include','-Isource/frozen-csrc','b200_offline_engine_v8.cu','-o','b200_offline_engine_v8.so','-lcuda'],'offline-engine-v8-compile.log',240)
  state['library']='b200_offline_engine_v8.so';state['gate']='offline_engine_gate_v8.py'
  for rows in (1,8):
   for mode in ('plain','memcheck','synccheck','racecheck'):
    cmd=['venv/bin/python','offline_engine_gate_v8.py','--noise-rows',str(rows),'--k','2048','--steps','32']
    if mode!='plain':cmd=['/usr/local/cuda/bin/compute-sanitizer','--tool',mode,'--error-exitcode','9']+cmd
    run(cmd,f'offline-engine-v8-noise{rows}-k2048-{mode}.log',240)
   run(['venv/bin/python','offline_engine_gate_v8.py','--noise-rows',str(rows),'--k','8192','--steps','8'],f'offline-engine-v8-noise{rows}-k8192-plain.log',240)
  run(['venv/bin/python','offline_engine_gate_v8.py','--noise-rows','8','--m','131072','--n','259584','--k','8192','--steps','8','--nbits','0x1b040000'],'offline-engine-v8-expanded-native.log',300)
  with (r/'offline-engine-v8-native-gates.json').open('x') as f:json.dump({'state':'passed','finished':time.time()},f)
  for trial,version in enumerate((6,8,8,6)):
   run(['venv/bin/python','offline_continuous_engine_v8.py','--library',f'b200_offline_engine_v{version}.so','--noise-rows','1','--seconds','90'],f'offline-engine-v8-abba-{trial}-engine{version}.log',180,True)
  state['state']='passed'
 except Exception as e:state.update(state='failed',error=str(e))
 state['finished']=time.time()
 with (r/'offline-engine-v8-status.json').open('x') as f:json.dump(state,f,indent=2)
