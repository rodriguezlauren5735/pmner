"""Explicitly launched only after reviewing group-sweep results. One GPU,600s."""
import csv,json,os,signal,subprocess,time
from pathlib import Path
r=Path('/home/jupyter-b200/pearl-b200-20260924-v1');os.chdir(r)
assert json.loads((r/'offline-engine-v8-status.json').read_text())['state']=='passed'
assert json.loads((r/'adapter-cpu-tests-v2-status.json').read_text())['exit']==0
sweep=json.loads((r/'group-sweep-v8-status.json').read_text());assert sweep['state']=='passed'
best=max(sweep['results'],key=lambda x:x['full_pass_wall_tmad_s'])
# A short-screening threshold, NOT a declaration of stable performance.
assert best['full_pass_wall_tmad_s']>1435,'screening candidate has not exceeded reference sufficiently'
assert best['m'] in (32768,131072) and best['group'] in (12,14,16,18,20,22,24)
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-af7a73cd-3032-50a8-c5a5-21c5bab963d7')
env['LD_LIBRARY_PATH']='/usr/local/cuda/lib64:'+env.get('LD_LIBRARY_PATH','')
state={'started':time.time(),'pid':os.getpid(),'state':'running','selection':best,'seconds':600}
child=None
try:
 args=['venv/bin/python','-B','b200_pool_adapter_v2.py','--wallet','prl1prkwvvvwlfql5eakdn4t0ja7zjtgyzgptnjswmaw8rak7atrzyjpq2xvkzg','--worker','b200v8check','--host','prl-us.kryptex.network','--port','8048','--seconds','600','--m',str(best['m']),'--group',str(best['group']),'--noise-rows','1','--library','b200_offline_engine_v8.so','--gate','offline-engine-v8-native-gates.json','--log-file','pool-validation-v8retry-events.jsonl']
 with (r/'pool-validation-v8retry-stdout.log').open('x') as out,(r/'pool-validation-v8retry-telemetry.csv').open('x') as telemetry:
  child=subprocess.Popen(args,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  record={'pid':child.pid,'proc_stat':Path(f'/proc/{child.pid}/stat').read_text()}
  with (r/'pool-validation-v8retry-child.json').open('x') as f:json.dump(record,f)
  deadline=time.monotonic()+720
  telemetry.write('timestamp,temperature.gpu,power.draw,clocks.sm,utilization.gpu\n')
  while child.poll() is None:
   if time.monotonic()>deadline:raise RuntimeError('finite validation deadline exceeded')
   q=subprocess.run(['nvidia-smi','-i',env['CUDA_VISIBLE_DEVICES'],'--query-gpu=timestamp,temperature.gpu,power.draw,clocks.sm,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10,check=True)
   telemetry.write(q.stdout);telemetry.flush()
   values=next(csv.reader(q.stdout.splitlines()));assert len(values)==5
   if float(values[1])>=85:raise RuntimeError('thermal safety stop at85C')
   event_path=r/'pool-validation-v8retry-events.jsonl'
   if event_path.exists():
    events=[]
    for line in event_path.read_text().splitlines():
     try:events.append(json.loads(line))
     except json.JSONDecodeError:pass
    if not any(e.get('event')=='stratum_authorized' for e in events) and sum(e.get('error')=='pool rejected authorization' for e in events)>=3:
     raise RuntimeError('repeated authorization rejection; aborting invalid login retries')
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:pass
  if child.returncode:raise RuntimeError(f'pool adapter exit{child.returncode}')
 state['state']='finished_pending_analysis'
except Exception as exc:state.update(state='failed',error=str(exc))
finally:
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 state['finished']=time.time()
 with (r/'pool-validation-v8retry-status.json').open('x') as f:json.dump(state,f,indent=2)
