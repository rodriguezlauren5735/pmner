import fcntl,json,os,signal,subprocess,time
from pathlib import Path
r=Path('/home/jupyter-b200/pearl-b200-20260924-v1');os.chdir(r)
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-af7a73cd-3032-50a8-c5a5-21c5bab963d7')
env['LD_LIBRARY_PATH']='/usr/local/cuda/lib64:'+env.get('LD_LIBRARY_PATH','')
state={'started':time.time(),'pid':os.getpid(),'state':'waiting','results':[]}
def run(args,name,timeout):
 with (r/name).open('x') as out:
  p=subprocess.Popen(args,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();raise
 if code:raise RuntimeError(f'{name} exit{code}')
try:
 deadline=time.monotonic()+2400
 while not (r/'sequence-v136-status.json').exists():
  if time.monotonic()>deadline:raise RuntimeError('prior sequence deadline exceeded')
  time.sleep(10)
 assert json.loads((r/'offline-engine-v8-native-gates.json').read_text())['state']=='passed'
 assert json.loads((r/'offline-engine-v8-status.json').read_text())['state']=='passed'
 with (r/'gpu0.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);state['state']='running'
  for group in (12,14,16,18,20,22,24):
   # gm=32 exceeds each group, including partial final groups; each hit must
   # verify independently after reconstructing its physical matrix coordinates.
   cmd=['venv/bin/python','offline_engine_group_gate_v8.py','--m','8192','--n','512','--k','2048','--steps','4','--group',str(group)]
   run(cmd,f'group-sweep-v8-native-g{group}.log',120)
   if group in (12,24):run(['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','9']+cmd,f'group-sweep-v8-native-memcheck-g{group}.log',180)
  shapes=[(32768,16),(32768,12),(32768,14),(32768,18),(32768,20),(32768,22),(32768,24),(32768,16),(131072,16),(131072,20),(32768,16)]
  for i,(m,group) in enumerate(shapes):
   assert m*8192<2**32 and 259584*8192<2**32
   name=f'group-sweep-v8-{i:02d}.log'
   run(['venv/bin/python','offline_continuous_engine_v8.py','--m',str(m),'--group',str(group),'--seconds','30','--warmup','5','--noise-rows','1','--job-every','20'],name,120)
   result=json.loads((r/name).read_text().splitlines()[-1]);assert result['state']=='passed'
   state['results'].append(result);print(json.dumps({'trial':i,**result}),flush=True)
  state['state']='passed'
except Exception as e:state.update(state='failed',error=str(e))
state['finished']=time.time()
with (r/'group-sweep-v8-status.json').open('x') as f:json.dump(state,f,indent=2)
