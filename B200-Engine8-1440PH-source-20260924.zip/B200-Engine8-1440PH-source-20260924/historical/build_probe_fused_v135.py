"""Bounded offline GPU0 probe, all output in the isolated workspace."""
import fcntl,json,os,signal,subprocess,time,sys
from pathlib import Path
root=Path('/home/jupyter-b200/pearl-b200-20260924-v1')
os.chdir(root)
assert json.loads((root/'noise-v5-status.json').read_text())['state']=='passed'
assert json.loads((root/'pow-v1-status.json').read_text())['state']=='passed'
tag=sys.argv[1];assert tag.startswith('v') and tag[1:].isdigit()
bn=int(sys.argv[2]) if len(sys.argv)>2 else 256;assert bn in (256,512)
exe='sm100_rank_probe_'+tag
env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='GPU-af7a73cd-3032-50a8-c5a5-21c5bab963d7'
env['PATH']='/usr/local/cuda/bin:'+env['PATH']
def run(args,log,timeout):
    env['PROBE_EXPORT']=str(root/log.removesuffix('.log'))
    with (root/log).open('x') as out:
        p=subprocess.Popen(args,stdout=out,stderr=subprocess.STDOUT,env=env,start_new_session=True)
        try:code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);p.wait();raise
    if code:raise RuntimeError(f'{log} exited {code}')
    prefix=env['PROBE_EXPORT']
    if Path(prefix+'-cpu-transcripts.bin').exists():
        with (root/(log.removesuffix('.log')+'-hash-verify.log')).open('x') as out:
            subprocess.run([str(root/'venv/bin/python'),'verify_fused_hits_v1.py',prefix],stdout=out,stderr=subprocess.STDOUT,env=env,check=True,timeout=90)
with (root/'gpu0.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    status={'started':time.time(),'state':'running','pid':os.getpid()}
    try:
        run(['/usr/local/cuda/bin/nvcc','-std=c++20','-O3','-gencode=arch=compute_100a,code=sm_100a','--expt-relaxed-constexpr','-Xptxas=-v',f'-DPROBE_BN={bn}','-Isource/cutlass/include','-Isource/frozen-csrc',exe+'.cu','-o',exe,'-lcuda'],f'compile-{tag}.log',180)
        assert tag=='v135'
        run(['/usr/local/cuda/bin/nvcc','-std=c++20','-O3','-gencode=arch=compute_100a,code=sm_100a','--expt-relaxed-constexpr','-DPROBE_DELAY_PEER_PRODUCER=1','-Isource/cutlass/include','-Isource/frozen-csrc',exe+'.cu','-o',exe+'-delayed','-lcuda'],f'compile-{tag}-delayed.log',180)
        for mode in ('plain','memcheck','synccheck','racecheck'):
            cmd=['./'+exe+'-delayed','512','512','2048','1']
            if mode!='plain':cmd=['/usr/local/cuda/bin/compute-sanitizer','--tool',mode,'--error-exitcode','9']+cmd
            run(cmd,f'delayed-peer-{tag}-{mode}.log',120)
        for k in (128,256,2048,2176,8192):
            run(['./'+exe,'256',str(bn),str(k),'1'],f'correctness-{tag}-k{k}.log',90)
        for pattern in (1,2,3,4):
            env['PROBE_INPUT']=str(pattern)
            run(['./'+exe,'256','512','8192','1'],f'extreme-{tag}-pattern{pattern}.log',120)
        env.pop('PROBE_INPUT',None)
        for m,n,k in ((256,1024,2176),(512,1024,8192),(1280,1024,256)):
            run(['./'+exe,str(m),str(n),str(k),'1'],f'multitile-{tag}-{m}-{n}-{k}.log',120)
        run(['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','9','./'+exe,'256',str(bn),'2176','1'],f'memcheck-{tag}.log',120)
        for mode in ('synccheck','racecheck'):
            run(['/usr/local/cuda/bin/compute-sanitizer','--tool',mode,'--error-exitcode','9','./'+exe,'256',str(bn*2),'256','1'],f'{mode}-{tag}.log',120)
        env['PROBE_INPUT']='1'
        for mode in ('memcheck','synccheck','racecheck'):
            run(['/usr/local/cuda/bin/compute-sanitizer','--tool',mode,'--error-exitcode','9','./'+exe,'256','512','8192','1'],f'long-{mode}-{tag}.log',150)
        env['PROBE_INPUT']='4'
        for mode in ('memcheck','synccheck','racecheck'):
            run(['/usr/local/cuda/bin/compute-sanitizer','--tool',mode,'--error-exitcode','9','./'+exe,'256','512','8192','1'],f'noise-long-{mode}-{tag}.log',150)
        run(['./'+exe,'512','512','8192','1'],f'noise-second-cluster-{tag}.log',150)
        for mode in ('memcheck','synccheck','racecheck'):
            run(['/usr/local/cuda/bin/compute-sanitizer','--tool',mode,'--error-exitcode','9','./'+exe,'512','512','8192','1'],f'noise-second-cluster-{mode}-{tag}.log',150)
        env.pop('PROBE_INPUT',None)
        run(['./'+exe,'4096','8192','8192','5'],f'performance-{tag}.log',90)
        for runid in range(3):
            run(['./'+exe,'8192','32768','8192','30'],f'performance-large-{tag}-{runid}.log',90)
        env['PROBE_INPUT']='1'
        run(['./'+exe,'32768','259584','8192','5'],f'production-shape-{tag}.log',150)
        env['PROBE_INPUT']='4';env['PROBE_WARMUP_SECONDS']='10'
        run(['./'+exe,'32768','259584','8192','30'],f'frozen-noise-production-{tag}.log',150)
        status['state']='passed'
    except Exception as e:status.update(state='failed',error=str(e))
    status['finished']=time.time()
    with (root/f'build-{tag}-status.json').open('x') as f:json.dump(status,f,indent=2)
