"""Packaging helper: explicit, finite offline rebuild; never connects to a pool."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gpu-uuid', required=True)
    p.add_argument('--cuda', default='/usr/local/cuda')
    a = p.parse_args()
    if not a.gpu_uuid.startswith('GPU-') or ',' in a.gpu_uuid:
        raise ValueError('Select one explicit GPU UUID')
    root = Path(__file__).resolve().parent / 'runtime'
    os.chdir(root)
    lib = Path('b200_offline_engine_v8.so')
    gate = Path('offline-engine-v8-native-gates.json')
    status = Path('offline-engine-v8-status.json')
    logs = Path('rebuild-logs')
    if any(x.exists() for x in (lib, gate, status, logs)):
        raise FileExistsError('Use a fresh extraction; never overwrite prior builds/gates/logs')
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=a.gpu_uuid)
    env['LD_LIBRARY_PATH'] = a.cuda + '/lib64:' + env.get('LD_LIBRARY_PATH', '')
    gpu = subprocess.check_output(['nvidia-smi', '-i', a.gpu_uuid, '--query-gpu=name', '--format=csv,noheader'], text=True).strip()
    if 'B200' not in gpu:
        raise RuntimeError('This package is validated only on B200')
    lock = Path('gpu0.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    logs.mkdir()

    def run(name, args, timeout=300):
        print(name, flush=True)
        with (logs / (name + '.log')).open('x') as out:
            child = subprocess.Popen(args, env=env, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                rc = child.wait(timeout=timeout)
            except BaseException:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                raise
        if rc:
            raise RuntimeError(f'{name} failed with exit {rc}; inspect logs')

    tests = ['test_b200_pool_adapter_v2', 'test_b200_runtime_gate_v2',
             'test_b200_stratum_transport_v1', 'test_b200_submit_wakeup_v1',
             'test_analyze_pool_validation_v1']
    run('cpu-tests', [sys.executable, '-B', '-m', 'unittest', *tests])
    run('compile', [a.cuda + '/bin/nvcc', '-std=c++20', '-O3', '-shared', '--cudart', 'shared',
                   '-Xcompiler', '-fPIC', '-Xptxas=-v', '-gencode=arch=compute_100a,code=sm_100a',
                   '--expt-relaxed-constexpr', '-Isource/cutlass/include', '-Isource/frozen-csrc',
                   'b200_offline_engine_v8.cu', '-o', str(lib), '-lcuda'])
    for rows in (1, 8):
        for mode in ('plain', 'memcheck', 'synccheck', 'racecheck'):
            cmd = [sys.executable, '-B', 'offline_engine_gate_v8.py', '--noise-rows', str(rows), '--k', '2048', '--steps', '32']
            if mode != 'plain':
                cmd = [a.cuda + '/bin/compute-sanitizer', '--tool', mode, '--error-exitcode', '9'] + cmd
            run(f'noise{rows}-{mode}', cmd)
        run(f'noise{rows}-k8192', [sys.executable, '-B', 'offline_engine_gate_v8.py', '--noise-rows', str(rows), '--k', '8192', '--steps', '8'])
    run('group20-native', [sys.executable, '-B', 'offline_engine_group_gate_v8.py', '--group', '20', '--m', '16384', '--n', '512', '--k', '8192', '--steps', '8'])
    run('expanded-native', [sys.executable, '-B', 'offline_engine_group_gate_v8.py', '--group', '20', '--m', '131072', '--n', '259584', '--k', '8192', '--steps', '8', '--nbits', '0x1b040000'])
    for i in range(2):
        run(f'continuous-{i}', [sys.executable, '-B', 'offline_continuous_engine_v8.py', '--m', '131072', '--n', '259584', '--k', '8192', '--group', '20', '--noise-rows', '1', '--seconds', '90'], 180)
    result = {'state': 'passed', 'library': lib.name, 'finished': time.time(), 'gpu_uuid': a.gpu_uuid,
              'library_sha256': hashlib.sha256(lib.read_bytes()).hexdigest(), 'origin': 'fresh package offline verification; not historical gate reuse'}
    for file in (gate, status):
        with file.open('x') as out:
            json.dump(result, out, indent=2)
    print('Offline gates passed. No pool connection was made.')


if __name__ == '__main__':
    main()
