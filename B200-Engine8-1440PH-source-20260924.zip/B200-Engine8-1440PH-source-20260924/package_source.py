"""Curated source export. No networking/GPU, no overwrite, no private credentials."""
import ast
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import zipfile

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
DEV = LAB.parents[1]
OUT = Path('C:/user/B200-Engine8-1440PH-source-20260924.zip')
TOP = OUT.stem
BASE = '4289463dd0a5e5517bd8eb2908a4c7bda990b08e'
PROOF = DEV / 'results/20260908-external-screens/constant-proof-evidence-20260908-v1'
files = {}
origins = {}


def add(name, data, origin):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
    assert name not in files, name
    files[name] = data
    origins[name] = origin


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert not OUT.exists() and not OUT.with_suffix('.zip.sha256').exists()
core = '''b200_offline_engine_v8.cu sm100_rank_probe_v135.cu tensorhash_port_probe_v4.cu
simple_merkle_roots_v4.cuh noise_port_helpers_v4.cuh noise_rows8_kernel_v6.cuh
b200_pool_adapter_v2.py b200_stratum_transport_v1.py b200_submit_wakeup_v1.py
offline_wideproof_fixture_v2.py offline_engine_gate_v8.py offline_engine_group_gate_v8.py
offline_continuous_engine_v8.py test_b200_pool_adapter_v2.py test_b200_runtime_gate_v2.py
test_b200_stratum_transport_v1.py test_b200_submit_wakeup_v1.py
analyze_pool_validation_v1.py test_analyze_pool_validation_v1.py'''.split()
historical = '''run_offline_engine_v8.py run_pool_validation_v8retry.py
build_probe_fused_v135.py run_group_sweep_v8.py'''.split()
archive = LAB / 'evidence-v11-stage141.tar.gz'
assert sha(archive.read_bytes()) == '20455c6325d14c21ac7ae4a7811996d59abe2a45f8f09589ff541d9153875e79'
with tarfile.open(archive, 'r:gz') as t:
    manifest = {x['name']: x for x in json.load(t.extractfile('evidence-manifest.json'))['files']}
    def archived(name):
        data = t.extractfile(name).read()
        assert sha(data) == manifest[name]['sha256']
        assert len(data) == manifest[name]['bytes']
        return data
    for name in core:
        if name in ('analyze_pool_validation_v1.py', 'test_analyze_pool_validation_v1.py'):
            add('runtime/' + name, (LAB / name).read_bytes(), 'post-run read-only analysis and regression tests')
            continue
        data = archived(name)
        # Preserve the exact remote tested bytes, and detect local drift.
        assert data.replace(b'\r\n', b'\n') == (LAB / name).read_bytes().replace(b'\r\n', b'\n'), name
        add('runtime/' + name, data, 'verified evidence-v11-stage141/' + name)
    for name in historical:
        add('historical/' + name, archived(name), 'verified evidence-v11-stage141/' + name)
    add('prebuilt/b200_offline_engine_v8.so', archived('b200_offline_engine_v8.so'), 'actual tested CUDA shared library')
    wheel = 'py_pearl_mining-0.3.1-cp312-abi3-manylinux_2_34_x86_64.whl'
    data = archived(wheel)
    assert sha(data) == '8912030bf4dea69a5860fadb08f6af2df3b873fab4f392196209ed9234a29491'
    add('prebuilt/' + wheel, data, 'actual tested original native proof wheel')
    for name in ('offline-v118-k2048-fixture.json', 'offline-v118-k2048-plain-gpu-hits.bin'):
        add('runtime/' + name, archived(name), 'original CPU regression fixture')
    for name in manifest:
        if (name.startswith(('offline-engine-v8-', 'group-sweep-v8-', 'build-v135-', 'adapter-cpu-tests-v2'))
                and name.endswith(('.json', '.log', '.csv'))):
            add('evidence/' + name, archived(name), 'verified original test evidence')
    source = archived('source-v1.tar.gz')
with tarfile.open(fileobj=io.BytesIO(source), mode='r:gz') as t:
    source_manifest = json.load(t.extractfile('source-manifest.json'))
    for member in t.getmembers():
        name = member.name
        if not name.startswith(('frozen-csrc/', 'cutlass/')):
            continue
        assert member.isfile()
        data = t.extractfile(member).read()
        assert sha(data) == source_manifest[name]['sha256']
        add('runtime/source/' + name, data, 'frozen source-v1/' + name)

# Reconstruct the actual proof source from its recorded commit, not today's checkout.
git_tar = subprocess.check_output(['git', '-C', str(DEV / 'upstream-pearl'), 'archive', BASE,
                                  'pearl-blake3', 'py-pearl-mining', 'zk-pow', 'plonky2', 'LICENSE'])
native = {}
with tarfile.open(fileobj=io.BytesIO(git_tar), mode='r:') as t:
    for member in t.getmembers():
        if member.isdir():
            continue
        assert member.isfile(), member.name
        native[member.name] = t.extractfile(member).read()
frozen = PROOF / 'constant-input-proof-v1'
expected = {}
for line in (frozen / 'constant-proof-artifacts.sha256').read_text().splitlines():
    digest, name = line.split(None, 1)
    if not name.startswith('../'):
        expected[name] = digest
for name, digest in expected.items():
    data = (frozen / name).read_bytes()
    assert sha(data) == digest, name
    native[name] = data
for name, data in native.items():
    add('native-proof-source/' + name, data, ('verified recorded overlay' if name in expected else 'git ' + BASE))
for name in ('constant-proof-base.txt', 'constant-proof-change.patch', 'constant-proof-source.sha256', 'constant-proof-artifacts.sha256'):
    add('native-proof-source/provenance/' + name, (frozen / name).read_bytes(), 'historical proof provenance')
for name in ('test_constant_proof_binding.py', 'verify_constant_sparse_pipeline.py'):
    add('native-proof-source/tests/' + name, (PROOF / 'constant-input-proof-tests-v1' / name).read_bytes(), 'historical native proof regression tests')

for name in ('pool-validation-v8retry-analysis.json', 'pool-validation-v8retry-events.jsonl', 'pool-validation-v8retry-telemetry.csv'):
    add('evidence/' + name, (LAB / name).read_bytes(), 'completed real pool validation downloaded evidence')
for name in ('README-中文.md', 'build_validate.py', 'package_source.py'):
    add(name, (HERE / name).read_bytes(), 'new packaging-only documentation/helper, not measured miner changes')
add('LICENSE-upstream-Pearl', native['LICENSE'], 'upstream source license ' + BASE)

# Resolve all quoted project includes recursively within the packaged build paths.
unresolved = []
visited = set()
def includes(name):
    if name in visited:
        return
    visited.add(name)
    for header in re.findall(r'^\s*#\s*include\s*"([^"]+)"', files[name].decode(errors='replace'), re.M):
        candidates = [str(PurePosixPath(name).parent / header), 'runtime/' + header,
                      'runtime/source/frozen-csrc/' + header, 'runtime/source/cutlass/include/' + header]
        found = next((x for x in candidates if x in files), None)
        if found:
            includes(found)
        else:
            unresolved.append((name, header))
includes('runtime/b200_offline_engine_v8.cu')
assert not unresolved, unresolved
for name, data in files.items():
    if (name.startswith('runtime/') and name.endswith('.py')) or name in ('build_validate.py', 'package_source.py'):
        ast.parse(data, filename=name)
    if not name.endswith(('.so', '.whl', '.bin')):
        assert not re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----|sessionid=[A-Za-z0-9]{10,}|csrftoken=[A-Za-z0-9]{10,}|trycloudflare\.com/[^\s]*token=[a-f0-9]{32,}', data), name
summary = {'version': 'B200 Engine8 / Core135 / adapter2', 'measured_local_ph_s': 1.4403116124726992,
           'not_24h_pool_accepted_average': True, 'gpu_jobs_started_for_export': 0,
           'project_include_closure_files': len(visited), 'files': [
               {'path': n, 'bytes': len(d), 'sha256': sha(d), 'origin': origins[n]} for n, d in sorted(files.items())]}
add('MANIFEST.json', json.dumps(summary, indent=2, ensure_ascii=False).encode(), 'generated')
add('SHA256SUMS.txt', ''.join(f'{sha(d)}  {n}\n' for n, d in sorted(files.items())).encode(), 'generated')
with zipfile.ZipFile(OUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, data in sorted(files.items()):
        z.writestr(TOP + '/' + name, data)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(files)
    for name, data in files.items():
        assert sha(z.read(TOP + '/' + name)) == sha(data), name
digest = sha(OUT.read_bytes())
with OUT.with_suffix('.zip.sha256').open('x') as f:
    f.write(digest + '  ' + OUT.name + '\n')
print(json.dumps({'path': str(OUT), 'files': len(files), 'bytes': OUT.stat().st_size,
                  'sha256': digest, 'include_closure': len(visited), 'verified': True}, indent=2))
