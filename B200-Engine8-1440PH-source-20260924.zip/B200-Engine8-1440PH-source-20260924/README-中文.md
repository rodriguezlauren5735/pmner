# B200 自研 1.440 PH/s 版本完整源码交付

冻结日期：2026-09-24。版本标识：**Engine v8 / Core v135 / Pool adapter v2**。
这是 B200 分支，不是把 H100 0.6.2 原文件重新命名；未包含后续 v136–v147 实验内核。

## 实测与限制

- 单张 NVIDIA B200，原设备 148 SM、约 183359 MiB 显存，原 1000 W 上限未调整。
- CUDA 13.0.88，驱动 580.173.02，Linux x86_64，Python 3.12.3。
- 参数：M=131072、N=259584、K=8192、group=20、noise_rows=1。
- 约 600 秒真实矿池测试，3093 次完整计算，91 accepted、0 rejected、0 unknown、0 丢弃。
- 最后运行中累计本地算力 **1440.3116 TH/s（1.4403116 PH/s）**；8 个约 60 秒稳态窗口平均 **1440.2449 TH/s**，范围 1439.8483–1440.8133。
- 结束后的累计本地值 1435.407 TH/s 包含停止计算后的提交排空等待，不应与运行中值混用。
- 按已接受份额难度累计的该次矿池有效工作量点估计 **1364.7381 TH/s**。短测份额随机性大，不能据此声称 24 小时矿池平均为 1.440 PH/s，也未证明稳定领先 SRBMiner 3.6.9。
- 这是研究版、单卡、有限时长客户端（60–1800 秒），不是已经验证的 24 小时多卡生产发行版。

## 包内目录

- `runtime/`：当时实际版本的 CUDA/Python 原始源码、测试、CPU 证明测试数据。源码未因打包而改写。
- `runtime/source/frozen-csrc/`：冻结 0.6.2 中复用的噪声生成、BLAKE3、承诺计算等 CUDA 源码。
- `runtime/source/cutlass/`：实际构建使用的 CUTLASS 头文件和许可证。
- `native-proof-source/`：Rust 证明库完整项目源码。来自基线提交 `4289463dd0a5e5517bd8eb2908a4c7bda990b08e` 的 pearl-blake3、py-pearl-mining、zk-pow、plonky2，并叠加实际使用的 sparse-filled Merkle proof 修改与 Cargo.lock。
- `prebuilt/`：对应的已测试 Linux B200 `.so` 和 Python 3.12 ABI3 原生证明 wheel；不是 CUDA/Rust 源码的替代品。
- `evidence/`：原始编译、正确性、sanitizer、ABBA、参数扫描和真实矿池日志及汇总。历史通过记录只作为证据，不自动授权新构建运行。
- `historical/`：当时使用的构建/验证/矿池测试启动脚本，保留原路径和设备 UUID，仅供复现参考，不能不检查就直接运行。
- `build_validate.py`：此次交付新增的可迁移离线构建/验证入口；不连接矿池、不修改功耗和驱动。该辅助入口本次只做语法检查，未重复占用远端 GPU 执行。
- `MANIFEST.json`、`SHA256SUMS.txt`：逐文件长度、来源和 SHA-256；归档外另附 zip 的 SHA-256。

未打包 SSH 私钥、浏览器 Cookie、Jupyter 访问 token、云账号会话、Windows 项目后台配置。日志可能含原公开收款地址、worker、job 和份额内容。

## 代码入口及主要算法

1. `b200_offline_engine_v8.cu`：C ABI 引擎，包含 Core v135；分配缓存、接收新任务、提交每次新 nonce、输出命中和证明用 Merkle 缓存。
2. `sm100_rank_probe_v135.cu`：SM100a 双 SM Tensor Core 整数矩阵核、TMA 双缓冲、TMEM 读取、秩链 XOR、BLAKE3 和目标判断。包含修复长循环阶段复用的 **256 消费者 + 2 生产者确认**，不能随意去掉 peer producer 的确认。
3. `tensorhash_port_probe_v4.cu`、`simple_merkle_roots_v4.cuh`：Merkle 子树和承诺计算。
4. `noise_port_helpers_v4.cuh`、`noise_rows8_kernel_v6.cuh`：原始 keyed noise 与稀疏噪声应用；1.440 配置选 noise_rows=1，8 行模式不是该成绩配置。
5. `b200_pool_adapter_v2.py`：CUDA ctypes 入口、单 CPU 证明进程、有限队列、每份证明独立原生 V3 验证后提交。
6. `b200_stratum_transport_v1.py`、`b200_submit_wakeup_v1.py`：TLS、重连、任务更新、份额响应和日志。
7. `offline_wideproof_fixture_v2.py`：2×128 证明配置；原生目标调整和证明约束仍执行。

矩阵原始内容为固定 64，A 的前 10 字节写入新 nonce；按任务密钥生成噪声。任务变化时重新建立承诺/噪声缓存。复用的是合法中间计算，不是反复提交同一个份额。2×128 证明遵守原生配置和难度换算。

## Linux 构建与离线验证

建议在空目录解压，且确认目标 GPU 没有其他程序占用。本包不安装 CUDA、不调整驱动，也不停止其他进程。

```bash
cd B200-Engine8-1440PH-source-20260924
python3.12 -m venv .venv
.venv/bin/python -m pip install blake3==1.0.8 numpy==2.2.6
.venv/bin/python -m pip install --no-deps prebuilt/py_pearl_mining-0.3.1-cp312-abi3-manylinux_2_34_x86_64.whl
nvidia-smi --query-gpu=index,uuid,name --format=csv
# 替换为要使用的唯一一张 B200 的 UUID；这一步会编译并实际占用该 GPU 做离线验证。
.venv/bin/python build_validate.py --gpu-uuid GPU-你的设备UUID
```

构建入口使用 `-gencode=arch=compute_100a,code=sm_100a`，编译器默认 `/usr/local/cuda/bin/nvcc`。需要 CUDA Toolkit、C++ 编译器以及同目录 `compute-sanitizer`。H100/H200 不能直接使用该 SM100a 内核。

入口顺序：CPU 单元测试 → CUDA 编译 → 两种噪声布局的小尺寸原生 V3 与 memcheck/synccheck/racecheck → K8192 原生校验 → group20 及大尺寸校验 → 两段 90 秒完整引擎持续测试。全部成功才生成新的 native/runtime gate；失败不生成通过状态。执行有限时长且持有本目录 `gpu0.lock`。此锁不阻止其他目录里的程序，用户仍需自行确保 GPU 独占。

原始 nvcc 参数可见 `historical/run_offline_engine_v8.py` 或 `evidence/offline-engine-v8-compile.log`。CPU 测试读取包内原始 fixture，不产生真实份额。

## 显式运行矿池测试

为了保留实测源码原样，`runtime/b200_pool_adapter_v2.py` 的 `GPU_UUID` 常量仍为原测试设备。更换设备时，只将该常量改为你实际的目标 B200 UUID，并将下面环境变量设为相同值。设备 UUID 不影响数学算法，但更换环境须重新验证。不能用历史 JSON 替代新环境验证。

```bash
cd runtime
export CUDA_VISIBLE_DEVICES=GPU-你的设备UUID
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}
../.venv/bin/python -B b200_pool_adapter_v2.py \
  --wallet 你的prl1收款地址 --worker b200v8 \
  --host prl-us.kryptex.network --port 8048 \
  --seconds 600 --m 131072 --n 259584 --k 8192 \
  --group 20 --noise-rows 1 \
  --library b200_offline_engine_v8.so \
  --gate offline-engine-v8-native-gates.json \
  --log-file pool-run-001.jsonl
```

8048 使用证书验证的 TLS。worker 用短英文数字名称；历史 33 字符名称被池拒绝，换短名称后授权成功，但未精确测定池的长度上限。每次使用新的日志文件名，程序拒绝覆盖。Ctrl+C 正常退出；内置没有温度监控，历史外层 runner 才有 85°C 保护，长测需另外完善守护和温控。

**务必显式传入上述 library、gate、noise-rows、group、m 参数。** 原 adapter 的默认 library/gate 是较早版本名称，不能直接省略；保留这一点是为保证源码与实测完全一致。

## 原生证明库从源码重建

现成 wheel 就是原测试使用的版本，SHA-256：`8912030bf4dea69a5860fadb08f6af2df3b873fab4f392196209ed9234a29491`。

源码基线/补丁/锁文件都在包内。Rust 第三方 crates、Rust 工具链、Python 包、CUDA Toolkit 不属于本项目源码，没有整套离线缓存；重建可能需要访问 crate registry。plonky2 使用 nightly 功能，需要合适的 Rust nightly。原远端工具链没有在本次交付中重新验证，不承诺任意最新 nightly 都能构建成功。

```bash
.venv/bin/python -m pip install 'maturin>=1.7'
cd native-proof-source
cargo +nightly test --locked --release --manifest-path pearl-blake3/Cargo.toml --lib --features serde
cd py-pearl-mining
RUSTUP_TOOLCHAIN=nightly ../../.venv/bin/maturin build --locked --release \
  --interpreter ../../.venv/bin/python --out ../../rebuilt-wheels
```

编译成功后安装重建 wheel，再重新跑 CPU 与 GPU 原生验证；不要未经验证替换原 wheel。源码重建的二进制 SHA 不一定与原工具链构建物一致。

## 交付检查范围

此次导出核对已归档实测版本字节、验证源码依赖及原生补丁哈希、逐文件 SHA-256、ZIP 完整性和新增脚本语法。没有启动新的矿池会话，没有改动正在运行的远端程序，也没有把尚未验证的优化混入此版。
