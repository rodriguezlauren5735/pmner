//! Merkle tree construction and proof generation/verification.
//!
//! `MerkleTree` builds a BLAKE3 Merkle tree from raw bytes and generates multi-leaf proofs.
//! `MerkleProof` verifies proofs and provides byte extraction utilities.

use std::collections::{BTreeMap, BTreeSet, HashMap};

use anyhow::{ensure, Result};
use blake3::{CHUNK_LEN, OUT_LEN};
use rayon::prelude::*;

use crate::hasher::{Blake3Hasher, Digest};

/// Round `raw_len` up to the next multiple of `CHUNK_LEN` (1024).
pub fn padded_chunk_len(raw_len: usize) -> usize {
    raw_len.div_ceil(CHUNK_LEN) * CHUNK_LEN
}

/// Zero-pad `data` so its length is a multiple of `CHUNK_LEN` (1024).
///
/// Matrix data must be padded to a BLAKE3 chunk boundary before building a
/// Merkle tree.  Uses [`padded_chunk_len`] for the target size.
pub fn pad_to_chunk_boundary(data: &[u8]) -> Vec<u8> {
    let mut padded = data.to_vec();
    padded.resize(padded_chunk_len(data.len()), 0);
    padded
}

// ============================================================================
// Sparse-zero proof construction
// ============================================================================

/// Build a multi-leaf proof for data consisting of a byte prefix followed by
/// zeros, using a contiguous suffix of already-computed subtree CVs.
///
/// This is intended for large, sparse mining matrices whose GPU tensor hash
/// scratchpad still contains the base subtree roots which were not overwritten
/// by later reduction passes. `known_subtree_roots` must be the complete,
/// contiguous suffix of level-`subtree_height` nodes beginning at
/// `known_roots_start_leaf`. Each root covers `2^subtree_height` Merkle leaves
/// (except the final root, which may cover a shorter tail).
///
/// The bytes in `[0, sparse_prefix.len())` are taken from `sparse_prefix`; every
/// remaining byte up to `total_len` is implicitly zero. `total_len` and
/// `known_roots_start_leaf` must be aligned to the BLAKE3 chunk and base-subtree
/// boundaries respectively. The supplied subtree roots must reconstruct
/// `expected_root`, and the returned proof is independently verified before it
/// is returned.
///
/// Unlike [`MerkleTree::new`], this function never materializes all
/// `total_len` bytes. Work is proportional to the missing base-root prefix and
/// the proof paths, rather than to the whole sparse matrix.
///
/// For the current CUDA `tensor_hash` layout, let `t = threads_per_block` and
/// `b = ceil(total_leaves / t)`. Then `subtree_height = log2(t)`. With
/// `leaves_per_mt_block = l`, the second reduction overwrites the first
/// `ceil(b / l)` root slots, so the untouched suffix starts at
/// `known_roots_start_leaf = ceil(b / l) * t`; pass the packed 32-byte scratch
/// records from that root slot through slot `b - 1`.
///
/// # Trust boundary
///
/// The supplied subtree roots are authenticated against `expected_root`, but
/// they summarize bytes that this function does not reopen. Consequently this
/// API assumes both values came from the same trusted hash invocation; it does
/// not independently prove that every unopened byte represented by those roots
/// is zero.
#[allow(clippy::too_many_arguments)]
pub fn sparse_zero_multileaf_proof(
    sparse_prefix: &[u8],
    total_len: usize,
    key: Digest,
    leaf_indices: &[usize],
    subtree_height: u32,
    known_roots_start_leaf: usize,
    known_subtree_roots: &[Digest],
    expected_root: Digest,
) -> Result<MerkleProof> {
    sparse_filled_multileaf_proof(
        sparse_prefix, 0, total_len, key, leaf_indices, subtree_height,
        known_roots_start_leaf, known_subtree_roots, expected_root,
    )
}

/// Build a proof for a byte prefix followed by a repeated background byte.
///
/// This preserves the sparse-zero API's chunk-aligned length, ragged-tree
/// topology, complete trusted CV suffix and expected-root authentication.
/// Only real leaves are filled: missing right children are promoted, not
/// padded with new constant (or zero) leaves. Unaligned raw byte strings remain
/// unsupported. The pinned MerkleProof verifier treats a single-leaf root as
/// a chunk CV whereas MerkleTree uses a root hash, so single-leaf inputs are
/// explicitly rejected here instead of changing consensus verification.
/// This function does not enforce a miner's matrix-value policy.
#[allow(clippy::too_many_arguments)]
pub fn sparse_filled_multileaf_proof(
    sparse_prefix: &[u8],
    fill_byte: u8,
    total_len: usize,
    key: Digest,
    leaf_indices: &[usize],
    subtree_height: u32,
    known_roots_start_leaf: usize,
    known_subtree_roots: &[Digest],
    expected_root: Digest,
) -> Result<MerkleProof> {
    ensure!(total_len > 0, "total_len must be non-zero");
    ensure!(total_len >= 2 * CHUNK_LEN, "single-leaf sparse proofs are unsupported by the pinned verifier");
    ensure!(
        total_len.checked_rem(CHUNK_LEN) == Some(0),
        "total_len must be aligned to the {}-byte BLAKE3 chunk size",
        CHUNK_LEN
    );
    ensure!(
        sparse_prefix.len() <= total_len,
        "sparse_prefix is longer than total_len"
    );
    ensure!(!leaf_indices.is_empty(), "leaf_indices must be non-empty");

    let leaves_per_subtree = 1usize
        .checked_shl(subtree_height)
        .ok_or_else(|| anyhow::anyhow!("subtree_height is too large"))?;
    let total_leaves = total_len / CHUNK_LEN;
    ensure!(
        leaves_per_subtree <= total_leaves,
        "subtree_height exceeds the Merkle tree's leaf domain"
    );
    ensure!(
        known_roots_start_leaf.checked_rem(leaves_per_subtree) == Some(0),
        "known_roots_start_leaf must be aligned to {} leaves",
        leaves_per_subtree
    );

    let base_node_count = total_leaves.div_ceil(leaves_per_subtree);
    let base_leaf_capacity = base_node_count
        .checked_mul(leaves_per_subtree)
        .ok_or_else(|| anyhow::anyhow!("base subtree domain overflows usize"))?;
    ensure!(
        known_roots_start_leaf <= base_leaf_capacity,
        "known_roots_start_leaf is outside the base subtree domain"
    );
    let known_start_node = known_roots_start_leaf / leaves_per_subtree;
    ensure!(
        known_start_node <= base_node_count,
        "known root start is outside the base subtree domain"
    );
    ensure!(
        known_subtree_roots.len() == base_node_count - known_start_node,
        "known_subtree_roots has length {}, expected {} for a complete suffix",
        known_subtree_roots.len(),
        base_node_count - known_start_node
    );

    let reconstructed_prefix_len = known_roots_start_leaf
        .checked_mul(CHUNK_LEN)
        .ok_or_else(|| anyhow::anyhow!("reconstructed prefix length overflows usize"))?
        .min(total_len);
    ensure!(
        sparse_prefix.len() <= reconstructed_prefix_len,
        "sparse_prefix extends into the region represented by known subtree roots"
    );

    // A tensor-hash scratchpad only exposes non-root base CVs when there are at
    // least two base nodes. For a one-node tree there is no useful suffix to
    // consume; keep the sparse fallback available, but reject ambiguous roots.
    if base_node_count == 1 {
        ensure!(
            known_subtree_roots.is_empty() && known_start_node == 1,
            "known subtree roots are not usable when the tree has only one base node"
        );
    }

    let unique: BTreeSet<usize> = leaf_indices.iter().copied().collect();
    ensure!(
        unique.last().is_some_and(|&i| i < total_leaves),
        "leaf index out of bounds"
    );
    let sorted_indices: Vec<usize> = unique.iter().copied().collect();

    let mut base_nodes = vec![None; base_node_count];
    for (slot, root) in base_nodes[known_start_node..]
        .iter_mut()
        .zip(known_subtree_roots)
    {
        *slot = Some(*root);
    }

    let mut nodes = SparseFilledNodeProvider {
        sparse_prefix,
        fill_byte,
        total_leaves,
        subtree_height,
        base_nodes,
        hasher: Blake3Hasher::with_key(key),
        cache: HashMap::new(),
    };

    let reconstructed_root = nodes.compute_root()?;
    ensure!(
        reconstructed_root == expected_root,
        "known subtree roots and sparse prefix do not reconstruct expected_root"
    );

    let leaf_data = sorted_indices
        .iter()
        .map(|&i| nodes.leaf_data(i))
        .collect::<Result<Vec<_>>>()?;

    // Follow precisely the same level-order sibling traversal as
    // MerkleTree::get_multileaf_proof. This makes every MerkleProof field and
    // sibling position byte-for-byte equivalent to the dense-tree path.
    let mut siblings = Vec::new();
    let mut current_set = unique;
    let mut level_len = total_leaves;
    let mut level = 0u32;
    while level_len > 1 {
        for &i in &current_set {
            if i % 2 == 1 {
                if !current_set.contains(&(i - 1)) {
                    siblings.push(nodes.node(level, i - 1)?);
                }
            } else if !current_set.contains(&(i + 1)) && (i + 1) < level_len {
                siblings.push(nodes.node(level, i + 1)?);
            }
        }

        current_set = current_set.iter().map(|&i| i / 2).collect();
        level_len = level_len.div_ceil(2);
        level += 1;
    }

    let proof = MerkleProof {
        leaf_data,
        leaf_indices: sorted_indices,
        total_leaves,
        root: expected_root,
        siblings,
    };
    proof.sanity_check()?;
    ensure!(
        proof.verify(key),
        "sparse data and supplied subtree roots are inconsistent with expected_root"
    );
    Ok(proof)
}

/// Lazily supplies non-root CVs from either trusted base nodes or the virtual
/// prefix/constant byte string. Nodes are memoized because multiproof paths overlap.
struct SparseFilledNodeProvider<'a> {
    sparse_prefix: &'a [u8],
    fill_byte: u8,
    total_leaves: usize,
    subtree_height: u32,
    base_nodes: Vec<Option<Digest>>,
    hasher: Blake3Hasher,
    cache: HashMap<(u32, usize), Digest>,
}

impl SparseFilledNodeProvider<'_> {
    fn level_len(&self, level: u32) -> Result<usize> {
        let span = 1usize
            .checked_shl(level)
            .ok_or_else(|| anyhow::anyhow!("Merkle level is too large"))?;
        Ok(self.total_leaves.div_ceil(span))
    }

    fn leaf_data(&self, leaf_index: usize) -> Result<[u8; CHUNK_LEN]> {
        ensure!(leaf_index < self.total_leaves, "leaf index out of bounds");
        let start = leaf_index
            .checked_mul(CHUNK_LEN)
            .ok_or_else(|| anyhow::anyhow!("leaf byte offset overflows usize"))?;
        let mut data = [self.fill_byte; CHUNK_LEN];
        if start < self.sparse_prefix.len() {
            let copied = CHUNK_LEN.min(self.sparse_prefix.len() - start);
            data[..copied].copy_from_slice(&self.sparse_prefix[start..start + copied]);
        }
        Ok(data)
    }

    /// Return a non-root CV at an ordinary Merkle layer.
    fn node(&mut self, level: u32, index: usize) -> Result<Digest> {
        ensure!(
            index < self.level_len(level)?,
            "Merkle node index out of bounds"
        );

        if level == self.subtree_height {
            if let Some(root) = self.base_nodes.get(index).copied().flatten() {
                return Ok(root);
            }
        }
        if let Some(root) = self.cache.get(&(level, index)) {
            return Ok(*root);
        }

        let result = if level == 0 {
            let data = self.leaf_data(index)?;
            self.hasher.chunk_cv(&data, index as u64)
        } else {
            let child_level = level - 1;
            let left_index = index
                .checked_mul(2)
                .ok_or_else(|| anyhow::anyhow!("Merkle child index overflows usize"))?;
            let left = self.node(child_level, left_index)?;
            if left_index + 1 < self.level_len(child_level)? {
                let right = self.node(child_level, left_index + 1)?;
                self.hasher.parent_cv(&left, &right)
            } else {
                left
            }
        };

        self.cache.insert((level, index), result);
        Ok(result)
    }

    fn compute_root(&mut self) -> Result<Digest> {
        if self.total_leaves == 1 {
            let data = self.leaf_data(0)?;
            return Ok(self.hasher.hash(&data));
        }

        let mut level = 0u32;
        let mut level_len = self.total_leaves;
        while level_len > 2 {
            level_len = level_len.div_ceil(2);
            level += 1;
        }
        debug_assert_eq!(level_len, 2);
        let left = self.node(level, 0)?;
        let right = self.node(level, 1)?;
        Ok(self.hasher.root_cv(&left, &right))
    }
}

// ============================================================================
// MerkleTree
// ============================================================================

/// BLAKE3 Merkle tree with multi-leaf proof generation.
#[cfg_attr(feature = "pyo3", pyo3::pyclass(name = "MerkleTree"))]
pub struct MerkleTree {
    key: Digest,
    layers: Vec<Vec<Digest>>,
    data: Vec<u8>,
}

impl MerkleTree {
    /// Build a Merkle tree from `data` using keyed BLAKE3.
    pub fn new(data: &[u8], key: Digest) -> Self {
        let hasher = Blake3Hasher::with_key(key);
        if data.is_empty() {
            return Self {
                key,
                layers: vec![vec![]],
                data: vec![],
            };
        }

        // Single chunk or less: hash directly
        if data.len() <= CHUNK_LEN {
            let root = hasher.hash(data);
            return Self {
                key,
                layers: vec![vec![root]],
                data: data.to_vec(),
            };
        }

        let chunk_cvs = hasher.hash_chunks(data);
        let mut layers: Vec<Vec<Digest>> = vec![chunk_cvs];

        while layers.last().unwrap().len() > 2 {
            let prev = layers.last().unwrap();
            layers.push(hasher.combine_layer(prev));
        }

        let last = layers.last().unwrap();
        if last.len() == 2 {
            let root = hasher.root_cv(&last[0], &last[1]);
            layers.push(vec![root]);
        }

        Self {
            key,
            layers,
            data: data.to_vec(),
        }
    }

    /// The BLAKE3 key this tree was built with.
    pub fn key(&self) -> Digest {
        self.key
    }

    pub fn root(&self) -> Digest {
        self.layers.last().map(|l| l[0]).unwrap_or([0u8; OUT_LEN])
    }

    pub fn leaf_hashes(&self) -> &[Digest] {
        &self.layers[0]
    }

    pub fn num_leaves(&self) -> usize {
        self.layers[0].len()
    }

    /// Generate a multi-leaf proof. Returns a complete `MerkleProof`.
    pub fn get_multileaf_proof(&self, leaf_indices: &[usize]) -> MerkleProof {
        assert!(!leaf_indices.is_empty(), "leaf_indices must be non-empty");

        let unique: BTreeSet<usize> = leaf_indices.iter().copied().collect();
        let total_leaves = self.num_leaves();

        assert!(
            *unique.last().unwrap() < total_leaves,
            "leaf index out of bounds"
        );

        // Collect leaf data
        let sorted_indices: Vec<usize> = unique.iter().copied().collect();
        let leaf_data: Vec<[u8; CHUNK_LEN]> = sorted_indices
            .iter()
            .map(|&i| {
                let start = i * CHUNK_LEN;
                let end = (start + CHUNK_LEN).min(self.data.len());
                let mut chunk = [0u8; CHUNK_LEN];
                chunk[..end - start].copy_from_slice(&self.data[start..end]);
                chunk
            })
            .collect();

        // Walk tree level-by-level to collect sibling hashes
        let mut siblings: Vec<Digest> = Vec::new();
        let mut current_set = unique;
        let mut level_len = total_leaves;

        let mut level = 0;
        while level_len > 1 && !current_set.is_empty() {
            let level_nodes = &self.layers[level];

            for &i in &current_set {
                if i % 2 == 1 {
                    if !current_set.contains(&(i - 1)) {
                        siblings.push(level_nodes[i - 1]);
                    }
                } else if !current_set.contains(&(i + 1)) && (i + 1) < level_len {
                    siblings.push(level_nodes[i + 1]);
                }
            }

            current_set = current_set.iter().map(|&i| i / 2).collect();
            level_len = level_len.div_ceil(2);
            level += 1;
        }

        MerkleProof {
            leaf_data,
            leaf_indices: sorted_indices,
            total_leaves,
            root: self.root(),
            siblings,
        }
    }

    /// Compute which leaf indices are needed to prove the given matrix rows.
    pub fn compute_leaf_indices_from_rows(
        row_indices: &[usize],
        shape: (usize, usize),
    ) -> Vec<usize> {
        let cols = shape.1;
        let mut indices = BTreeSet::new();
        for &row in row_indices {
            let first = (row * cols) / CHUNK_LEN;
            let last = ((row + 1) * cols - 1) / CHUNK_LEN;
            for i in first..=last {
                indices.insert(i);
            }
        }
        indices.into_iter().collect()
    }
}

// ============================================================================
// MerkleProof
// ============================================================================

/// Generic multi-leaf Merkle proof, domain-agnostic.
#[derive(Clone)]
#[cfg_attr(feature = "pyo3", pyo3::pyclass(name = "MerkleProof"))]
#[cfg_attr(
    feature = "serde",
    derive(serde::Serialize, serde::Deserialize),
    serde(crate = "serde")
)]
pub struct MerkleProof {
    #[cfg_attr(feature = "serde", serde(with = "serde_chunk_vec"))]
    pub leaf_data: Vec<[u8; CHUNK_LEN]>,
    pub leaf_indices: Vec<usize>,
    pub total_leaves: usize,
    pub root: Digest,
    pub siblings: Vec<Digest>,
}

impl std::fmt::Debug for MerkleProof {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("MerkleProof")
            .field("leaf_indices", &self.leaf_indices)
            .field("total_leaves", &self.total_leaves)
            .field("root", &self.root)
            .field("leaf_count", &self.leaf_data.len())
            .field("sibling_count", &self.siblings.len())
            .finish()
    }
}

impl MerkleProof {
    /// Validate proof structure.
    pub fn sanity_check(&self) -> Result<()> {
        ensure!(
            !self.leaf_indices.is_empty(),
            "leaf_indices must be non-empty"
        );
        ensure!(
            self.leaf_indices.len() == self.leaf_data.len(),
            "leaf_indices and leaf_data must have the same length"
        );
        ensure!(
            self.leaf_indices.windows(2).all(|w| w[0] < w[1]),
            "leaf_indices must be sorted and unique"
        );
        Ok(())
    }

    /// Compute leaf hashes (chunk CVs) from the raw leaf data.
    pub fn leaf_hashes(&self, key: Digest) -> Vec<Digest> {
        let hasher = Blake3Hasher::with_key(key);
        self.leaf_indices
            .par_iter()
            .zip(self.leaf_data.par_iter())
            .map(|(&idx, data)| hasher.chunk_cv(data, idx as u64))
            .collect()
    }

    /// Reconstruct the Merkle root from leaf hashes and proof siblings.
    /// Returns `None` if the proof has incorrect shape.
    pub fn compute_root(&self, key: Digest) -> Option<Digest> {
        if self.leaf_indices.is_empty() {
            return None;
        }

        let hasher = Blake3Hasher::with_key(key);
        let leaf_hashes = self.leaf_hashes(key);

        let mut current: BTreeMap<usize, Digest> =
            self.leaf_indices.iter().copied().zip(leaf_hashes).collect();
        let mut level_len = self.total_leaves;

        if level_len == 1 {
            return if self.siblings.is_empty() {
                Some(current[&0])
            } else {
                None
            };
        }

        let mut sib_iter = self.siblings.iter();

        while level_len > 2 {
            let mut next: BTreeMap<usize, Digest> = BTreeMap::new();

            for (&i, &cv) in &current {
                if i % 2 == 0 {
                    let left = cv;
                    let right = if let Some(&r) = current.get(&(i + 1)) {
                        Some(r)
                    } else if (i + 1) < level_len {
                        Some(*sib_iter.next()?)
                    } else {
                        None
                    };
                    next.insert(
                        i / 2,
                        match right {
                            Some(r) => hasher.parent_cv(&left, &r),
                            None => left,
                        },
                    );
                } else if current.contains_key(&(i - 1)) {
                    continue;
                } else {
                    let right = cv;
                    let left = *sib_iter.next()?;
                    next.insert(i / 2, hasher.parent_cv(&left, &right));
                }
            }

            current = next;
            level_len = level_len.div_ceil(2);
        }

        let left = match current.get(&0) {
            Some(&v) => v,
            None => *sib_iter.next()?,
        };
        let right = match current.get(&1) {
            Some(&v) => v,
            None => *sib_iter.next()?,
        };

        if sib_iter.next().is_some() {
            return None;
        }

        Some(hasher.root_cv(&left, &right))
    }

    /// Verify that the proof reconstructs the stored root.
    pub fn verify(&self, key: Digest) -> bool {
        self.compute_root(key) == Some(self.root)
    }

    /// Extract bytes from sparse merkle leaves.
    pub fn extract_bytes(&self, global_start: usize, length: usize) -> Result<Vec<u8>> {
        let mut result = vec![0u8; length];
        let global_end = global_start + length;
        let mut copied = 0;

        for (&leaf_idx, data) in self.leaf_indices.iter().zip(&self.leaf_data) {
            let leaf_start = leaf_idx * CHUNK_LEN;
            let leaf_end = leaf_start + CHUNK_LEN;
            if leaf_start < global_end && global_start < leaf_end {
                let copy_start = global_start.max(leaf_start);
                let copy_end = global_end.min(leaf_end);
                let len = copy_end - copy_start;
                result[copy_start - global_start..][..len]
                    .copy_from_slice(&data[copy_start - leaf_start..][..len]);
                copied += len;
            }
        }
        ensure!(copied == length, "Not all required bytes covered by leaves");
        Ok(result)
    }

    /// Compute byte ranges covered by proof siblings.
    pub fn compute_sibling_ranges(&self, total_size: usize) -> Vec<(usize, usize, Digest)> {
        if self.leaf_indices.is_empty() || self.siblings.is_empty() {
            return Vec::new();
        }

        let mut current: BTreeSet<usize> = self.leaf_indices.iter().copied().collect();

        let mut result = Vec::new();
        let mut proof_idx = 0;
        let mut level_size = total_size.div_ceil(CHUNK_LEN);
        let mut level = 0;

        while level_size > 1 && !current.is_empty() && proof_idx < self.siblings.len() {
            let mut next = BTreeSet::new();
            for &idx in &current {
                let sib = if idx % 2 == 0 { idx + 1 } else { idx - 1 };
                let need_sib = if idx % 2 == 1 {
                    !current.contains(&sib)
                } else {
                    sib < level_size && !current.contains(&sib)
                };

                if need_sib && proof_idx < self.siblings.len() {
                    let chunk = CHUNK_LEN << level;
                    result.push((
                        sib * chunk,
                        ((sib + 1) * chunk).min(total_size),
                        self.siblings[proof_idx],
                    ));
                    proof_idx += 1;
                }
                next.insert(idx / 2);
            }
            current = next;
            level_size = level_size.div_ceil(2);
            level += 1;
        }
        result
    }

    /// Recursively compute a CV for a byte range from sibling ranges and leaf data.
    pub fn compute_cv(
        &self,
        start: usize,
        end: usize,
        ranges: &[(usize, usize, Digest)],
        key: Digest,
    ) -> Result<Digest> {
        if let Some(&(_, _, h)) = ranges.iter().find(|(s, e, _)| *s == start && *e == end) {
            return Ok(h);
        }
        if end - start == CHUNK_LEN {
            let data = self.extract_bytes(start, end - start)?;
            return Ok(Blake3Hasher::with_key(key).chunk_cv(&data, (start / CHUNK_LEN) as u64));
        }
        let mid = start + (end - start).next_power_of_two() / 2;
        let hasher = Blake3Hasher::with_key(key);
        let left = self.compute_cv(start, mid, ranges, key)?;
        let right = self.compute_cv(mid, end, ranges, key)?;
        Ok(hasher.parent_cv(&left, &right))
    }
}

// ============================================================================
// Serde helpers for fixed-size arrays
// ============================================================================

#[cfg(feature = "serde")]
mod serde_chunk_vec {
    use blake3::CHUNK_LEN;
    use serde::{Deserialize, Deserializer, Serialize, Serializer};

    pub fn serialize<S: Serializer>(
        data: &[[u8; CHUNK_LEN]],
        serializer: S,
    ) -> Result<S::Ok, S::Error> {
        let vecs: Vec<&[u8]> = data.iter().map(|a| a.as_slice()).collect();
        vecs.serialize(serializer)
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(
        deserializer: D,
    ) -> Result<Vec<[u8; CHUNK_LEN]>, D::Error> {
        let vecs: Vec<Vec<u8>> = Vec::deserialize(deserializer)?;
        vecs.into_iter()
            .map(|v| {
                v.try_into()
                    .map_err(|_| serde::de::Error::custom("leaf data must be CHUNK_LEN bytes"))
            })
            .collect()
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    fn test_data(size: usize) -> Vec<u8> {
        (0..size).map(|i| (i % 256) as u8).collect()
    }

    fn test_key() -> Digest {
        *b"0123456789abcdef0123456789abcdef"
    }

    fn assert_proofs_equal(actual: &MerkleProof, expected: &MerkleProof) {
        assert_eq!(actual.leaf_data, expected.leaf_data);
        assert_eq!(actual.leaf_indices, expected.leaf_indices);
        assert_eq!(actual.total_leaves, expected.total_leaves);
        assert_eq!(actual.root, expected.root);
        assert_eq!(actual.siblings, expected.siblings);
    }

    fn assert_sparse_matches_dense(
        total_leaves: usize,
        subtree_height: u32,
        prefix_len: usize,
        known_start_node: usize,
        requested: &[usize],
    ) {
        let key = test_key();
        let leaves_per_subtree = 1usize << subtree_height;
        assert!(total_leaves > leaves_per_subtree);
        assert!(prefix_len <= known_start_node * leaves_per_subtree * CHUNK_LEN);

        let sparse_prefix: Vec<u8> = (0..prefix_len)
            .map(|i| (i.wrapping_mul(131).wrapping_add(17) % 251) as u8)
            .collect();
        let mut dense = vec![0u8; total_leaves * CHUNK_LEN];
        dense[..prefix_len].copy_from_slice(&sparse_prefix);
        let tree = MerkleTree::new(&dense, key);

        let base_nodes = &tree.layers[subtree_height as usize];
        assert_eq!(base_nodes.len(), total_leaves.div_ceil(leaves_per_subtree));
        assert!(known_start_node <= base_nodes.len());

        let actual = sparse_zero_multileaf_proof(
            &sparse_prefix,
            dense.len(),
            key,
            requested,
            subtree_height,
            known_start_node * leaves_per_subtree,
            &base_nodes[known_start_node..],
            tree.root(),
        )
        .unwrap();
        let expected = tree.get_multileaf_proof(requested);
        assert_proofs_equal(&actual, &expected);
    }

    #[test]
    fn test_sparse_filled_randomized_dense_equivalence() {
        // 192 comparisons, including ragged trees, original API compatibility,
        // whole/partial/no trusted suffix and duplicate unsorted requests.
        for fill in [0u8, 64, 192, 255] {
            for seed in 0usize..48 {
                let h = (seed % 5) as u32;
                let span = 1usize << h;
                let leaves = span + 1 + (seed * 37 % (3 * span + 11));
                let count = leaves.div_ceil(span);
                let start = seed % (count + 1);
                let prefix_len = (seed * 97).min(start * span * CHUNK_LEN).min(leaves * CHUNK_LEN);
                let prefix: Vec<u8> = (0..prefix_len).map(|i| (i * 13 + seed) as u8).collect();
                let mut dense = vec![fill; leaves * CHUNK_LEN];
                dense[..prefix_len].copy_from_slice(&prefix);
                let key = test_key();
                let tree = MerkleTree::new(&dense, key);
                let roots = &tree.layers[h as usize][start..];
                let requested = [leaves - 1, seed % leaves, 0, leaves - 1];
                let actual = sparse_filled_multileaf_proof(&prefix, fill, dense.len(), key,
                    &requested, h, start * span, roots, tree.root()).unwrap();
                assert_proofs_equal(&actual, &tree.get_multileaf_proof(&requested));
                if fill == 0 {
                    assert_proofs_equal(&actual, &sparse_zero_multileaf_proof(&prefix, dense.len(), key,
                        &requested, h, start * span, roots, tree.root()).unwrap());
                }
            }
        }
    }

    #[test]
    fn test_sparse_filled_single_base_and_leaf_fallbacks() {
        for fill in [0u8, 64, 192, 255] {
            for h in 1..5u32 {
                let leaves = 1usize << h;
                let prefix = b"nonce";
                let mut dense = vec![fill; leaves * CHUNK_LEN];
                dense[..prefix.len()].copy_from_slice(prefix);
                let tree = MerkleTree::new(&dense, test_key());
                let requested = [leaves - 1, 0];
                let actual = sparse_filled_multileaf_proof(prefix, fill, dense.len(), test_key(),
                    &requested, h, leaves, &[], tree.root()).unwrap();
                assert_proofs_equal(&actual, &tree.get_multileaf_proof(&requested));
            }
        }
    }

    #[test]
    fn test_sparse_filled_level7_ragged_tail() {
        for fill in [64u8, 192, 255] {
            let mut dense = vec![fill; (3 * 128 + 17) * CHUNK_LEN];
            let prefix = b"nonce-12345";
            dense[..prefix.len()].copy_from_slice(prefix);
            let tree = MerkleTree::new(&dense, test_key());
            let requested = [400, 0, 127, 128, 255, 256, 400];
            let actual = sparse_filled_multileaf_proof(prefix, fill, dense.len(), test_key(),
                &requested, 7, 256, &tree.layers[7][2..], tree.root()).unwrap();
            assert_proofs_equal(&actual, &tree.get_multileaf_proof(&requested));
        }
    }

    #[test]
    fn test_sparse_filled_explicitly_rejects_single_leaf() {
        for fill in [0u8, 64, 192, 255] {
            let dense = vec![fill; CHUNK_LEN];
            let tree = MerkleTree::new(&dense, test_key());
            let error = sparse_filled_multileaf_proof(&[], fill, CHUNK_LEN, test_key(),
                &[0], 0, 1, &[], tree.root()).unwrap_err();
            assert!(error.to_string().contains("single-leaf"));
        }
    }

    #[test]
    fn test_sparse_filled_rejects_wrong_fill_roots_and_layout() {
        let data = vec![64u8; 37 * CHUNK_LEN];
        let tree = MerkleTree::new(&data, test_key());
        let roots = &tree.layers[3];
        let build = |fill, len, start, known: &[Digest], root| {
            sparse_filled_multileaf_proof(&[], fill, len, test_key(), &[0, 36], 3, start, known, root)
        };
        assert!(build(64, data.len(), 0, roots, tree.root()).is_ok());
        // Even with a completely trusted suffix, wrong reopened bytes fail.
        assert!(build(0, data.len(), 0, roots, tree.root()).is_err());
        // A missing prefix of CVs reconstructed with the wrong fill also fails.
        assert!(build(192, data.len(), 8, &roots[1..], tree.root()).is_err());
        let mut bad_root = tree.root(); bad_root[0] ^= 1;
        assert!(build(64, data.len(), 0, roots, bad_root).is_err());
        let mut bad_roots = roots.to_vec(); bad_roots[1][0] ^= 1;
        assert!(build(64, data.len(), 0, &bad_roots, tree.root()).is_err());
        assert!(build(64, data.len()-1, 0, roots, tree.root()).is_err());
        assert!(build(64, data.len(), 1, roots, tree.root()).is_err());
        assert!(build(64, data.len(), 0, &roots[1..], tree.root()).is_err());
    }

    // ---- Sparse-zero proof generation ----

    #[test]
    fn test_sparse_zero_level7_proof_matches_dense_tree() {
        // Mirrors tensor_hash's default 128-leaf base subtrees. The first two
        // scratch roots are treated as overwritten and reconstructed from the
        // ten-byte nonce prefix plus implicit zeros.
        assert_sparse_matches_dense(
            3 * 128 + 17,
            7,
            10,
            2,
            &[400, 0, 1, 127, 128, 255, 256, 400],
        );
    }

    #[test]
    fn test_sparse_zero_can_use_the_entire_known_root_suffix() {
        assert_sparse_matches_dense(37, 3, 0, 0, &[0, 8, 9, 36]);
    }

    #[test]
    fn test_sparse_zero_randomized_equivalence() {
        // Property-style coverage across ragged trees, subtree heights, prefix
        // sizes, duplicate/unsorted requests, and varying known-root suffixes.
        for seed in 0u64..48 {
            let subtree_height = (seed % 5) as u32;
            let leaves_per_subtree = 1usize << subtree_height;
            let total_leaves =
                leaves_per_subtree + 1 + ((seed as usize * 37) % (3 * leaves_per_subtree + 11));
            let base_node_count = total_leaves.div_ceil(leaves_per_subtree);
            let known_start_node = 1 + (seed as usize % base_node_count);
            let prefix_limit = known_start_node * leaves_per_subtree * CHUNK_LEN;
            let prefix_len = (1 + seed as usize * 97).min(prefix_limit);

            let selected_count = 1 + seed as usize % total_leaves.min(9);
            let mut state = seed.wrapping_add(1);
            let mut requested = Vec::with_capacity(selected_count + 1);
            for _ in 0..selected_count {
                state = state.wrapping_mul(6364136223846793005).wrapping_add(1);
                requested.push(state as usize % total_leaves);
            }
            requested.reverse();
            requested.push(requested[0]);

            assert_sparse_matches_dense(
                total_leaves,
                subtree_height,
                prefix_len,
                known_start_node,
                &requested,
            );
        }
    }

    #[test]
    fn test_sparse_zero_single_base_node_fallback() {
        let key = test_key();
        let total_leaves = 8;
        let prefix = b"small-prefix";
        let mut dense = vec![0u8; total_leaves * CHUNK_LEN];
        dense[..prefix.len()].copy_from_slice(prefix);
        let tree = MerkleTree::new(&dense, key);

        let actual = sparse_zero_multileaf_proof(
            prefix,
            dense.len(),
            key,
            &[7, 0, 3],
            3,
            total_leaves,
            &[],
            tree.root(),
        )
        .unwrap();
        assert_proofs_equal(&actual, &tree.get_multileaf_proof(&[7, 0, 3]));
    }

    #[test]
    fn test_sparse_zero_rejects_invalid_layout_and_roots() {
        let key = test_key();
        let total_leaves = 32;
        let subtree_height = 3;
        let leaves_per_subtree = 1usize << subtree_height;
        let prefix = b"nonce";
        let mut dense = vec![0u8; total_leaves * CHUNK_LEN];
        dense[..prefix.len()].copy_from_slice(prefix);
        let tree = MerkleTree::new(&dense, key);
        let roots = &tree.layers[subtree_height as usize][1..];
        let valid = || {
            sparse_zero_multileaf_proof(
                prefix,
                dense.len(),
                key,
                &[0, 17],
                subtree_height,
                leaves_per_subtree,
                roots,
                tree.root(),
            )
        };
        assert!(valid().is_ok());

        assert!(sparse_zero_multileaf_proof(
            prefix,
            dense.len() - 1,
            key,
            &[0],
            subtree_height,
            leaves_per_subtree,
            roots,
            tree.root(),
        )
        .unwrap_err()
        .to_string()
        .contains("aligned"));

        assert!(sparse_zero_multileaf_proof(
            prefix,
            dense.len(),
            key,
            &[0],
            subtree_height,
            leaves_per_subtree + 1,
            roots,
            tree.root(),
        )
        .unwrap_err()
        .to_string()
        .contains("aligned"));

        assert!(sparse_zero_multileaf_proof(
            prefix,
            dense.len(),
            key,
            &[0],
            subtree_height,
            leaves_per_subtree,
            &roots[1..],
            tree.root(),
        )
        .unwrap_err()
        .to_string()
        .contains("complete suffix"));

        let prefix_past_boundary = vec![1u8; leaves_per_subtree * CHUNK_LEN + 1];
        assert!(sparse_zero_multileaf_proof(
            &prefix_past_boundary,
            dense.len(),
            key,
            &[0],
            subtree_height,
            leaves_per_subtree,
            roots,
            tree.root(),
        )
        .unwrap_err()
        .to_string()
        .contains("extends into"));

        let mut wrong_root = tree.root();
        wrong_root[0] ^= 1;
        assert!(sparse_zero_multileaf_proof(
            prefix,
            dense.len(),
            key,
            &[0],
            subtree_height,
            leaves_per_subtree,
            roots,
            wrong_root,
        )
        .unwrap_err()
        .to_string()
        .contains("expected_root"));

        assert!(sparse_zero_multileaf_proof(
            prefix,
            dense.len(),
            key,
            &[total_leaves],
            subtree_height,
            leaves_per_subtree,
            roots,
            tree.root(),
        )
        .unwrap_err()
        .to_string()
        .contains("out of bounds"));
    }

    #[test]
    fn test_sparse_zero_rejects_known_root_inconsistent_with_zero_leaf() {
        let key = test_key();
        let total_leaves = 32;
        let subtree_height = 3;
        let leaves_per_subtree = 1usize << subtree_height;

        // The supplied roots and expected root are mutually consistent, but a
        // byte in their claimed zero suffix is actually non-zero. Selecting
        // that leaf must be rejected by the final independent proof check.
        let mut contradictory_dense = vec![0u8; total_leaves * CHUNK_LEN];
        contradictory_dense[9 * CHUNK_LEN + 7] = 1;
        let contradictory_tree = MerkleTree::new(&contradictory_dense, key);
        let roots = &contradictory_tree.layers[subtree_height as usize][1..];

        let error = sparse_zero_multileaf_proof(
            &[],
            contradictory_dense.len(),
            key,
            &[9],
            subtree_height,
            leaves_per_subtree,
            roots,
            contradictory_tree.root(),
        )
        .unwrap_err();
        assert!(error.to_string().contains("inconsistent"));
    }

    // ---- Tree construction ----

    #[test]
    fn test_root_matches_blake3_hash() {
        let key = test_key();
        for num_chunks in [1, 2, 3, 5, 7, 10] {
            let data = test_data(num_chunks * CHUNK_LEN);
            let tree = MerkleTree::new(&data, key);
            let expected = Blake3Hasher::with_key(key).hash(&data);
            assert_eq!(
                tree.root(),
                expected,
                "Root mismatch for {num_chunks} chunks"
            );
        }
    }

    #[test]
    fn test_root_matches_partial_last_chunk() {
        let key = test_key();
        for size in [1, 100, 1023, 1025, 2000, 3000, 7777] {
            let data = test_data(size);
            let tree = MerkleTree::new(&data, key);
            let expected = Blake3Hasher::with_key(key).hash(&data);
            assert_eq!(tree.root(), expected, "Root mismatch for size {size}");
        }
    }

    #[test]
    fn test_leaf_count() {
        let key = test_key();
        for (size, expected_leaves) in [(1024, 1), (2048, 2), (3072, 3), (1025, 2), (100, 1)] {
            let data = test_data(size);
            let tree = MerkleTree::new(&data, key);
            assert_eq!(
                tree.num_leaves(),
                expected_leaves,
                "Wrong leaf count for size {size}"
            );
        }
    }

    #[test]
    fn test_single_leaf_tree() {
        let key = test_key();
        let data = test_data(CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);
        assert_eq!(tree.key(), key);
        assert_eq!(tree.num_leaves(), 1);
        assert_eq!(tree.root(), tree.leaf_hashes()[0]);
    }

    // ---- Proof generation + verification ----

    #[test]
    fn test_single_leaf_proof() {
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, test_key());

        for idx in [0, 2, 4, 7] {
            let proof = tree.get_multileaf_proof(&[idx]);
            assert!(
                proof.verify(tree.key()),
                "Single leaf proof failed for index {idx}"
            );
        }
    }

    #[test]
    fn test_multi_leaf_proof_consecutive() {
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, test_key());

        let proof = tree.get_multileaf_proof(&[0, 1]);
        assert!(proof.verify(tree.key()));

        let proof = tree.get_multileaf_proof(&[2, 3, 4]);
        assert!(proof.verify(tree.key()));
    }

    #[test]
    fn test_multi_leaf_proof_non_consecutive() {
        let key = test_key();
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        for indices in [
            vec![0, 2],
            vec![0, 3],
            vec![1, 3, 5],
            vec![0, 1, 4, 5],
            vec![0, 2, 3, 7],
        ] {
            let proof = tree.get_multileaf_proof(&indices);
            assert!(proof.verify(key), "Proof failed for indices {indices:?}");
        }
    }

    #[test]
    fn test_proof_dedup_and_ordering() {
        let key = test_key();
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        let proof1 = tree.get_multileaf_proof(&[5, 3, 4, 3]);
        let proof2 = tree.get_multileaf_proof(&[3, 4, 5]);
        assert_eq!(proof1.siblings, proof2.siblings);
        assert!(proof1.verify(key));
    }

    #[test]
    fn test_full_tree_proof() {
        let key = test_key();
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        let all: Vec<usize> = (0..tree.num_leaves()).collect();
        let proof = tree.get_multileaf_proof(&all);
        assert!(proof.verify(key));
        assert!(proof.siblings.is_empty());
    }

    #[test]
    fn test_small_tree_3_leaves() {
        let key = test_key();
        let data = test_data(3 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);
        assert_eq!(tree.num_leaves(), 3);

        for i in 0..3 {
            let proof = tree.get_multileaf_proof(&[i]);
            assert!(proof.verify(key), "3-leaf tree: single leaf {i} failed");
        }

        let proof = tree.get_multileaf_proof(&[0, 2]);
        assert!(proof.verify(key));
    }

    #[test]
    fn test_4_leaf_proof_lengths() {
        let key = test_key();
        let data = test_data(4 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        let adjacent = tree.get_multileaf_proof(&[0, 1]);
        let cross = tree.get_multileaf_proof(&[0, 2]);
        let all = tree.get_multileaf_proof(&[0, 1, 2, 3]);

        assert_eq!(adjacent.siblings.len(), 1);
        assert_eq!(cross.siblings.len(), 2);
        assert_eq!(all.siblings.len(), 0);
    }

    // ---- Verification rejection ----

    #[test]
    fn test_reject_wrong_leaf_data() {
        let key = test_key();
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        let mut proof = tree.get_multileaf_proof(&[2, 3]);
        proof.leaf_data[0] = [0xFFu8; CHUNK_LEN];
        assert!(!proof.verify(key));
    }

    #[test]
    fn test_reject_wrong_root() {
        let key = test_key();
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        let mut proof = tree.get_multileaf_proof(&[1, 2]);
        proof.root = [0xAA; OUT_LEN];
        assert!(!proof.verify(key));
    }

    #[test]
    fn test_reject_wrong_indices() {
        let key = test_key();
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        let mut proof = tree.get_multileaf_proof(&[2, 3]);
        proof.leaf_indices = vec![3, 4];
        assert!(!proof.verify(key));
    }

    #[test]
    fn test_reject_extra_siblings() {
        let key = test_key();
        let data = test_data(8 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        let mut proof = tree.get_multileaf_proof(&[0, 2, 5]);
        proof.siblings.push([0xBB; OUT_LEN]);
        assert!(!proof.verify(key));
    }

    // ---- Randomized round-trips ----

    #[test]
    fn test_random_round_trips() {
        use std::collections::HashSet;
        let key = test_key();

        for seed in 0u64..20 {
            let n = 3 + (seed % 20) as usize;
            let data = test_data(n * CHUNK_LEN);
            let tree = MerkleTree::new(&data, key);

            let num_selected = 1 + (seed as usize % tree.num_leaves());
            let mut indices: HashSet<usize> = HashSet::new();
            let mut val = seed;
            while indices.len() < num_selected {
                val = val.wrapping_mul(6364136223846793005).wrapping_add(1);
                indices.insert((val as usize) % tree.num_leaves());
            }
            let mut indices: Vec<usize> = indices.into_iter().collect();
            indices.sort();

            let proof = tree.get_multileaf_proof(&indices);
            assert!(
                proof.verify(key),
                "Random round-trip failed: n={n}, indices={indices:?}"
            );
        }
    }

    // ---- compute_leaf_indices_from_rows ----

    #[test]
    fn test_leaf_indices_from_rows() {
        // 4 rows of 1024 bytes each = 4 leaves, 1:1 mapping
        let indices = MerkleTree::compute_leaf_indices_from_rows(&[0, 2], (4, CHUNK_LEN));
        assert_eq!(indices, vec![0, 2]);

        // 4 rows of 512 bytes each = 2 leaves (2 rows per leaf)
        let indices = MerkleTree::compute_leaf_indices_from_rows(&[0, 2], (4, 512));
        assert_eq!(indices, vec![0, 1]);

        // Row spans two leaves
        let indices = MerkleTree::compute_leaf_indices_from_rows(&[0], (2, 1500));
        assert_eq!(indices, vec![0, 1]);
    }

    // ---- extract_bytes ----

    #[test]
    fn test_extract_bytes() {
        let key = test_key();
        let data = test_data(4 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);
        let proof = tree.get_multileaf_proof(&[1, 2]);

        let extracted = proof.extract_bytes(CHUNK_LEN, 64).unwrap();
        assert_eq!(extracted, &data[CHUNK_LEN..CHUNK_LEN + 64]);

        // Spanning two leaves
        let extracted = proof.extract_bytes(2 * CHUNK_LEN - 32, 64).unwrap();
        assert_eq!(extracted, &data[2 * CHUNK_LEN - 32..2 * CHUNK_LEN + 32]);
    }

    #[test]
    fn test_extract_bytes_fails_for_missing_leaves() {
        let key = test_key();
        let data = test_data(4 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);
        let proof = tree.get_multileaf_proof(&[1]);

        // Leaf 0 not in proof
        assert!(proof.extract_bytes(0, 64).is_err());
    }

    // ---- compute_sibling_ranges + compute_cv ----

    #[test]
    fn test_compute_sibling_ranges() {
        let key = test_key();
        let data = test_data(4 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);
        let proof = tree.get_multileaf_proof(&[0]);

        let total_size = data.len();
        let ranges = proof.compute_sibling_ranges(total_size);
        assert!(!ranges.is_empty());

        for (start, end, _hash) in &ranges {
            assert!(*start < *end);
            assert!(*end <= total_size);
        }
    }

    #[test]
    fn test_compute_cv_round_trip() {
        let key = test_key();
        let data = test_data(4 * CHUNK_LEN);
        let tree = MerkleTree::new(&data, key);

        let all_indices: Vec<usize> = (0..4).collect();
        let proof = tree.get_multileaf_proof(&all_indices);
        let ranges = proof.compute_sibling_ranges(data.len());

        let cv = proof.compute_cv(0, CHUNK_LEN, &ranges, key).unwrap();
        let expected = Blake3Hasher::with_key(key).chunk_cv(&data[..CHUNK_LEN], 0);
        assert_eq!(cv, expected);
    }

    // ---- Sanity check ----

    #[test]
    fn test_sanity_check() {
        let proof = MerkleProof {
            leaf_data: vec![[0u8; CHUNK_LEN], [1u8; CHUNK_LEN]],
            leaf_indices: vec![0, 2],
            total_leaves: 4,
            root: [0u8; OUT_LEN],
            siblings: vec![],
        };
        assert!(proof.sanity_check().is_ok());

        let bad = MerkleProof {
            leaf_data: vec![],
            leaf_indices: vec![],
            total_leaves: 0,
            root: [0u8; OUT_LEN],
            siblings: vec![],
        };
        assert!(bad.sanity_check().is_err());

        let unsorted = MerkleProof {
            leaf_data: vec![[0u8; CHUNK_LEN], [1u8; CHUNK_LEN]],
            leaf_indices: vec![2, 0],
            total_leaves: 4,
            root: [0u8; OUT_LEN],
            siblings: vec![],
        };
        assert!(unsorted.sanity_check().is_err());
    }

    #[test]
    fn test_padded_chunk_len() {
        assert_eq!(padded_chunk_len(0), 0);
        assert_eq!(padded_chunk_len(1), CHUNK_LEN);
        assert_eq!(padded_chunk_len(CHUNK_LEN - 1), CHUNK_LEN);
        assert_eq!(padded_chunk_len(CHUNK_LEN), CHUNK_LEN);
        assert_eq!(padded_chunk_len(CHUNK_LEN + 1), 2 * CHUNK_LEN);
        assert_eq!(padded_chunk_len(3 * CHUNK_LEN), 3 * CHUNK_LEN);
    }

    #[test]
    fn test_pad_to_chunk_boundary() {
        assert!(pad_to_chunk_boundary(&[]).is_empty());

        let single_byte = pad_to_chunk_boundary(&[1]);
        assert_eq!(single_byte.len(), CHUNK_LEN);
        assert_eq!(single_byte[0], 1);
        assert_eq!(single_byte[1], 0);

        let aligned = test_data(CHUNK_LEN);
        assert_eq!(pad_to_chunk_boundary(&aligned), aligned);

        let unaligned = test_data(CHUNK_LEN + 1);
        let padded = pad_to_chunk_boundary(&unaligned);
        assert_eq!(padded.len(), 2 * CHUNK_LEN);
        assert_eq!(&padded[..CHUNK_LEN + 1], &unaligned[..]);
        assert!(padded[CHUNK_LEN + 1..].iter().all(|&b| b == 0));
    }

    #[test]
    fn test_padded_tree_root_differs_from_unpadded() {
        let key = test_key();
        let data = test_data(CHUNK_LEN + 500);
        let padded = pad_to_chunk_boundary(&data);

        let tree_raw = MerkleTree::new(&data, key);
        let tree_padded = MerkleTree::new(&padded, key);

        assert_ne!(
            tree_raw.root(),
            tree_padded.root(),
            "Padded and unpadded trees must have different roots for non-aligned data"
        );
        assert_eq!(tree_padded.num_leaves(), 2);
        assert_eq!(tree_raw.num_leaves(), 2);
    }
}
