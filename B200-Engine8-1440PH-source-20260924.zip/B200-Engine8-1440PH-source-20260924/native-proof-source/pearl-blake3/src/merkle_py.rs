//! Python bindings for [`MerkleTree`] and [`MerkleProof`].
//!
//! Provides `#[pymethods]` implementations that extend the pyo3 classes defined in [`merkle`].

use blake3::{CHUNK_LEN, OUT_LEN};
use pyo3::{exceptions::PyValueError, pymethods, types::PyBytes, Bound, PyResult, Python};

use crate::hasher::Digest;
use crate::merkle::{sparse_filled_multileaf_proof, sparse_zero_multileaf_proof, MerkleProof, MerkleTree};

#[pymethods]
impl MerkleTree {
    #[new]
    #[pyo3(signature = (data, key))]
    fn py_new(data: &[u8], key: &[u8]) -> PyResult<Self> {
        let key: [u8; OUT_LEN] = key.try_into().map_err(|_| {
            PyValueError::new_err(format!(
                "key must be exactly {} bytes, got {}",
                OUT_LEN,
                key.len()
            ))
        })?;
        Ok(Self::new(data, key))
    }

    #[getter(root)]
    fn py_root<'py>(&self, py: Python<'py>) -> Bound<'py, PyBytes> {
        PyBytes::new(py, &self.root())
    }

    #[getter(leaf_hashes)]
    fn py_leaf_hashes<'py>(&self, py: Python<'py>) -> Vec<Bound<'py, PyBytes>> {
        self.leaf_hashes()
            .iter()
            .map(|h| PyBytes::new(py, h))
            .collect()
    }

    #[pyo3(name = "get_multileaf_proof")]
    fn py_get_multileaf_proof(&self, leaf_indices: Vec<usize>) -> MerkleProof {
        self.get_multileaf_proof(&leaf_indices)
    }

    /// Build a proof for `sparse_prefix || zeroes` without materializing the
    /// complete byte string. `known_subtree_roots` is a packed sequence of
    /// 32-byte CVs forming the complete untouched suffix at
    /// `subtree_height`.
    #[staticmethod]
    #[pyo3(name = "sparse_zero_multileaf_proof")]
    #[allow(clippy::too_many_arguments)]
    fn py_sparse_zero_multileaf_proof(
        py: Python<'_>,
        sparse_prefix: &[u8],
        total_len: usize,
        key: &[u8],
        leaf_indices: Vec<usize>,
        subtree_height: u32,
        known_roots_start_leaf: usize,
        known_subtree_roots: &[u8],
        expected_root: &[u8],
    ) -> PyResult<MerkleProof> {
        let key: Digest = key.try_into().map_err(|_| {
            PyValueError::new_err(format!(
                "key must be exactly {} bytes, got {}",
                OUT_LEN,
                key.len()
            ))
        })?;
        let expected_root: Digest = expected_root.try_into().map_err(|_| {
            PyValueError::new_err(format!(
                "expected_root must be exactly {} bytes, got {}",
                OUT_LEN,
                expected_root.len()
            ))
        })?;
        if known_subtree_roots.len().checked_rem(OUT_LEN) != Some(0) {
            return Err(PyValueError::new_err(format!(
                "known_subtree_roots must contain packed {}-byte roots, got {} bytes",
                OUT_LEN,
                known_subtree_roots.len()
            )));
        }
        let known_subtree_roots = known_subtree_roots
            .chunks(OUT_LEN)
            .map(|root| {
                root.try_into()
                    .expect("packed root length was validated above")
            })
            .collect::<Vec<Digest>>();
        let sparse_prefix = sparse_prefix.to_vec();

        // Hashing the missing base-root prefix can take measurable CPU time for
        // production matrices. All borrowed Python buffers have been copied at
        // this point, so it is safe to release the GIL for the entire operation.
        py.allow_threads(move || {
            sparse_zero_multileaf_proof(
                &sparse_prefix,
                total_len,
                key,
                &leaf_indices,
                subtree_height,
                known_roots_start_leaf,
                &known_subtree_roots,
                expected_root,
            )
            .map_err(|err| PyValueError::new_err(err.to_string()))
        })
    }

    /// Constant-background counterpart of sparse_zero_multileaf_proof.
    /// The byte prefix overrides the background, but no extra leaves are added.
    #[staticmethod]
    #[pyo3(name = "sparse_filled_multileaf_proof")]
    #[allow(clippy::too_many_arguments)]
    fn py_sparse_filled_multileaf_proof(
        py: Python<'_>,
        sparse_prefix: &[u8],
        fill_byte: u8,
        total_len: usize,
        key: &[u8],
        leaf_indices: Vec<usize>,
        subtree_height: u32,
        known_roots_start_leaf: usize,
        known_subtree_roots: &[u8],
        expected_root: &[u8],
    ) -> PyResult<MerkleProof> {
        let key: Digest = key.try_into().map_err(|_| {
            PyValueError::new_err(format!("key must be exactly {} bytes, got {}", OUT_LEN, key.len()))
        })?;
        let expected_root: Digest = expected_root.try_into().map_err(|_| {
            PyValueError::new_err(format!("expected_root must be exactly {} bytes, got {}", OUT_LEN, expected_root.len()))
        })?;
        if known_subtree_roots.len().checked_rem(OUT_LEN) != Some(0) {
            return Err(PyValueError::new_err(format!(
                "known_subtree_roots must contain packed {}-byte roots, got {} bytes", OUT_LEN, known_subtree_roots.len()
            )));
        }
        let roots = known_subtree_roots.chunks(OUT_LEN)
            .map(|root| root.try_into().expect("packed root length was validated above"))
            .collect::<Vec<Digest>>();
        let prefix = sparse_prefix.to_vec();
        py.allow_threads(move || {
            sparse_filled_multileaf_proof(&prefix, fill_byte, total_len, key, &leaf_indices,
                subtree_height, known_roots_start_leaf, &roots, expected_root)
                .map_err(|err| PyValueError::new_err(err.to_string()))
        })
    }

    #[staticmethod]
    #[pyo3(name = "compute_leaf_indices_from_rows")]
    fn py_compute_leaf_indices_from_rows(
        row_indices: Vec<usize>,
        shape: (usize, usize),
    ) -> Vec<usize> {
        Self::compute_leaf_indices_from_rows(&row_indices, shape)
    }
}

#[pymethods]
impl MerkleProof {
    #[new]
    fn py_new(
        leaf_data: Vec<Vec<u8>>,
        leaf_indices: Vec<usize>,
        root: &[u8],
        siblings: Vec<Vec<u8>>,
        total_leaves: usize,
    ) -> PyResult<Self> {
        let leaf_data: Vec<[u8; CHUNK_LEN]> = leaf_data
            .into_iter()
            .map(|v| {
                v.try_into().map_err(|_| {
                    PyValueError::new_err(format!("leaf data must be exactly {} bytes", CHUNK_LEN))
                })
            })
            .collect::<PyResult<_>>()?;
        let root: Digest = root.try_into().map_err(|_| {
            PyValueError::new_err(format!("root must be exactly {} bytes", OUT_LEN))
        })?;
        let siblings: Vec<Digest> = siblings
            .into_iter()
            .map(|v| {
                v.try_into().map_err(|_| {
                    PyValueError::new_err(format!(
                        "siblings entries must be exactly {} bytes",
                        OUT_LEN
                    ))
                })
            })
            .collect::<PyResult<_>>()?;
        Ok(Self {
            leaf_data,
            leaf_indices,
            total_leaves,
            root,
            siblings,
        })
    }
}
