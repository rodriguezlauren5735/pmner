"""CPU-only binding and serialization checks for the isolated filled proof API."""
import base64
import unittest
import pearl_mining as pm

KEY=bytes(range(32))


def serialized(proof,leaves,rows):
    matrix=pm.MatrixMerkleProof(proof=proof,row_indices=rows)
    # Container serialization only; these small fixture dimensions are NOT
    # public mining jobs. V3 policy is checked separately with real GPU cases.
    return base64.b64decode(pm.PlainProof(m=leaves,n=leaves,k=1024,noise_rank=128,
        a_merkle_proof=matrix,bt_merkle_proof=matrix,moe=None).to_base64(),validate=True)


class FilledProofBindingTests(unittest.TestCase):
    def test_dense_serialized_equivalence(self):
        count=0
        for fill in (0,64,192,255):
            for leaves in (2,3,7,8,9,17,129,257):
                for prefix in (b"",b"nonce-12345",bytes(range(256))*5):
                    data=prefix+bytes([fill])*(leaves*1024-len(prefix))
                    tree=pm.MerkleTree(data,KEY)
                    rows=sorted({0,leaves//2,leaves-1})
                    h=min(3,leaves.bit_length()-1);span=1<<h;start=((leaves+span-1)//span)*span
                    actual=pm.MerkleTree.sparse_filled_multileaf_proof(prefix,fill,len(data),KEY,rows,h,start,b"",tree.root)
                    expected=tree.get_multileaf_proof(rows)
                    self.assertEqual(serialized(actual,leaves,rows),serialized(expected,leaves,rows))
                    if fill==0:
                        zero=pm.MerkleTree.sparse_zero_multileaf_proof(prefix,len(data),KEY,rows,h,start,b"",tree.root)
                        self.assertEqual(serialized(actual,leaves,rows),serialized(zero,leaves,rows))
                    count+=1
        self.assertEqual(count,96)

    def test_rejects_wrong_background_and_root(self):
        data=b"\x40"*(9*1024);tree=pm.MerkleTree(data,KEY)
        for fill,root in ((0,tree.root),(64,b"\x01"*32)):
            with self.assertRaises(ValueError):
                pm.MerkleTree.sparse_filled_multileaf_proof(b"",fill,len(data),KEY,[0,8],3,16,b"",root)

    def test_byte_and_digest_boundaries(self):
        data=b"\x40"*2048;root=pm.MerkleTree(data,KEY).root
        for fill in (-1,256):
            with self.assertRaises((ValueError,OverflowError)):
                pm.MerkleTree.sparse_filled_multileaf_proof(b"",fill,len(data),KEY,[0],1,2,b"",root)
        for key,known,expected in ((b"bad",b"",root),(KEY,b"bad",root),(KEY,b"",b"bad")):
            with self.assertRaises(ValueError):
                pm.MerkleTree.sparse_filled_multileaf_proof(b"",64,len(data),key,[0],1,2,known,expected)

    def test_single_leaf_explicitly_rejected(self):
        data=b"\x40"*1024
        with self.assertRaisesRegex(ValueError,"single-leaf"):
            pm.MerkleTree.sparse_filled_multileaf_proof(b"",64,len(data),KEY,[0],0,1,b"",pm.MerkleTree(data,KEY).root)


if __name__=="__main__": unittest.main(verbosity=2)
