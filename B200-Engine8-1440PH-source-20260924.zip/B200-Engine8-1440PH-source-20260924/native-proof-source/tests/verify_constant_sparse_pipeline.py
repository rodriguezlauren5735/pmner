"""Isolated actual GPU roots -> constant-background sparse proof -> independent V3.

No network; the live client is not changed. Dense comparison is mandatory for
small cases and intentionally forbidden for production-sized matrix allocation.
"""
import argparse
import base64
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import time

import pearl_mining as pm
import torch
from miner_base.block_submission import create_proof
from pearl_gateway.comm.dataclasses import OpenedBlockInfo
from kryptex_h100_miner import (H100Engine, JobSnapshot, CertificateVersion, compact_to_target,
    sparse_hash_layout, encode_base128_nonce, create_sparse_plain_proof, require_live_profile,
    PearlMiningConfigurationFactory, TENSOR_HASH_SUBTREE_HEIGHT)

HEADER=bytes.fromhex("00000020d0c6e8483e11724095e82b739bdb511f02ba63bb2023cc0663a52079e2bfb097a65ef30a69c6ebce375322a046445350f53eac02516f6b39d78b73ea3e61451dbae89b6a64d90018")
NBITS=0x1D2FFFFF


def constant_plain_proof(result,m,n,k,rank,expected_config,a_fill,b_fill):
    if type(a_fill) is not int or type(b_fill) is not int or not (-64<=a_fill<=64 and -64<=b_fill<=64):
        raise ValueError("original matrix fills must be integers in [-64,64]")
    require_live_profile(rank,k,CertificateVersion.ZK_V3)
    material=result.proof_material
    if material is None or not result.found: raise ValueError("missing captured material")
    config=PearlMiningConfigurationFactory.create(common_dim=k,rank=rank,row_indices=result.a_rows,col_indices=result.b_columns)
    if config.to_bytes()!=expected_config: raise ValueError("GPU proof layout mismatch")
    matrices=[]
    for rows,shape,prefix,fill,known,root in (
        (result.a_rows,(m,k),bytes(v&255 for v in encode_base128_nonce(result.nonce)),a_fill,material.a_known_roots,material.root_a),
        (result.b_columns,(n,k),b"",b_fill,material.b_known_roots,material.root_b)):
        layout=sparse_hash_layout(shape[0]*shape[1])
        if len(known)!=layout.known_roots_byte_end-layout.known_roots_byte_start: raise ValueError("scratch suffix length")
        leaves=pm.MerkleTree.compute_leaf_indices_from_rows(rows,shape)
        proof=pm.MerkleTree.sparse_filled_multileaf_proof(prefix,fill&255,layout.total_len,material.key,leaves,
            TENSOR_HASH_SUBTREE_HEIGHT,layout.known_roots_start_leaf,known,root)
        matrices.append(pm.MatrixMerkleProof(proof=proof,row_indices=rows))
    return pm.PlainProof(m=m,n=n,k=k,noise_rank=rank,a_merkle_proof=matrices[0],bt_merkle_proof=matrices[1],moe=None)


def canonical(proof): return base64.b64decode(proof.to_base64(),validate=True)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--production",action="store_true")
    args=p.parse_args()
    interfaces={v.split(":",1)[0].strip() for v in Path("/proc/net/dev").read_text().splitlines()[2:]}
    if interfaces!={"lo"}: raise SystemExit("isolated namespace required")
    m,n=(131072,261888) if args.production else (4096,6144);k=8192
    e=H100Engine(m=m,n=n,k=k,rank=128,tile_size_k=128,cluster_size_m=1,cluster_size_n=1,pipeline_stages=2,swizzle=12,swizzle_n_maj=False)
    config=e.matmul_config.mining_config.to_bytes();records=[]
    cases=((64,64,123456789),(64,64,(1<<70)-1)) if args.production else ((0,0,123456789),(64,64,123456789),(-64,-64,1),(64,-64,(1<<70)-1))
    for index,(a_fill,b_fill,nonce) in enumerate(cases):
        header=bytearray(HEADER);header[40]^=index+1
        job=JobSnapshot(connection_epoch=1,job_epoch=index+1,job_id=f"offline-filled-{index}",header=bytes(header),
            target=compact_to_target(NBITS),share_nbits=NBITS,cert_version=CertificateVersion.ZK_V3,height=108951+index)
        e.A.fill_(a_fill);e.B.fill_(b_fill);e._job=None
        result=e.run_pass(job,nonce)
        if not result.found: raise AssertionError("easy offline job produced no candidate")
        before=time.perf_counter();proof=constant_plain_proof(result,m,n,k,128,config,a_fill,b_fill);seconds=time.perf_counter()-before
        data=canonical(proof)
        valid,reason=pm.verify_plain_proof_for_cert_version(3,pm.IncompleteBlockHeader.from_bytes(job.header),proof,nbits_override=NBITS)
        if not valid: raise AssertionError(f"independent V3: {reason}")
        if not args.production:
            dense=create_proof(OpenedBlockInfo(A_row_indices=result.a_rows,B_column_indices=result.b_columns,
                A=e.A.cpu(),B_t=e.B.cpu(),commitment_hash=None,noise_rank=128),job.header)
            if canonical(dense)!=data: raise AssertionError("dense/sparse serialized mismatch")
        if a_fill==b_fill==0:
            if canonical(create_sparse_plain_proof(result,m,n,k,128,config))!=data: raise AssertionError("zero API changed")
        material=result.proof_material
        changed=bytearray(material.a_known_roots);changed[len(changed)//2]^=1
        negatives=[replace(result,proof_material=replace(material,a_known_roots=bytes(changed))),
                   replace(result,proof_material=replace(material,root_a=bytes([material.root_a[0]^1])+material.root_a[1:]))]
        for invalid in negatives:
            try: constant_plain_proof(invalid,m,n,k,128,config,a_fill,b_fill)
            except ValueError: pass
            else: raise AssertionError("corrupted root accepted")
        if a_fill!=0 or b_fill!=0:
            try: constant_plain_proof(result,m,n,k,128,config,0,0)
            except ValueError: pass
            else: raise AssertionError("wrong zero background accepted")
        # Captured bytes must remain usable after the next GPU hash pass.
        e.run_pass(job,1 if nonce==(1<<70)-1 else nonce+1)
        if canonical(constant_plain_proof(result,m,n,k,128,config,a_fill,b_fill))!=data: raise AssertionError("scratch snapshot mutated")
        record=dict(a=a_fill,b=b_fill,nonce=nonce,shape=[m,n,k],rank=128,proof_seconds=seconds,
            bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),v3_valid=True,dense_equal=not args.production,
            corruption_cases_rejected=2,wrong_zero_rejected=(a_fill!=0 or b_fill!=0),snapshot_stable=True)
        records.append(record);print(json.dumps(record),flush=True)
    print(json.dumps(dict(kind="constant-sparse-gpu-pipeline",success=True,production=args.production,results=records,
        qualification="Offline integration, not public accepted shares or performance.")),flush=True)


if __name__=="__main__": main()
